# راهنمای گام‌به‌گام بیلد — Jarvis 2.0.0

این فایل دقیقاً همان کاری را می‌گوید که باید بکنید تا از این سورس یک APK نصب‌شدنی بگیرید.
هیچ مرحله‌ای جا نیفتاده و هر دستور آماده‌ی کپی‌کردن است.

---

## ۰. مهم‌ترین نکته را اول بگویم

**در این محیط، من نتوانستم APK بسازم.** دلیلش این است که سندباکس من اجازه‌ی دانلود
Android SDK و اجرای بیلد اندروید را نمی‌دهد (سیاست محیط، نه مشکل کد). پس:

| چه چیزی | وضعیت |
|---|---|
| ماژول `:core` (Kotlin خالص) | ✅ واقعاً کامپایل شد و ۳۴ تستش پاس شد |
| سرور رله | ✅ واقعاً lint شد و ۵۳ تستش پاس شد |
| ماژول `:app` (اندروید) | ⚠️ کامپایل نشد — اینجا Android SDK نیست |
| APK | ❌ ساخته نشد — شما باید بسازید (حدود ۱۰ دقیقه) |

هر چیزی که تست شده، پایین‌تر با علامت ✅ و هر چیزی که تست نشده با ⚠️ علامت خورده است.
هیچ‌جا ادعا نکرده‌ام چیزی را که امتحان نکرده‌ام.

---

## ۱. پیش‌نیازها

| ابزار | نسخه | چرا |
|---|---|---|
| **Android Studio** | Ladybug (2024.2) یا جدیدتر | راحت‌ترین راه. JDK 17 همراهش هست. |
| **JDK** | 17 | اگر از خط فرمان بیلد می‌کنید |
| **Android SDK Platform 35** | — | `compileSdk = 35` |
| **Android SDK Build-Tools** | 35.x | |
| **گوشی اندروید** | 8.0 (API 26) یا بالاتر | |

### نصب SDK از داخل Android Studio
`Settings → Languages & Frameworks → Android SDK` و بعد:

- تب **SDK Platforms** → تیک `Android 15.0 (API 35)` → Apply
- تب **SDK Tools** → تیک `Android SDK Build-Tools 35` و `Android SDK Platform-Tools` → Apply

---

## ۲. باز کردن پروژه

```bash
unzip jarvis-v4-source.zip
cd jarvis-v4/android
```

### راه الف — Android Studio (توصیه می‌شود)

1. `File → Open` و پوشه‌ی `jarvis-v4/android` را انتخاب کنید (**نه** پوشه‌ی والد).
2. صبر کنید تا Gradle Sync تمام شود. بار اول ۲ تا ۵ دقیقه طول می‌کشد چون وابستگی‌ها دانلود می‌شوند.
3. اگر پرسید «Trust project?» → **Trust**.

### راه ب — خط فرمان

اول فایل `local.properties` را بسازید تا Gradle بداند SDK کجاست:

```bash
cd jarvis-v4/android
cp local.properties.example local.properties
```

بعد مسیر SDK خودتان را در آن بنویسید:

```properties
# macOS
sdk.dir=/Users/YOUR_NAME/Library/Android/sdk
# Linux
sdk.dir=/home/YOUR_NAME/Android/Sdk
# Windows (به این شکل، با دو بک‌اسلش)
sdk.dir=C\:\\Users\\YOUR_NAME\\AppData\\Local\\Android\\Sdk
```

> اگر `local.properties` نباشد یا مسیرش غلط باشد، بیلد **با پیام واضح** شکست می‌خورد؛
> بی‌صدا به نسخه‌ی دیگری از SDK سقوط نمی‌کند. این دقیقاً باگ بیلد نسخه‌ی قبل بود.

---

## ۳. دستور دقیق بیلد و محل خروجی APK

### الف) APK دیباگ (سریع‌ترین راه برای نصب روی گوشی خودتان)

```bash
cd jarvis-v4/android
./gradlew :app:assembleDebug
```

**خروجی:**

```
jarvis-v4/android/app/build/outputs/apk/debug/app-debug.apk
```

روی ویندوز: `gradlew.bat :app:assembleDebug`

### ب) APK ریلیز، امضاشده با کلید خودتان

اول یک کلید بسازید (فقط یک‌بار در عمر پروژه):

```bash
keytool -genkeypair -v \
  -keystore jarvis-release.jks \
  -alias jarvis \
  -keyalg RSA -keysize 2048 -validity 10000
```

بعد فایل `android/keystore.properties` را بسازید (این فایل را **هرگز** کامیت نکنید):

```properties
storeFile=../jarvis-release.jks
storePassword=YOUR_STORE_PASSWORD
keyAlias=jarvis
keyPassword=YOUR_KEY_PASSWORD
```

و در `app/build.gradle.kts` داخل بلوک `android { }` این را اضافه کنید:

```kotlin
signingConfigs {
    create("release") {
        val props = java.util.Properties().apply {
            val f = rootProject.file("keystore.properties")
            if (f.exists()) f.inputStream().use { load(it) }
        }
        storeFile = props.getProperty("storeFile")?.let { file(it) }
        storePassword = props.getProperty("storePassword")
        keyAlias = props.getProperty("keyAlias")
        keyPassword = props.getProperty("keyPassword")
    }
}
// و داخل buildTypes { release { ... } }:
//   signingConfig = if (rootProject.file("keystore.properties").exists())
//       signingConfigs.getByName("release") else null
```

سپس:

```bash
./gradlew :app:assembleRelease
```

**خروجی:**

```
jarvis-v4/android/app/build/outputs/apk/release/app-release.apk
```

### ج) همه‌ی بررسی‌ها با هم (چیزی که من در محیط خودم نتوانستم اجرا کنم)

```bash
cd jarvis-v4/android

# تست‌های واحد ماژول core — این را من اجرا کردم، پاس است
./gradlew :core:test

# لینت اندروید روی ماژول app
./gradlew :app:lintDebug

# تست‌های واحد ماژول app (شامل MockWebServer)
./gradlew :app:testDebugUnitTest

# همه‌ی موارد بالا
./gradlew :core:test :app:testDebugUnitTest :app:lintDebug
```

> ⚠️ **صادقانه:** من `:core:test` را اجرا کردم و سبز است. سه دستور دیگر به Android SDK
> نیاز دارند و در محیط من قابل اجرا نبودند. اگر جایی خطا دیدند، متن خطا را بفرستید تا
> دقیقاً همان را درست کنم.

### د) نصب روی گوشی

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

یا فایل APK را به گوشی کپی کنید و روی آن بزنید (نصب از منابع ناشناس را اجازه بدهید).

---

## ۴. سرور را بالا بیاورید (بدون این، اپ کار نمی‌کند)

### الف) محلی، برای تست

```bash
cd jarvis-v4/server
npm install
cp .env.example .env
```

در `.env` اینها را پر کنید:

```bash
JARVIS_DEVICE_TOKEN=$(openssl rand -hex 32)   # این را کپی کنید، در اپ لازمش دارید
AI_PROVIDER=gemini
GEMINI_API_KEY=کلید-خودتان
```

کلید Gemini را از https://aistudio.google.com/apikey بگیرید.

```bash
npm run dev
# → http://localhost:3000
```

تست سریع:

```bash
curl -s http://localhost:3000/api/health \
  -H "Authorization: Bearer YOUR_DEVICE_TOKEN"
```

باید چیزی شبیه این برگردد:

```json
{"ok":true,"provider":"gemini","key_configured":true,...}
```

### ب) روی Vercel

```bash
cd jarvis-v4/server
npm i -g vercel
vercel login
vercel
```

بعد در داشبورد Vercel → پروژه → **Settings → Environment Variables** این‌ها را اضافه کنید:

| نام | مقدار |
|---|---|
| `JARVIS_DEVICE_TOKEN` | همان رشته‌ی تصادفی |
| `AI_PROVIDER` | `gemini` |
| `GEMINI_API_KEY` | کلید شما |

```bash
vercel --prod
```

آدرس نهایی را در اپ وارد کنید.

### ج) اتصال اپ به سرور

1. اپ را باز کنید → آیکن چرخ‌دنده (تنظیمات)
2. **آدرس سرور**: `https://your-project.vercel.app` (بدون `/` آخر)
3. **توکن دستگاه**: همان `JARVIS_DEVICE_TOKEN`
4. **ذخیره** → برگردید → یک فرمان بگویید

اگر خطا گرفتید، در لاگ Vercel (`vercel logs`) دنبال `auth_failed` یا `model_failed` بگردید.

### د) تست روی امولاتور با سرور محلی

در امولاتور، `localhost` یعنی خود امولاتور. برای رسیدن به سرور روی کامپیوتر خودتان از
`http://10.0.2.2:3000` استفاده کنید. `network_security_config.xml` فقط برای همین سه
آدرس (۱۰.۰.۲.۲، localhost، ۱۲۷.۰.۰.۱) ترافیک بدون TLS را مجاز کرده است؛ بقیه‌ی دنیا
فقط https.

---

## ۵. دسترسی‌هایی که باید در گوشی بدهید

بدون این‌ها اپ بالا می‌آید ولی کاری نمی‌تواند بکند. اپ خودش وضعیت هرکدام را نشان می‌دهد.

| دسترسی | مسیر | برای چه |
|---|---|---|
| **Accessibility** | تنظیمات → دسترسی‌پذیری → Jarvis → روشن | دیدن صفحه و زدن دکمه‌ها. **بدون این هیچ کاری نمی‌شود.** |
| میکروفون | اولین بار که دکمه‌ی میکروفون را بزنید | شنیدن |
| مخاطبین / تماس / پیامک | اولین استفاده | تماس و پیام |
| اعلان‌ها | اندروید ۱۳+ | نشان دادن وضعیت |
| ضبط صفحه | تنظیمات اپ → ضبط صفحه | دیدن تصاویر و ویدیو |

### چرا «Hey Jarvis» خودکار نیست

اندروید به اپ‌های شخص ثالث اجازه‌ی گوش دادن دائمی به میکروفون را نمی‌دهد؛ این کار فقط
برای دستیار سیستمی مجاز است. دو راه عملی که در اپ هست:

1. **کاشی تنظیمات سریع** — از پنل اعلان‌ها، یک ضربه روی Jarvis.
2. **دستیار پیش‌فرض** — تنظیمات → اپ‌ها → اپ پیش‌فرض → دستیار → Jarvis.
   بعد از آن، نگه‌داشتن دکمه‌ی خانه (یا حرکت به بالا از گوشه) Jarvis را باز می‌کند.

این محدودیت اندروید است، نه نقص پیاده‌سازی. هر اپی که ادعا کند بدون دستیار سیستمی
همیشه گوش می‌دهد، یا دروغ می‌گوید یا باتری را می‌خورد.

---

## ۶. اگر بیلد شکست خورد

| خطا | معنی | راه‌حل |
|---|---|---|
| `SDK location not found` | `local.properties` نیست | بخش ۲-ب را انجام دهید |
| `Failed to find target with hash string 'android-35'` | پلتفرم ۳۵ نصب نیست | SDK Manager → API 35 |
| `Unsupported class file major version 65` | JDK غلط (21 به‌جای 17) | `File → Project Structure → SDK Location → Gradle JDK → 17` |
| `Could not resolve androidx...` | شبکه یا مخزن | VPN/پراکسی را چک کنید؛ `google()` و `mavenCentral()` در `settings.gradle.kts` هستند |
| `Execution failed for task ':app:lintDebug'` | خطای لینت | متن خطا را بفرستید؛ `app/build/reports/lint-results-debug.html` را باز کنید |
| `Duplicate class kotlin.*` | نسخه‌های متناقض Kotlin | `./gradlew --refresh-dependencies` |

اگر هیچ‌کدام جواب نداد، خروجی کامل این دستور را بفرستید:

```bash
./gradlew :app:assembleDebug --stacktrace > build.log 2>&1
```

---

## ۷. چرا هیچ کلید مدلی داخل APK نیست

این را عمداً معماری کرده‌ام:

- کلید مدل فقط در Environment Variables سرور است.
- اپ فقط `JARVIS_DEVICE_TOKEN` را می‌فرستد که بدون سرور شما بی‌ارزش است.
- `BuildConfig` هیچ فیلدی برای کلید ندارد؛ اگر کسی APK را decompile کند چیزی پیدا نمی‌کند.
- `allowBackup=false` و قواعد backup، توکن دستگاه را از ابر و از انتقال بین گوشی‌ها بیرون می‌گذارد.

اگر کسی کلید را داخل اپ بگذارد، در عرض چند روز از APK بیرون کشیده و خرج می‌شود.
این معماری جلوی آن را می‌گیرد.
