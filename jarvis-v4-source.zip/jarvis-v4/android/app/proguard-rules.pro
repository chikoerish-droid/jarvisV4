# ---------------------------------------------------------------------------
# ProGuard / R8 rules
#
# kotlinx.serialization needs its generated serializers kept; everything else
# in this app is ordinary code that R8 handles correctly.
# ---------------------------------------------------------------------------

# kotlinx.serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.**
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# Keep our @Serializable models and their generated serializers
-keep,includedescriptorclasses class ai.jarvis.core.**$$serializer { *; }
-keepclassmembers class ai.jarvis.core.** {
    *** Companion;
}
-keepclasseswithmembers class ai.jarvis.core.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**

# Keep the accessibility service entry point
-keep class ai.jarvis.app.access.AccessibilityBridge { *; }
