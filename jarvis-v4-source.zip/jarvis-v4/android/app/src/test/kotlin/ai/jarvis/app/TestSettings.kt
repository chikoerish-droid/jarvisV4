package ai.jarvis.app

import ai.jarvis.app.data.SettingsProvider
import ai.jarvis.app.data.SettingsStore

/**
 * A SettingsProvider that holds values in memory, for JVM unit tests.
 * It deliberately mirrors the production defaults so the tests exercise the
 * same empty/placeholder behaviour a fresh install has.
 */
class TestSettings(
    private val url: String,
    private val token: String,
) : SettingsProvider {
    override suspend fun snapshot() = SettingsStore.Snapshot(
        serverUrl = url,
        deviceToken = token,
        locale = "fa-IR",
        speakReplies = false,
        confirmRisky = true,
        autoListen = false,
        maxIterations = 6,
        wakeWord = false,
    )
}
