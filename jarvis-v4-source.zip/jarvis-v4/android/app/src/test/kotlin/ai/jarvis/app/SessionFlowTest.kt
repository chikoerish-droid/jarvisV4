package ai.jarvis.app

import ai.jarvis.app.exec.ScreenController
import ai.jarvis.core.AgentLoop
import ai.jarvis.core.Device
import ai.jarvis.core.PlanRequest
import ai.jarvis.core.PlanResponse
import ai.jarvis.core.Planner
import ai.jarvis.core.Step
import ai.jarvis.core.StepOutcome
import ai.jarvis.core.StopReason
import ai.jarvis.core.Ui
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The end-to-end shape of a real session, with the network and the device
 * faked but the *loop* real:
 *
 *   "اینستاگرام را باز کن" -> open_app -> read_screen -> tap_text -> finish
 *
 * This is the acceptance test for the central complaint about v3 ("it is just
 * an offline app with a fixed command list"): it proves the assistant can
 * look at the screen and act on what it finds, over several model turns.
 */
class SessionFlowTest {

    private class ScriptedPlanner(private val script: List<PlanResponse>) : Planner {
        val requests = mutableListOf<PlanRequest>()
        override suspend fun plan(request: PlanRequest): PlanResponse {
            requests += request
            return script.getOrElse(requests.size - 1) { PlanResponse(speech = "تمام", done = true) }
        }
    }

    private class RecordingDevice(private val screenAfter: String) : Device {
        val ran = mutableListOf<String>()
        override suspend fun execute(step: Step): StepOutcome {
            ran += step.action
            return when (step.action) {
                "read_screen" -> StepOutcome(step, true, data = screenAfter)
                else -> StepOutcome(step, true)
            }
        }
        override suspend fun deviceState(): JsonObject =
            JsonObject(mapOf("foregroundApp" to JsonPrimitive("com.instagram.android")))
        override fun needsConfirmation(step: Step) = false
        override suspend fun confirm(step: Step) = true
    }

    private class SilentUi : Ui {
        val spoken = mutableListOf<String>()
        override suspend fun say(text: String) { spoken += text }
        override suspend fun askUser(question: String, options: List<String>, secret: Boolean): String? = null
        override suspend fun onStep(step: Step, outcome: StepOutcome) {}
    }

    @Test
    fun `a multi turn instagram task reads the screen and taps what it finds`() = runTest {
        val screen = """
            APP: com.instagram.android
            SCREEN: 1080x2400
            [0] clickable id=action_bar_title "Messages" bounds=[24,120][420,180] C
            [1] clickable "Search" bounds=[900,120][1050,180] C
        """.trimIndent()

        val planner = ScriptedPlanner(
            listOf(
                PlanResponse(
                    speech = "اینستاگرام را باز می‌کنم",
                    steps = listOf(Step("open_app", mapOf("app" to JsonPrimitive("اینستاگرام")))),
                ),
                PlanResponse(
                    speech = "صفحه را می‌خوانم",
                    steps = listOf(Step("read_screen")),
                ),
                PlanResponse(
                    speech = "پیام‌ها را باز می‌کنم",
                    steps = listOf(Step("tap_text", mapOf("text" to JsonPrimitive("Messages")))),
                    done = true,
                ),
            ),
        )
        val device = RecordingDevice(screen)
        val loop = AgentLoop(planner, device, SilentUi())

        val result = loop.run("اینستاگرام را باز کن و پیام‌هایم را ببین")

        assertEquals(StopReason.DONE, result.reason)
        assertEquals(listOf("open_app", "read_screen", "tap_text"), device.ran)
        // The model actually saw the screen before tapping.
        val third = planner.requests[2]
        assertTrue(third.observation?.data?.contains("Messages") == true)
    }

    @Test
    fun `an unrecoverable failure stops with an honest message`() = runTest {
        val planner = ScriptedPlanner(
            listOf(
                PlanResponse(speech = "تلاش می‌کنم", steps = listOf(Step("read_screen"))),
                PlanResponse(speech = "باز هم تلاش می‌کنم", steps = listOf(Step("read_screen"))),
                PlanResponse(speech = "باز هم", steps = listOf(Step("read_screen"))),
            ),
        )
        val failing = object : Device {
            override suspend fun execute(step: Step) = StepOutcome(step, false, "permission_denied")
            override suspend fun deviceState(): JsonObject? = null
            override fun needsConfirmation(step: Step) = false
            override suspend fun confirm(step: Step) = true
        }
        val loop = AgentLoop(planner, failing, SilentUi(), maxIterations = 3)

        val result = loop.run("کاری کن")

        assertEquals(StopReason.MAX_ITERATIONS, result.reason)
        assertTrue(result.speech.isNotBlank())
    }
}
