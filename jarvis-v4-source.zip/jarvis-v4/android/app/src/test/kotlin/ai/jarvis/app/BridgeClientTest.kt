package ai.jarvis.app

import ai.jarvis.app.net.BridgeClient
import ai.jarvis.app.net.BridgeException
import ai.jarvis.app.data.SettingsStore
import ai.jarvis.core.PlanRequest
import kotlinx.coroutines.test.runTest
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/**
 * Tests the network layer against a real local HTTP server.
 *
 * The important ones:
 *   - the Authorization header is actually sent (the v3 "Test connection"
 *     bug was an unauthenticated probe against a route that requires auth);
 *   - a 401 produces a readable Persian message instead of a crash;
 *   - numeric parameters in the response parse (the v3 crash).
 *
 * Note: this class uses a fake SettingsStore through an interface-free
 * approach — SettingsStore needs a Context, so the test builds a tiny
 * stand-in by overriding nothing. See BridgeClientTestSupport.
 */
class BridgeClientTest {

    private lateinit var server: MockWebServer

    @Before
    fun setUp() {
        server = MockWebServer()
        server.start()
    }

    @After
    fun tearDown() {
        server.shutdown()
    }

    @Test
    fun `a plan response is parsed with numeric parameters`() = runTest {
        server.enqueue(
            MockResponse()
                .setResponseCode(200)
                .setHeader("Content-Type", "application/json")
                .setBody(
                    """
                    {"requestId":"r1","speech":"باشه","steps":[
                      {"action":"tap_xy","params":{"x":100,"y":200}},
                      {"action":"wait","params":{"ms":500}}
                    ],"done":false}
                    """.trimIndent(),
                ),
        )

        val client = BridgeClient(TestSettings(server.url("/").toString().trimEnd('/'), "token"))
        val response = client.plan(PlanRequest(utterance = "تست"))

        assertEquals("باشه", response.speech)
        assertEquals(2, response.steps.size)
        assertEquals(100, response.steps[0].int("x"))
        assertEquals(500, response.steps[1].int("ms"))
    }

    @Test
    fun `the device token is sent as a bearer header`() = runTest {
        server.enqueue(MockResponse().setResponseCode(200).setBody("""{"speech":"ok","steps":[]}"""))

        val client = BridgeClient(TestSettings(server.url("/").toString().trimEnd('/'), "secret-device-token"))
        client.plan(PlanRequest(utterance = "hi"))

        val recorded = server.takeRequest()
        assertEquals("Bearer secret-device-token", recorded.getHeader("Authorization"))
        assertEquals("/api/plan", recorded.path)
        assertTrue(recorded.body.readUtf8().contains("\"utterance\":\"hi\""))
    }

    @Test
    fun `a 401 becomes a readable message about the token`() = runTest {
        server.enqueue(MockResponse().setResponseCode(401).setBody("""{"error":"bad_token"}"""))

        val client = BridgeClient(TestSettings(server.url("/").toString().trimEnd('/'), "wrong"))
        val error = runCatching { client.plan(PlanRequest(utterance = "hi")) }.exceptionOrNull()

        assertTrue(error is BridgeException)
        assertTrue(error!!.message!!.contains("توکن"))
    }

    @Test
    fun `a 429 becomes a readable rate limit message`() = runTest {
        server.enqueue(MockResponse().setResponseCode(429).setBody("""{"error":"rate_limited"}"""))

        val client = BridgeClient(TestSettings(server.url("/").toString().trimEnd('/'), "t"))
        val error = runCatching { client.plan(PlanRequest(utterance = "hi")) }.exceptionOrNull()

        assertTrue(error is BridgeException)
        assertTrue(error!!.message!!.contains("۴۲۹"))
    }

    @Test
    fun `an empty token is refused before any network call`() = runTest {
        val client = BridgeClient(TestSettings(server.url("/").toString().trimEnd('/'), ""))
        val error = runCatching { client.plan(PlanRequest(utterance = "hi")) }.exceptionOrNull()

        assertTrue(error is BridgeException)
        assertEquals(0, server.requestCount)
    }

    @Test
    fun `a placeholder server url is refused before any network call`() = runTest {
        val client = BridgeClient(TestSettings("https://your-jarvis.vercel.app", "token"))
        val error = runCatching { client.plan(PlanRequest(utterance = "hi")) }.exceptionOrNull()

        assertTrue(error is BridgeException)
        assertTrue(error!!.message!!.contains("سرور"))
    }

    @Test
    fun `malformed json becomes a readable error, not a crash`() = runTest {
        server.enqueue(MockResponse().setResponseCode(200).setBody("not json at all"))

        val client = BridgeClient(TestSettings(server.url("/").toString().trimEnd('/'), "t"))
        val error = runCatching { client.plan(PlanRequest(utterance = "hi")) }.exceptionOrNull()

        assertTrue(error is BridgeException)
    }

    @Test
    fun `health reports the provider when the server is healthy`() = runTest {
        server.enqueue(
            MockResponse().setResponseCode(200).setBody(
                """{"ok":true,"provider":"gemini","model":"gemini-2.5-flash","key_configured":true}""",
            ),
        )

        val client = BridgeClient(TestSettings(server.url("/").toString().trimEnd('/'), "t"))
        val result = client.health()

        assertTrue(result.ok)
        assertTrue(result.message.contains("gemini"))
    }

    @Test
    fun `health reports a missing server key honestly`() = runTest {
        server.enqueue(
            MockResponse().setResponseCode(200).setBody(
                """{"ok":true,"provider":"gemini","model":null,"key_configured":false}""",
            ),
        )

        val client = BridgeClient(TestSettings(server.url("/").toString().trimEnd('/'), "t"))
        val result = client.health()

        assertTrue(!result.ok)
        assertTrue(result.message.contains("کلید"))
    }
}
