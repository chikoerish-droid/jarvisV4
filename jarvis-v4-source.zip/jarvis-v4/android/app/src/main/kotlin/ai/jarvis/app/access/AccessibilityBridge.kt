package ai.jarvis.app.access

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.graphics.Rect
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * The accessibility service: the phone's eyes and hands.
 *
 * It does two things:
 *   1. exposes the current screen as a compact, model-friendly text tree
 *      (read_screen) — this is what makes the assistant able to *see*;
 *   2. performs taps, swipes, typing and scrolling on request.
 *
 * Design notes that matter:
 *   - The tree is pruned hard. A raw Android tree is thousands of nodes and
 *     would blow the model's context. We keep only nodes that are visible,
 *     clickable, editable, or carry text, and we cap the total.
 *   - The primary handle is the label (tap_text), because indices shift.
 *   - Nothing here decides *what* to do. It only executes. The brain is on the
 *     server.
 */
class AccessibilityBridge : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        val info = serviceInfo ?: AccessibilityServiceInfo()
        info.eventTypes = AccessibilityEvent.TYPES_ALL_MASK
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
        info.flags = info.flags or
            AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
            AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
            AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
        info.notificationTimeout = 50
        serviceInfo = info

        instance = this
        connected.value = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg == packageName) return
        lastForeground.value = pkg
    }

    override fun onInterrupt() { /* nothing to interrupt */ }

    override fun onDestroy() {
        connected.value = false
        instance = null
        super.onDestroy()
    }

    // ------------------------------------------------------------------ eyes

    /**
     * Renders the current screen as text.
     *
     * Format, one line per element:
     *   [i] <role> "label" id=viewId bounds=[l,t][r,b] flags
     *
     * `flags` is a compact set: C=clickable, E=editable, S=scrollable,
     * K=checked, D=disabled.
     */
    fun readScreen(maxNodes: Int = 120): String {
        val root = rootInActiveWindow
            ?: return "SCREEN_UNAVAILABLE: no active window (the app may be protected or the screen is off)"
        val sb = StringBuilder()
        val pkg = root.packageName?.toString() ?: "?"
        sb.append("APP: ").append(pkg).append('\n')

        val counter = intArrayOf(0)
        val screen = Rect()
        root.getBoundsInScreen(screen)
        sb.append("SCREEN: ").append(screen.width()).append('x').append(screen.height()).append('\n')

        walk(root, sb, counter, maxNodes, 0)
        if (counter[0] >= maxNodes) sb.append("... (truncated at $maxNodes elements)\n")
        return sb.toString()
    }

    private fun walk(
        node: AccessibilityNodeInfo?,
        sb: StringBuilder,
        counter: IntArray,
        maxNodes: Int,
        depth: Int,
    ) {
        if (node == null || counter[0] >= maxNodes || depth > 40) return

        val visible = node.isVisibleToUser
        val label = labelOf(node)
        val interesting = visible && (
            label != null ||
                node.isClickable ||
                node.isEditable ||
                node.isScrollable ||
                node.isCheckable
            )

        if (interesting) {
            val bounds = Rect()
            node.getBoundsInScreen(bounds)
            // Skip zero-size and off-screen nodes: they are noise.
            if (bounds.width() > 0 && bounds.height() > 0) {
                sb.append('[').append(counter[0]).append("] ")
                sb.append(roleOf(node)).append(' ')
                if (label != null) sb.append('"').append(label.replace('\n', ' ').take(120)).append("\" ")
                node.viewIdResourceName?.let { sb.append("id=").append(it.substringAfterLast('/')).append(' ') }
                sb.append("bounds=[").append(bounds.left).append(',').append(bounds.top)
                    .append("][").append(bounds.right).append(',').append(bounds.bottom).append("] ")
                val flags = buildString {
                    if (node.isClickable) append('C')
                    if (node.isEditable) append('E')
                    if (node.isScrollable) append('S')
                    if (node.isCheckable && node.isChecked) append('K')
                    if (!node.isEnabled) append('D')
                }
                if (flags.isNotEmpty()) sb.append(flags)
                sb.append('\n')
                counter[0]++
            }
        }

        for (i in 0 until node.childCount) {
            walk(node.getChild(i), sb, counter, maxNodes, depth + 1)
        }
    }

    private fun labelOf(node: AccessibilityNodeInfo): String? {
        val text = node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }
        val desc = node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }
        val hint = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            node.hintText?.toString()?.trim()?.takeIf { it.isNotEmpty() }
        } else null
        return text ?: desc ?: hint
    }

    private fun roleOf(node: AccessibilityNodeInfo): String = when {
        node.isEditable -> "input"
        node.className?.contains("Button") == true -> "button"
        node.isClickable -> "clickable"
        node.isScrollable -> "scroll"
        node.className?.contains("Image") == true -> "image"
        else -> "text"
    }

    // ----------------------------------------------------------------- hands

    /** Finds the first node whose label matches, case-insensitively. */
    fun findByText(text: String, index: Int = 0): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val matches = mutableListOf<AccessibilityNodeInfo>()
        collectMatches(root, text, matches, 0)
        return matches.getOrNull(index)
    }

    private fun collectMatches(
        node: AccessibilityNodeInfo?,
        needle: String,
        out: MutableList<AccessibilityNodeInfo>,
        depth: Int,
    ) {
        if (node == null || depth > 40 || out.size > 50) return
        val label = labelOf(node)
        if (label != null && label.contains(needle, ignoreCase = true) && node.isVisibleToUser) {
            out += node
        }
        for (i in 0 until node.childCount) collectMatches(node.getChild(i), needle, out, depth + 1)
    }

    fun clickNode(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        var guard = 0
        while (current != null && guard++ < 6) {
            if (current.isClickable) {
                return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            current = current.parent
        }
        return false
    }

    fun longClickNode(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        var guard = 0
        while (current != null && guard++ < 6) {
            if (current.isClickable) {
                return current.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)
            }
            current = current.parent
        }
        return false
    }

    fun setText(node: AccessibilityNodeInfo, text: String): Boolean {
        val args = android.os.Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun focus(node: AccessibilityNodeInfo): Boolean =
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS) ||
            node.performAction(AccessibilityNodeInfo.ACTION_CLICK)

    fun scroll(direction: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val action = when (direction) {
            "up" -> AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            "down" -> AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            else -> return false
        }
        // Prefer a scrollable node that is actually on screen.
        val scrollable = findScrollable(root, 0)
        return (scrollable ?: root).performAction(action)
    }

    private fun findScrollable(node: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
        if (node == null || depth > 30) return null
        if (node.isScrollable && node.isVisibleToUser) return node
        for (i in 0 until node.childCount) {
            findScrollable(node.getChild(i), depth + 1)?.let { return it }
        }
        return null
    }

    fun globalBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun globalHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun globalRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)

    companion object {
        @Volatile
        var instance: AccessibilityBridge? = null
            private set

        val connected = MutableStateFlow(false)
        val lastForeground = MutableStateFlow<String?>(null)

        fun isConnected(): Boolean = instance != null

        fun foregroundPackage(): String? = instance?.rootInActiveWindow?.packageName?.toString()
            ?: lastForeground.value
    }
}
