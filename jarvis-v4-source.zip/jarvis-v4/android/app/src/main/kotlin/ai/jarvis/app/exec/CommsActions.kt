package ai.jarvis.app.exec

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import ai.jarvis.core.Step
import ai.jarvis.core.StepOutcome

/**
 * Calls, SMS, WhatsApp, email, contacts.
 *
 * The v3 bug: `send_sms` with no `send` flag fell through to
 * SmsManager.sendTextMessage and sent the message silently. Here the default
 * is always the composer — the user presses send — and an immediate send
 * requires send=true AND the confirmation gate in the agent loop.
 */
class CommsActions(private val context: Context) {

    fun call(contact: String): StepOutcome {
        val number = resolveNumber(contact)
            ?: return StepOutcome(Step("call"), false, "شماره‌ی «$contact» پیدا نشد")
        val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE)
                != PackageManager.PERMISSION_GRANTED
            ) {
                context.startActivity(
                    Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                )
                return StepOutcome(
                    Step("call"), false,
                    "اجازه‌ی تماس داده نشده؛ صفحه‌ی شماره‌گیری باز شد.",
                )
            }
            context.startActivity(intent)
            StepOutcome(Step("call"), true, data = "calling $number")
        } catch (e: Exception) {
            StepOutcome(Step("call"), false, e.message)
        }
    }

    fun sms(contact: String, message: String, send: Boolean): StepOutcome {
        val number = resolveNumber(contact)
            ?: return StepOutcome(Step("send_sms"), false, "شماره‌ی «$contact» پیدا نشد")

        if (!send) {
            // Default: open the composer. The user presses send.
            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).apply {
                putExtra("sms_body", message)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            return try {
                context.startActivity(intent)
                StepOutcome(Step("send_sms"), true, data = "composer opened for $number")
            } catch (e: Exception) {
                StepOutcome(Step("send_sms"), false, e.message)
            }
        }

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return StepOutcome(Step("send_sms"), false, "اجازه‌ی ارسال پیامک داده نشده است.")
        }
        return try {
            val manager = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                context.getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getDefault()
            }
            manager.sendTextMessage(number, null, message, null, null)
            StepOutcome(Step("send_sms"), true, data = "sent to $number")
        } catch (e: Exception) {
            StepOutcome(Step("send_sms"), false, "ارسال نشد: ${e.message}")
        }
    }

    fun whatsapp(contact: String, message: String): StepOutcome {
        val number = resolveNumber(contact)
            ?: return StepOutcome(Step("send_whatsapp"), false, "شماره‌ی «$contact» پیدا نشد")
        val digits = number.filter { it.isDigit() || it == '+' }.removePrefix("+")
        val uri = Uri.parse("https://wa.me/$digits?text=${Uri.encode(message)}")
        val intent = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            StepOutcome(Step("send_whatsapp"), true, data = "whatsapp chat opened")
        } catch (e: Exception) {
            StepOutcome(Step("send_whatsapp"), false, "واتساپ نصب نیست یا باز نشد: ${e.message}")
        }
    }

    fun whatsappCall(contact: String, video: Boolean): StepOutcome {
        val number = resolveNumber(contact)
            ?: return StepOutcome(Step("whatsapp_call"), false, "شماره‌ی «$contact» پیدا نشد")
        val digits = number.filter { it.isDigit() }
        // WhatsApp has no public call intent; the reliable route is to open the
        // chat and let the user tap the call button. We say so.
        val uri = Uri.parse("https://wa.me/$digits")
        return try {
            context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            StepOutcome(
                Step("whatsapp_call"), false,
                "واتساپ API عمومی برای شروع تماس ندارد؛ چت باز شد، دکمه‌ی تماس را بزنید.",
            )
        } catch (e: Exception) {
            StepOutcome(Step("whatsapp_call"), false, e.message)
        }
    }

    fun email(to: String, subject: String, body: String): StepOutcome {
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$to")).apply {
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, body)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            StepOutcome(Step("send_email"), true, data = "mail composer opened")
        } catch (e: Exception) {
            StepOutcome(Step("send_email"), false, e.message)
        }
    }

    fun openContact(contact: String): StepOutcome {
        val uri = Uri.withAppendedPath(
            ContactsContract.CommonDataKinds.Phone.CONTENT_FILTER_URI,
            Uri.encode(contact),
        )
        return try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
            StepOutcome(Step("open_contact"), true, data = "contact opened")
        } catch (e: Exception) {
            StepOutcome(Step("open_contact"), false, e.message)
        }
    }

    /** Resolves a contact name to a phone number, or passes a number through. */
    fun resolveNumber(contact: String): String? {
        val trimmed = contact.trim()
        if (trimmed.matches(Regex("^[+]?[0-9\\s-]{3,}$"))) {
            return trimmed.replace(" ", "").replace("-", "")
        }
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return null
        }
        val uri = Uri.withAppendedPath(
            ContactsContract.CommonDataKinds.Phone.CONTENT_FILTER_URI,
            Uri.encode(trimmed),
        )
        context.contentResolver.query(
            uri,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null,
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                return cursor.getString(0)?.replace(" ", "")?.replace("-", "")
            }
        }
        return null
    }
}
