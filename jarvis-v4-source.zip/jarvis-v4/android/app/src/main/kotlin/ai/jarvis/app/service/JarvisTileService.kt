package ai.jarvis.app.service

import android.content.Intent
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import ai.jarvis.app.ui.MainActivity

/**
 * Quick Settings tile — one tap from anywhere to talk.
 *
 * This is the closest an app can get to "Hey Jarvis" without an always-on
 * hotword service, which Android does not allow for third-party apps (only the
 * system assistant can do that). If the user sets Jarvis as the default
 * assistant app, the long-press-home gesture opens it too (see the ASSIST
 * intent filter in the manifest).
 */
class JarvisTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        qsTile?.apply {
            state = Tile.STATE_INACTIVE
            label = "Jarvis"
            updateTile()
        }
    }

    override fun onClick() {
        super.onClick()
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra("start_listening", true)
        }
        // startActivityAndCollapse(Intent) only exists from API 34; older
        // versions need the PendingIntent form.
        if (android.os.Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(intent)
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(
                android.app.PendingIntent.getActivity(
                    this, 0, intent,
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE,
                ),
            )
        }
    }
}
