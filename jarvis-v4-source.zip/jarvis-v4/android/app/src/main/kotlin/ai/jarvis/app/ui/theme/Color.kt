package ai.jarvis.app.ui.theme

import androidx.compose.ui.graphics.Color

// A calm, high-contrast palette. Dark by default: the assistant is used in
// the dark, in the car, at night.
val ArcBlue = Color(0xFF6FA8FF)
val ArcBlueDark = Color(0xFF1B3A6B)
val ArcCyan = Color(0xFF7FE0D4)
val ArcAmber = Color(0xFFFFC46B)
val ArcRed = Color(0xFFFF7A7A)

val NightBase = Color(0xFF0D1117)
val NightSurface = Color(0xFF161B22)
val NightSurfaceVariant = Color(0xFF21262D)
val NightOutline = Color(0xFF30363D)

val DayBase = Color(0xFFF7F9FC)
val DaySurface = Color(0xFFFFFFFF)
val DaySurfaceVariant = Color(0xFFE8EDF5)
