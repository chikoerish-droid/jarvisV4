package ai.jarvis.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ai.jarvis.app.access.AccessibilityBridge
import ai.jarvis.app.net.HealthResult
import ai.jarvis.app.voice.VoiceController
import ai.jarvis.core.Step
import kotlinx.coroutines.flow.StateFlow

/**
 * The main screen: a conversation, a big mic button, and honest status.
 *
 * The design goal is "Jarvis, not a settings app": one screen, one button,
 * and a transcript that shows every step the assistant took so the user can
 * see what happened on their phone.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JarvisApp(
    messages: List<AgentViewModel.Message>,
    running: Boolean,
    pendingConfirm: AgentViewModel.PendingConfirm?,
    pendingQuestion: AgentViewModel.PendingQuestion?,
    health: HealthResult?,
    voice: VoiceController,
    onSubmit: (String) -> Unit,
    onStop: () -> Unit,
    onListen: () -> Unit,
    onStopListening: () -> Unit,
    onConfirm: (Boolean) -> Unit,
    onAnswer: (String?) -> Unit,
    onTestConnection: () -> Unit,
    onClearHealth: () -> Unit,
    onClearTranscript: () -> Unit,
    onRequestPermissions: () -> Unit,
) {
    val context = LocalContext.current
    var input by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val listening by voice.listening.collectAsStateSafe()
    val partial by voice.partial.collectAsStateSafe()
    val voiceError by voice.error.collectAsStateSafe()
    val accessibilityOn by AccessibilityBridge.connected.collectAsStateSafe()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }

    if (showSettings) {
        SettingsScreen(onBack = { showSettings = false })
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Jarvis", fontWeight = FontWeight.SemiBold)
                        Text(
                            if (accessibilityOn) "دسترسی فعال است" else "دسترسی خاموش است",
                            fontSize = 11.sp,
                            color = if (accessibilityOn) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.error,
                        )
                    }
                },
                actions = {
                    IconButton(onClick = onClearTranscript) {
                        Text("پاک", fontSize = 12.sp)
                    }
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Default.Settings, contentDescription = "تنظیمات")
                    }
                },
            )
        },
        bottomBar = {
            Composer(
                input = input,
                onInputChange = { input = it },
                running = running,
                listening = listening,
                partial = partial,
                onSend = {
                    if (input.isNotBlank()) {
                        onSubmit(input)
                        input = ""
                    }
                },
                onMic = { if (listening) onStopListening() else onListen() },
                onStop = onStop,
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .imePadding(),
        ) {
            if (!accessibilityOn) {
                PermissionBanner(
                    text = "برای دیدن و کنترل صفحه، Jarvis را در Accessibility روشن کنید.",
                    action = "باز کردن تنظیمات",
                    onClick = {
                        context.startActivity(
                            android.content.Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)
                                .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK),
                        )
                    },
                )
            }

            voiceError?.let {
                PermissionBanner(text = it, action = "اجازه‌ها", onClick = onRequestPermissions)
            }

            health?.let {
                PermissionBanner(
                    text = it.message,
                    action = "بستن",
                    onClick = onClearHealth,
                    isError = !it.ok,
                )
            }

            if (messages.isEmpty()) {
                EmptyState(onSuggestion = onSubmit)
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(messages) { message -> MessageBubble(message) }
                    item { Spacer(Modifier.height(8.dp)) }
                }
            }
        }
    }

    pendingConfirm?.let { pending ->
        ConfirmDialog(step = pending.step, onAnswer = onConfirm)
    }

    pendingQuestion?.let { pending ->
        QuestionDialog(pending = pending, onAnswer = onAnswer)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EmptyState(onSuggestion: (String) -> Unit) {
    val suggestions = listOf(
        "اینستاگرام را باز کن و پیام‌های جدیدم را بخوان",
        "برای علی پیام بفرست که دیر می‌رسم",
        "یک اسنپ تا میدان ونک بگیر",
        "صدای این آهنگ را دانلود کن",
        "وای‌فای را خاموش کن",
    )
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .size(96.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center,
        ) {
            Text("J", fontSize = 44.sp, fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer)
        }
        Spacer(Modifier.height(20.dp))
        Text("چه کاری برایتان انجام بدهم؟", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(6.dp))
        Text(
            "به فارسی یا انگلیسی بگویید. Jarvis روی گوشی شما کار می‌کند و مغزش روی سرور خودتان است.",
            style = MaterialTheme.typography.bodySmall,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(24.dp))
        suggestions.forEach { suggestion ->
            Card(
                onClick = { onSuggestion(suggestion) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                ),
            ) {
                Text(
                    suggestion,
                    modifier = Modifier.padding(14.dp),
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }
    }
}

@Composable
private fun MessageBubble(message: AgentViewModel.Message) {
    val isUser = message.from == "user"
    val isStep = message.from == "step"
    val alignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
    val bg = when {
        isUser -> MaterialTheme.colorScheme.primary
        message.kind == AgentViewModel.Message.Kind.ERROR -> MaterialTheme.colorScheme.errorContainer
        isStep -> MaterialTheme.colorScheme.surfaceVariant
        else -> MaterialTheme.colorScheme.secondaryContainer
    }
    val fg = when {
        isUser -> MaterialTheme.colorScheme.onPrimary
        message.kind == AgentViewModel.Message.Kind.ERROR -> MaterialTheme.colorScheme.onErrorContainer
        else -> MaterialTheme.colorScheme.onSurface
    }

    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = alignment) {
        Surface(
            color = bg,
            shape = RoundedCornerShape(
                topStart = 16.dp, topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 16.dp,
            ),
            modifier = Modifier.fillMaxWidth(if (isStep) 0.92f else 0.85f),
        ) {
            Text(
                text = message.text,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                color = fg,
                fontSize = if (isStep) 12.sp else 15.sp,
            )
        }
    }
}

@Composable
private fun Composer(
    input: String,
    onInputChange: (String) -> Unit,
    running: Boolean,
    listening: Boolean,
    partial: String,
    onSend: () -> Unit,
    onMic: () -> Unit,
    onStop: () -> Unit,
) {
    Surface(tonalElevation = 3.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            OutlinedTextField(
                value = if (listening && partial.isNotBlank()) partial else input,
                onValueChange = onInputChange,
                modifier = Modifier.weight(1f),
                placeholder = { Text(if (listening) "می‌شنوم…" else "بگویید یا بنویسید…") },
                maxLines = 4,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { onSend() }),
                shape = RoundedCornerShape(24.dp),
            )
            Spacer(Modifier.width(8.dp))
            if (running) {
                FloatingActionButton(
                    onClick = onStop,
                    containerColor = MaterialTheme.colorScheme.error,
                ) {
                    Icon(Icons.Default.Stop, contentDescription = "توقف")
                }
            } else {
                FloatingActionButton(
                    onClick = onMic,
                    containerColor = if (listening) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.primary,
                ) {
                    if (listening) CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        strokeWidth = 2.dp,
                        color = Color.White,
                    ) else Icon(Icons.Default.Mic, contentDescription = "میکروفون")
                }
                Spacer(Modifier.width(6.dp))
                IconButton(onClick = onSend, enabled = input.isNotBlank()) {
                    Icon(Icons.Default.Send, contentDescription = "ارسال")
                }
            }
        }
    }
}

@Composable
private fun PermissionBanner(
    text: String,
    action: String,
    onClick: () -> Unit,
    isError: Boolean = false,
) {
    Surface(
        color = if (isError) MaterialTheme.colorScheme.errorContainer
        else MaterialTheme.colorScheme.tertiaryContainer,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp),
        shape = RoundedCornerShape(12.dp),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(text, modifier = Modifier.weight(1f), fontSize = 12.sp)
            TextButton(onClick = onClick) { Text(action, fontSize = 12.sp) }
        }
    }
}

@Composable
private fun ConfirmDialog(step: Step, onAnswer: (Boolean) -> Unit) {
    val description = when (step.action) {
        "call" -> "تماس با ${step.str("contact")}"
        "send_sms" -> "ارسال پیامک به ${step.str("contact")}"
        "send_whatsapp" -> "پیام واتساپ به ${step.str("contact")}"
        "delete_file" -> "حذف فایل ${step.str("path")}"
        "install_apk" -> "نصب برنامه"
        "instagram_post" -> "انتشار در اینستاگرام"
        "x_post" -> "انتشار در X"
        else -> step.action
    }
    AlertDialog(
        onDismissRequest = { onAnswer(false) },
        title = { Text("تأیید لازم است") },
        text = { Text("آیا «$description» انجام شود؟") },
        confirmButton = { Button(onClick = { onAnswer(true) }) { Text("بله") } },
        dismissButton = { TextButton(onClick = { onAnswer(false) }) { Text("نه") } },
    )
}

@Composable
private fun QuestionDialog(pending: AgentViewModel.PendingQuestion, onAnswer: (String?) -> Unit) {
    var value by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = { onAnswer(null) },
        title = { Text("یک سؤال") },
        text = {
            Column {
                Text(pending.question)
                Spacer(Modifier.height(12.dp))
                if (pending.options.isNotEmpty()) {
                    pending.options.forEach { option ->
                        TextButton(onClick = { onAnswer(option) }) { Text(option) }
                    }
                } else {
                    OutlinedTextField(
                        value = value,
                        onValueChange = { value = it },
                        singleLine = true,
                        visualTransformation = if (pending.secret) PasswordVisualTransformation()
                        else androidx.compose.ui.text.input.VisualTransformation.None,
                    )
                }
            }
        },
        confirmButton = {
            if (pending.options.isEmpty()) {
                Button(onClick = { onAnswer(value) }) { Text("تأیید") }
            }
        },
        dismissButton = { TextButton(onClick = { onAnswer(null) }) { Text("لغو") } },
    )
}

/** Collects a StateFlow with lifecycle awareness. */
@Composable
private fun <T> StateFlow<T>.collectAsStateSafe() =
    androidx.lifecycle.compose.collectAsStateWithLifecycle()
