package ai.jarvis.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Re-arms the quick-settings tile after a reboot.
 *
 * Deliberately does NOT start a background listener: an always-on microphone
 * is not something an app should sneak in, and Android would kill it anyway.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        // Requesting the tile update re-registers it with SystemUI.
        runCatching {
            android.service.quicksettings.TileService.requestListeningState(
                context!!,
                android.content.ComponentName(context, JarvisTileService::class.java),
            )
        }
    }
}
