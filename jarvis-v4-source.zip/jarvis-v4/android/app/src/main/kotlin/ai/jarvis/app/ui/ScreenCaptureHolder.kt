package ai.jarvis.app.ui

import android.graphics.Bitmap

/**
 * Holds the most recent screen capture.
 *
 * MediaProjection needs a user-granted token and a foreground service; the
 * capture itself is produced by [ScreenCaptureService]. The executor reads the
 * latest frame from here. If nothing has been captured, `screenshot` returns a
 * clear "permission not granted" error instead of a blank image.
 */
object ScreenCaptureHolder {
    @Volatile
    private var latest: Bitmap? = null

    fun put(bitmap: Bitmap) {
        latest = bitmap
    }

    fun latest(): Bitmap? = latest

    fun clear() {
        latest = null
    }
}
