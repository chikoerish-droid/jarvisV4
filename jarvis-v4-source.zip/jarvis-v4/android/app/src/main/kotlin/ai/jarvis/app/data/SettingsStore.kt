package ai.jarvis.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "jarvis_settings")

/**
 * Settings, persisted with DataStore.
 *
 * The device token is stored here. It is NOT a model key: it only proves to
 * the relay that this phone is allowed to talk to it, and it is useless
 * without the server. It is excluded from cloud backup (see
 * data_extraction_rules.xml) so it does not leak through a Google account.
 */
class SettingsStore(private val context: Context) : SettingsProvider {

    private object Keys {
        val SERVER_URL = stringPreferencesKey("server_url")
        val DEVICE_TOKEN = stringPreferencesKey("device_token")
        val LOCALE = stringPreferencesKey("locale")
        val SPEAK_REPLIES = booleanPreferencesKey("speak_replies")
        val CONFIRM_RISKY = booleanPreferencesKey("confirm_risky")
        val AUTO_LISTEN = booleanPreferencesKey("auto_listen")
        val MAX_ITERATIONS = intPreferencesKey("max_iterations")
        val WAKE_WORD = booleanPreferencesKey("wake_word")
        val ONBOARDED = booleanPreferencesKey("onboarded")
    }

    val serverUrl: Flow<String> = context.dataStore.data.map { it[Keys.SERVER_URL] ?: DEFAULT_SERVER }
    val deviceToken: Flow<String> = context.dataStore.data.map { it[Keys.DEVICE_TOKEN] ?: "" }
    val locale: Flow<String> = context.dataStore.data.map { it[Keys.LOCALE] ?: "fa-IR" }
    val speakReplies: Flow<Boolean> = context.dataStore.data.map { it[Keys.SPEAK_REPLIES] ?: true }
    val confirmRisky: Flow<Boolean> = context.dataStore.data.map { it[Keys.CONFIRM_RISKY] ?: true }
    val autoListen: Flow<Boolean> = context.dataStore.data.map { it[Keys.AUTO_LISTEN] ?: false }
    val maxIterations: Flow<Int> = context.dataStore.data.map { it[Keys.MAX_ITERATIONS] ?: 6 }
    val wakeWord: Flow<Boolean> = context.dataStore.data.map { it[Keys.WAKE_WORD] ?: false }
    val onboarded: Flow<Boolean> = context.dataStore.data.map { it[Keys.ONBOARDED] ?: false }

    suspend fun ensureDefaults() {
        context.dataStore.edit { prefs ->
            if (prefs[Keys.SERVER_URL].isNullOrBlank()) prefs[Keys.SERVER_URL] = DEFAULT_SERVER
            if (prefs[Keys.LOCALE].isNullOrBlank()) prefs[Keys.LOCALE] = "fa-IR"
        }
    }

    suspend fun setServerUrl(value: String) = context.dataStore.edit {
        it[Keys.SERVER_URL] = value.trim().trimEnd('/')
    }

    suspend fun setDeviceToken(value: String) = context.dataStore.edit {
        it[Keys.DEVICE_TOKEN] = value.trim()
    }

    suspend fun setLocale(value: String) = context.dataStore.edit { it[Keys.LOCALE] = value }
    suspend fun setSpeakReplies(value: Boolean) = context.dataStore.edit { it[Keys.SPEAK_REPLIES] = value }
    suspend fun setConfirmRisky(value: Boolean) = context.dataStore.edit { it[Keys.CONFIRM_RISKY] = value }
    suspend fun setAutoListen(value: Boolean) = context.dataStore.edit { it[Keys.AUTO_LISTEN] = value }
    suspend fun setMaxIterations(value: Int) = context.dataStore.edit {
        it[Keys.MAX_ITERATIONS] = value.coerceIn(1, 20)
    }
    suspend fun setWakeWord(value: Boolean) = context.dataStore.edit { it[Keys.WAKE_WORD] = value }
    suspend fun setOnboarded(value: Boolean) = context.dataStore.edit { it[Keys.ONBOARDED] = value }

    override suspend fun snapshot(): Snapshot = Snapshot(
        serverUrl = serverUrl.first(),
        deviceToken = deviceToken.first(),
        locale = locale.first(),
        speakReplies = speakReplies.first(),
        confirmRisky = confirmRisky.first(),
        autoListen = autoListen.first(),
        maxIterations = maxIterations.first(),
        wakeWord = wakeWord.first(),
    )

    data class Snapshot(
        val serverUrl: String,
        val deviceToken: String,
        val locale: String,
        val speakReplies: Boolean,
        val confirmRisky: Boolean,
        val autoListen: Boolean,
        val maxIterations: Int,
        val wakeWord: Boolean,
    )

    companion object {
        /** Shown on first run; the user replaces it with their own deployment. */
        const val DEFAULT_SERVER = "https://your-jarvis.vercel.app"
    }
}
