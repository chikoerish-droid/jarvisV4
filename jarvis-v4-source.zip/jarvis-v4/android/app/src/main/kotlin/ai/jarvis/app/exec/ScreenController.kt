package ai.jarvis.app.exec

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.os.Build
import android.util.Base64
import ai.jarvis.app.access.AccessibilityBridge
import ai.jarvis.core.Step
import ai.jarvis.core.StepOutcome
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume

/**
 * Everything that touches the screen: reading it, tapping it, typing into it,
 * and capturing it as an image.
 *
 * Gestures go through the accessibility service's dispatchGesture, which is
 * the only way an app can tap another app without root. Screenshots go through
 * MediaProjection, which the user grants once.
 */
class ScreenController(
    private val bridgeProvider: () -> AccessibilityBridge?,
    private val screenshotProvider: () -> Bitmap?,
) {

    private val bridge get() = bridgeProvider()

    fun read(): StepOutcome {
        val b = bridge ?: return notConnected()
        val text = b.readScreen()
        return if (text.startsWith("SCREEN_UNAVAILABLE")) {
            StepOutcome(Step("read_screen"), false, text)
        } else {
            StepOutcome(Step("read_screen"), true, data = text)
        }
    }

    fun screenshot(full: Boolean): StepOutcome {
        val bitmap = screenshotProvider()
            ?: return StepOutcome(
                Step("screenshot"), false,
                "دسترسی ضبط صفحه داده نشده است. یک‌بار از تنظیمات آن را فعال کنید.",
            )
        val scaled = scaleDown(bitmap, 1080)
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 70, out)
        val b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        return StepOutcome(Step("screenshot"), true, data = "data:image/jpeg;base64,$b64")
    }

    private fun scaleDown(src: Bitmap, maxWidth: Int): Bitmap {
        if (src.width <= maxWidth) return src
        val ratio = maxWidth.toFloat() / src.width
        return Bitmap.createScaledBitmap(src, maxWidth, (src.height * ratio).toInt(), true)
    }

    suspend fun tapText(text: String, index: Int): StepOutcome {
        val b = bridge ?: return notConnected()
        val node = b.findByText(text, index)
            ?: return StepOutcome(Step("tap_text"), false, "عنصری با متن «$text» روی صفحه پیدا نشد")
        val ok = b.clickNode(node)
        delay(250)
        return if (ok) StepOutcome(Step("tap_text"), true, data = "tapped \"$text\"")
        else StepOutcome(Step("tap_text"), false, "عنصر «$text» قابل کلیک نبود")
    }

    suspend fun longPress(text: String): StepOutcome {
        val b = bridge ?: return notConnected()
        val node = b.findByText(text)
            ?: return StepOutcome(Step("long_press_text"), false, "عنصری با متن «$text» پیدا نشد")
        val ok = b.longClickNode(node)
        delay(250)
        return if (ok) StepOutcome(Step("long_press_text"), true, data = "long-pressed \"$text\"")
        else StepOutcome(Step("long_press_text"), false, "عنصر «$text» قابل نگه‌داشتن نبود")
    }

    suspend fun tap(x: Int, y: Int): StepOutcome {
        val ok = gesture { path -> path.moveTo(x.toFloat(), y.toFloat()) }
        delay(200)
        return if (ok) StepOutcome(Step("tap_xy"), true, data = "tapped ($x,$y)")
        else StepOutcome(Step("tap_xy"), false, "اشاره انجام نشد")
    }

    suspend fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, durationMs: Int): StepOutcome {
        val ok = gesture { path ->
            path.moveTo(x1.toFloat(), y1.toFloat())
            path.lineTo(x2.toFloat(), y2.toFloat())
        }
        delay(300)
        return if (ok) StepOutcome(Step("swipe"), true, data = "swiped")
        else StepOutcome(Step("swipe"), false, "اشاره انجام نشد")
    }

    suspend fun scroll(direction: String, amount: String): StepOutcome {
        val b = bridge ?: return notConnected()
        // Semantic scroll first: it works inside lists and does not depend on
        // screen size.
        if (direction == "up" || direction == "down") {
            if (b.scroll(direction)) {
                delay(300)
                return StepOutcome(Step("scroll"), true, data = "scrolled $direction")
            }
        }
        // Fall back to a swipe across the middle of the screen.
        val metrics = android.content.res.Resources.getSystem().displayMetrics
        val w = metrics.widthPixels
        val h = metrics.heightPixels
        val fraction = when (amount) {
            "small" -> 0.25f
            "large" -> 0.8f
            else -> 0.55f
        }
        val (x1, y1, x2, y2) = when (direction) {
            "down" -> listOf(w / 2, (h * 0.75f).toInt(), w / 2, (h * (0.75f - fraction)).toInt())
            "up" -> listOf(w / 2, (h * 0.25f).toInt(), w / 2, (h * (0.25f + fraction)).toInt())
            "left" -> listOf((w * 0.8f).toInt(), h / 2, (w * (0.8f - fraction)).toInt(), h / 2)
            else -> listOf((w * 0.2f).toInt(), h / 2, (w * (0.2f + fraction)).toInt(), h / 2)
        }
        return swipe(x1, y1, x2, y2, 300)
    }

    suspend fun type(text: String, submit: Boolean): StepOutcome {
        val b = bridge ?: return notConnected()
        val root = b.rootInActiveWindow
            ?: return StepOutcome(Step("type_text"), false, "پنجره‌ای فعال نیست")

        val focused = root.findFocus(android.view.accessibility.AccessibilityNodeInfo.FOCUS_INPUT)
        val target = focused ?: findFirstEditable(root)
            ?: return StepOutcome(Step("type_text"), false, "فیلد متنی روی صفحه پیدا نشد")

        if (!target.isFocused) b.focus(target)
        delay(120)

        val ok = b.setText(target, text)
        delay(150)
        if (!ok) {
            return StepOutcome(Step("type_text"), false, "نوشتن در فیلد ممکن نشد")
        }
        if (submit) {
            target.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_IME_ENTER)
            delay(200)
        }
        return StepOutcome(Step("type_text"), true, data = "typed ${text.length} chars")
    }

    private fun findFirstEditable(
        node: android.view.accessibility.AccessibilityNodeInfo?,
        depth: Int = 0,
    ): android.view.accessibility.AccessibilityNodeInfo? {
        if (node == null || depth > 30) return null
        if (node.isEditable && node.isVisibleToUser) return node
        for (i in 0 until node.childCount) {
            findFirstEditable(node.getChild(i), depth + 1)?.let { return it }
        }
        return null
    }

    fun pressKey(key: String): StepOutcome {
        val b = bridge ?: return notConnected()
        val ok = when (key) {
            "back" -> b.globalBack()
            "home" -> b.globalHome()
            "search" -> b.globalRecents()
            else -> false
        }
        return if (ok) StepOutcome(Step("press_key"), true, data = "pressed $key")
        else StepOutcome(Step("press_key"), false, "کلید $key پشتیبانی نمی‌شود")
    }

    fun back(): StepOutcome {
        val b = bridge ?: return notConnected()
        return if (b.globalBack()) StepOutcome(Step("back"), true, data = "back")
        else StepOutcome(Step("back"), false, "سرویس دسترسی فعال نیست")
    }

    fun home(): StepOutcome {
        val b = bridge ?: return notConnected()
        return if (b.globalHome()) StepOutcome(Step("home"), true, data = "home")
        else StepOutcome(Step("home"), false, "سرویس دسترسی فعال نیست")
    }

    fun recents(): StepOutcome {
        val b = bridge ?: return notConnected()
        return if (b.globalRecents()) StepOutcome(Step("recents"), true, data = "recents")
        else StepOutcome(Step("recents"), false, "سرویس دسترسی فعال نیست")
    }

    // ---------------------------------------------------------------- gesture

    private suspend fun gesture(build: (Path) -> Unit): Boolean {
        val b = bridge ?: return false
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false

        val path = Path().apply(build)
        val stroke = GestureDescription.StrokeDescription(path, 0, 60)
        val description = GestureDescription.Builder().addStroke(stroke).build()

        return suspendCancellableCoroutine { cont ->
            val callback = object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resume(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resume(false)
                }
            }
            val dispatched = b.dispatchGesture(description, callback, null)
            if (!dispatched && cont.isActive) cont.resume(false)
        }
    }

    private fun notConnected() = StepOutcome(
        Step("screen"), false,
        "سرویس دسترسی فعال نیست. در تنظیمات اندروید، Jarvis را در Accessibility روشن کنید.",
    )
}
