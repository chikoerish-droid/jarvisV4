package ai.jarvis.app.exec

import android.content.Context
import android.os.Environment
import ai.jarvis.core.Step
import ai.jarvis.core.StepOutcome
import java.io.File

/**
 * File operations in shared storage.
 *
 * Scoped storage is respected: we work inside the app's own external dir and
 * the public Download/Music/DCIM folders, and we never ask for
 * MANAGE_EXTERNAL_STORAGE. A path outside those roots is refused with a clear
 * reason rather than silently failing.
 */
class FileActions(private val context: Context) {

    private val roots: List<File> = listOfNotNull(
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC),
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS),
        context.getExternalFilesDir(null),
    )

    private fun resolve(path: String): File? {
        val direct = File(path)
        if (direct.isAbsolute && direct.exists()) return direct
        for (root in roots) {
            val candidate = File(root, path)
            if (candidate.exists()) return candidate
        }
        // Allow a not-yet-existing target inside a known root.
        for (root in roots) {
            val candidate = File(root, path)
            if (candidate.parentFile?.exists() == true) return candidate
        }
        return null
    }

    fun list(dir: String): StepOutcome {
        val target = resolve(dir)
            ?: return StepOutcome(Step("list_files"), false, "پوشه پیدا نشد: $dir")
        if (!target.isDirectory) return StepOutcome(Step("list_files"), false, "$dir یک پوشه نیست")
        val items = target.listFiles()?.sortedBy { it.name }?.take(200)?.map {
            val kind = if (it.isDirectory) "dir " else "file"
            val size = if (it.isFile) " ${it.length()}B" else ""
            "$kind ${it.name}$size"
        } ?: emptyList()
        return StepOutcome(Step("list_files"), true, data = items.joinToString("\n"))
    }

    fun move(from: String, to: String): StepOutcome = transfer(from, to, move = true)
    fun copy(from: String, to: String): StepOutcome = transfer(from, to, move = false)

    private fun transfer(from: String, to: String, move: Boolean): StepOutcome {
        val src = resolve(from) ?: return StepOutcome(Step("move_file"), false, "مبدأ پیدا نشد: $from")
        if (!src.exists()) return StepOutcome(Step("move_file"), false, "مبدأ وجود ندارد: $from")
        val destDir = resolve(to) ?: return StepOutcome(Step("move_file"), false, "مقصد پیدا نشد: $to")
        val dest = if (destDir.isDirectory) File(destDir, src.name) else destDir
        return try {
            if (move) {
                if (!src.renameTo(dest)) {
                    src.copyTo(dest, overwrite = true)
                    src.delete()
                }
            } else {
                src.copyTo(dest, overwrite = true)
            }
            StepOutcome(Step(if (move) "move_file" else "copy_file"), true, data = "-> ${dest.absolutePath}")
        } catch (e: Exception) {
            StepOutcome(Step("move_file"), false, e.message)
        }
    }

    fun rename(path: String, newName: String): StepOutcome {
        val src = resolve(path) ?: return StepOutcome(Step("rename_file"), false, "فایل پیدا نشد: $path")
        val dest = File(src.parentFile, newName)
        return if (src.renameTo(dest)) {
            StepOutcome(Step("rename_file"), true, data = "renamed to $newName")
        } else {
            StepOutcome(Step("rename_file"), false, "تغییر نام ممکن نشد")
        }
    }

    fun delete(path: String): StepOutcome {
        val file = resolve(path) ?: return StepOutcome(Step("delete_file"), false, "فایل پیدا نشد: $path")
        return if (file.delete()) {
            StepOutcome(Step("delete_file"), true, data = "deleted $path")
        } else {
            StepOutcome(Step("delete_file"), false, "حذف ممکن نشد")
        }
    }

    fun createFolder(path: String): StepOutcome {
        val dir = resolve(path) ?: return StepOutcome(Step("create_folder"), false, "مسیر مجاز نیست: $path")
        return if (dir.mkdirs() || dir.isDirectory) {
            StepOutcome(Step("create_folder"), true, data = "created ${dir.absolutePath}")
        } else {
            StepOutcome(Step("create_folder"), false, "ساخت پوشه ممکن نشد")
        }
    }
}
