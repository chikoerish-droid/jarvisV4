package ai.jarvis.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkScheme = darkColorScheme(
    primary = ArcBlue,
    onPrimary = Color(0xFF06111F),
    primaryContainer = ArcBlueDark,
    onPrimaryContainer = Color(0xFFD6E4FF),
    secondary = ArcCyan,
    onSecondary = Color(0xFF00201C),
    secondaryContainer = Color(0xFF16323A),
    onSecondaryContainer = Color(0xFFB8F2EA),
    tertiary = ArcAmber,
    error = ArcRed,
    errorContainer = Color(0xFF4A1D1D),
    onErrorContainer = Color(0xFFFFD9D9),
    background = NightBase,
    onBackground = Color(0xFFE6EDF3),
    surface = NightSurface,
    onSurface = Color(0xFFE6EDF3),
    surfaceVariant = NightSurfaceVariant,
    onSurfaceVariant = Color(0xFFA9B4C0),
    outline = NightOutline,
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF2F6FD0),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD6E4FF),
    onPrimaryContainer = Color(0xFF0A2748),
    secondary = Color(0xFF0E7C70),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFB8F2EA),
    onSecondaryContainer = Color(0xFF00201C),
    tertiary = Color(0xFF9A6200),
    error = Color(0xFFB3261E),
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
    background = DayBase,
    onBackground = Color(0xFF11151A),
    surface = DaySurface,
    onSurface = Color(0xFF11151A),
    surfaceVariant = DaySurfaceVariant,
    onSurfaceVariant = Color(0xFF44505F),
)

@Composable
fun JarvisTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkScheme else LightScheme,
        typography = JarvisTypography,
        content = content,
    )
}
