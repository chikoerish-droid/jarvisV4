package ai.jarvis.app.exec

import android.content.Context
import android.content.Intent
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.view.KeyEvent
import androidx.core.content.FileProvider
import ai.jarvis.app.data.SettingsStore
import ai.jarvis.core.Step
import ai.jarvis.core.StepOutcome
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Media: transport control, recording, downloads, APK install.
 *
 * The "download this song as mp3" case is handled honestly: the phone asks the
 * relay to resolve a direct audio URL, and if the relay has no resolver
 * configured it says so. v3 downloaded the YouTube *web page* and saved it as
 * .mp3, which is why the file never played.
 */
class MediaActions(
    private val context: Context,
    private val settings: SettingsStore,
) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()

    fun control(command: String): StepOutcome {
        val keyCode = when (command) {
            "play", "pause", "toggle" -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
            else -> return StepOutcome(Step("media_control"), false, "فرمان ناشناخته: $command")
        }
        return try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
            StepOutcome(Step("media_control"), true, data = command)
        } catch (e: Exception) {
            StepOutcome(Step("media_control"), false, e.message)
        }
    }

    suspend fun record(durationS: Int): StepOutcome = withContext(Dispatchers.IO) {
        val dir = File(context.getExternalFilesDir(null), "recordings").apply { mkdirs() }
        val file = File(dir, "rec_${System.currentTimeMillis()}.m4a")
        val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(context)
        } else {
            @Suppress("DEPRECATION")
            MediaRecorder()
        }
        return@withContext try {
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC)
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            recorder.setOutputFile(file.absolutePath)
            recorder.prepare()
            recorder.start()
            delay(durationS * 1000L)
            recorder.stop()
            recorder.release()
            StepOutcome(Step("record_audio"), true, data = "saved ${file.absolutePath}")
        } catch (e: Exception) {
            runCatching { recorder.release() }
            StepOutcome(Step("record_audio"), false, "ضبط نشد: ${e.message}")
        }
    }

    suspend fun download(url: String, filename: String?): StepOutcome = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder().url(url).build()
            http.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext StepOutcome(Step("download_file"), false, "دانلود ناموفق: HTTP ${response.code}")
                }
                val body = response.body ?: return@withContext StepOutcome(Step("download_file"), false, "پاسخ خالی بود")
                val name = filename ?: url.substringAfterLast('/').substringBefore('?').ifBlank { "download.bin" }
                val mime = body.contentType()?.toString() ?: "application/octet-stream"
                val bytes = body.bytes()
                val uri = saveToDownloads(name, mime, bytes)
                    ?: return@withContext StepOutcome(Step("download_file"), false, "ذخیره در پوشه‌ی دانلود ممکن نشد")
                StepOutcome(Step("download_file"), true, data = "saved $name (${bytes.size} bytes) to $uri")
            }
        } catch (e: Exception) {
            StepOutcome(Step("download_file"), false, "دانلود ناموفق: ${e.message}")
        }
    }

    /**
     * Resolves a direct audio URL through the relay, then downloads it.
     * If the relay has no resolver, the user gets a clear message.
     */
    suspend fun downloadAudio(query: String, bitrate: String?): StepOutcome = withContext(Dispatchers.IO) {
        val snap = settings.snapshot()
        if (snap.serverUrl.isBlank() || snap.deviceToken.isBlank()) {
            return@withContext StepOutcome(Step("download_audio"), false, "سرور تنظیم نشده است.")
        }
        try {
            val payload = Json.encodeToString(
                kotlinx.serialization.json.JsonObject.serializer(),
                kotlinx.serialization.json.buildJsonObject {
                    put("query", kotlinx.serialization.json.JsonPrimitive(query))
                    put("bitrate", kotlinx.serialization.json.JsonPrimitive(bitrate ?: "192"))
                },
            )
            val request = Request.Builder()
                .url("${snap.serverUrl}/api/resolve-audio")
                .addHeader("Authorization", "Bearer ${snap.deviceToken}")
                .post(payload.toRequestBody("application/json".toMediaType()))
                .build()

            http.newCall(request).execute().use { response ->
                val text = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val message = runCatching {
                        Json.parseToJsonElement(text).jsonObject["message"]?.jsonPrimitive?.content
                    }.getOrNull() ?: "استخراج صدا ناموفق بود (HTTP ${response.code})"
                    return@withContext StepOutcome(Step("download_audio"), false, message)
                }
                val obj = Json.parseToJsonElement(text).jsonObject
                val audioUrl = obj["audio_url"]?.jsonPrimitive?.content
                    ?: return@withContext StepOutcome(Step("download_audio"), false, "سرور آدرس صدا برنگرداند")
                val title = obj["title"]?.jsonPrimitive?.content ?: query
                val ext = obj["ext"]?.jsonPrimitive?.content ?: "m4a"
                val safeName = title.replace(Regex("[^\\p{L}\\p{N} _-]"), "_").take(60) + ".$ext"
                download(audioUrl, safeName)
            }
        } catch (e: Exception) {
            StepOutcome(Step("download_audio"), false, "استخراج صدا ناموفق بود: ${e.message}")
        }
    }

    fun installApk(path: String): StepOutcome {
        val file = File(path).takeIf { it.exists() }
            ?: File("/storage/emulated/0/Download", path).takeIf { it.exists() }
            ?: return StepOutcome(Step("install_apk"), false, "فایل APK پیدا نشد: $path")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !context.packageManager.canRequestPackageInstalls()) {
            return StepOutcome(
                Step("install_apk"), false,
                "اجازه‌ی نصب از این منبع داده نشده است. در تنظیمات فعال کنید.",
            )
        }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            StepOutcome(Step("install_apk"), true, data = "installer opened")
        } catch (e: Exception) {
            StepOutcome(Step("install_apk"), false, e.message)
        }
    }

    private fun saveToDownloads(name: String, mime: String, bytes: ByteArray): Uri? {
        val values = android.content.ContentValues().apply {
            put(android.provider.MediaStore.Downloads.DISPLAY_NAME, name)
            put(android.provider.MediaStore.Downloads.MIME_TYPE, mime)
            put(android.provider.MediaStore.Downloads.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: return null
        resolver.openOutputStream(uri)?.use { it.write(bytes) }
        values.clear()
        values.put(android.provider.MediaStore.Downloads.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        return uri
    }
}
