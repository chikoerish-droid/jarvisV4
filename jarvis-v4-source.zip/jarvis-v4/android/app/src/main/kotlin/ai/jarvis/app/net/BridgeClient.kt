package ai.jarvis.app.net

import ai.jarvis.app.data.SettingsProvider
import ai.jarvis.app.data.SettingsStore
import ai.jarvis.core.JarvisJson
import ai.jarvis.core.PlanRequest
import ai.jarvis.core.PlanResponse
import ai.jarvis.core.Planner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * The only network code in the app.
 *
 * It talks to exactly two endpoints on the user's own relay:
 *   POST /api/plan    — the brain
 *   GET  /api/health  — "Test connection"
 *
 * It sends the device token as a Bearer header. It never sends, stores or
 * knows a model key. If the server is unreachable the error is surfaced to the
 * user verbatim instead of being swallowed.
 */
class BridgeClient(private val settings: SettingsProvider) : Planner {

    private val json: Json = JarvisJson

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    override suspend fun plan(request: PlanRequest): PlanResponse = withContext(Dispatchers.IO) {
        val snap = settings.snapshot()
        if (snap.deviceToken.isBlank()) {
            throw BridgeException("توکن دستگاه تنظیم نشده است. در تنظیمات وارد کنید.")
        }
        if (snap.serverUrl.isBlank() || snap.serverUrl.contains("your-jarvis")) {
            throw BridgeException("آدرس سرور تنظیم نشده است. در تنظیمات آدرس سرور خودتان را وارد کنید.")
        }

        val payload = json.encodeToString(PlanRequest.serializer(), request)
        val body = payload.toRequestBody(JSON)
        val httpRequest = Request.Builder()
            .url("${snap.serverUrl}/api/plan")
            .addHeader("Authorization", "Bearer ${snap.deviceToken}")
            .addHeader("Content-Type", "application/json")
            .post(body)
            .build()

        http.newCall(httpRequest).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw BridgeException(describeError(response.code, text))
            }
            try {
                json.decodeFromString(PlanResponse.serializer(), text)
            } catch (e: Exception) {
                throw BridgeException("پاسخ سرور قابل خواندن نبود: ${e.message}")
            }
        }
    }

    /** "Test connection" in settings. Returns a human-readable result. */
    suspend fun health(): HealthResult = withContext(Dispatchers.IO) {
        val snap = settings.snapshot()
        if (snap.deviceToken.isBlank()) return@withContext HealthResult(false, "توکن دستگاه خالی است.")
        if (snap.serverUrl.isBlank()) return@withContext HealthResult(false, "آدرس سرور خالی است.")

        val request = Request.Builder()
            .url("${snap.serverUrl}/api/health")
            .addHeader("Authorization", "Bearer ${snap.deviceToken}")
            .get()
            .build()

        try {
            http.newCall(request).execute().use { response ->
                val text = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext HealthResult(false, describeError(response.code, text))
                }
                val obj = runCatching { json.parseToJsonElement(text).jsonObject }.getOrNull()
                    ?: return@withContext HealthResult(false, "پاسخ سرور قابل خواندن نبود.")
                val provider = obj["provider"]?.jsonPrimitive?.content ?: "?"
                val model = obj["model"]?.jsonPrimitive?.content ?: "?"
                val keyOk = obj["key_configured"]?.jsonPrimitive?.content == "true"
                if (!keyOk) {
                    return@withContext HealthResult(false, "سرور در دسترس است اما کلید مدل روی سرور تنظیم نشده.")
                }
                HealthResult(true, "متصل است — $provider / $model")
            }
        } catch (e: IOException) {
            HealthResult(false, "اتصال برقرار نشد: ${e.message}")
        }
    }

    private fun describeError(code: Int, body: String): String {
        val serverMessage = runCatching {
            json.parseToJsonElement(body).jsonObject["message"]?.jsonPrimitive?.content
        }.getOrNull()

        return when (code) {
            401 -> "توکن دستگاه پذیرفته نشد (۴۰۱). توکن را در تنظیمات بررسی کنید."
            429 -> "تعداد درخواست‌ها زیاد است (۴۲۹). کمی صبر کنید."
            500 -> serverMessage ?: "سرور تنظیم نشده است (۵۰۰)."
            502, 504 -> serverMessage ?: "مدل پاسخ نداد ($code)."
            else -> serverMessage ?: "خطای سرور ($code)."
        }
    }

    companion object {
        private val JSON = "application/json; charset=utf-8".toMediaType()
    }
}

class BridgeException(message: String) : Exception(message)

data class HealthResult(val ok: Boolean, val message: String)

/** Small helper so callers can build a device-state object without ceremony. */
fun deviceStateJson(map: Map<String, String>): JsonObject =
    JsonObject(map.mapValues { kotlinx.serialization.json.JsonPrimitive(it.value) })
