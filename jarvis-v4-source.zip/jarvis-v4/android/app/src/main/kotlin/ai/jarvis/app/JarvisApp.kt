package ai.jarvis.app

import android.app.Application
import ai.jarvis.app.data.SettingsStore
import ai.jarvis.app.net.BridgeClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Application entry point. Holds the singletons the rest of the app shares.
 *
 * There is deliberately no model key here and no way to add one: the app has
 * no field for it, no BuildConfig entry for it, and the network layer only
 * ever sends the device token. See BUILD_GUIDE.md ("Why there is no API key in
 * the APK").
 */
class JarvisApp : Application() {

    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    lateinit var settings: SettingsStore
        private set

    lateinit var bridge: BridgeClient
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        settings = SettingsStore(this)
        bridge = BridgeClient(settings)
        appScope.launch { settings.ensureDefaults() }
    }

    companion object {
        lateinit var instance: JarvisApp
            private set
    }
}
