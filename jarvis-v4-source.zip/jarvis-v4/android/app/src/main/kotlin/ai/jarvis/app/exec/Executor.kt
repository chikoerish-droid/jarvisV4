package ai.jarvis.app.exec

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import ai.jarvis.app.access.AccessibilityBridge
import ai.jarvis.core.ActionSpec
import ai.jarvis.core.Device
import ai.jarvis.core.Guard
import ai.jarvis.core.Step
import ai.jarvis.core.StepOutcome
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject

/**
 * The executor: turns a validated [Step] into a real action on the phone.
 *
 * Every action in ActionSpec is handled here or in one of the delegates
 * (DeviceActions, CommsActions, MediaActions, FileActions, SocialActions).
 * An action that is not handled returns ok=false with a clear reason — it
 * never silently does nothing, which is what made v3 feel broken.
 *
 * All failures are returned as data, never thrown, so the agent loop can feed
 * them back to the model and recover.
 */
class Executor(
    private val context: Context,
    private val screen: ScreenController,
    private val device: DeviceActions,
    private val comms: CommsActions,
    private val media: MediaActions,
    private val files: FileActions,
    private val social: SocialActions,
    private val apps: AppResolver,
) : Device {

    override suspend fun deviceState(): JsonObject = device.stateJson()

    override fun needsConfirmation(step: Step): Boolean = Guard.needsConfirmation(step)

    override suspend fun confirm(step: Step): Boolean = true // the UI layer asks; see AgentViewModel

    override suspend fun execute(step: Step): StepOutcome = withContext(Dispatchers.Main) {
        Guard.refuseReason(step)?.let { return@withContext StepOutcome(step, false, it) }

        try {
            when (step.action) {
                // ---------------------------------------------------- apps
                "open_app" -> apps.open(step.requireStr("app"))
                "open_url" -> openUrl(step.requireStr("url"))
                "open_profile" -> openProfile(step.requireStr("platform"), step.requireStr("handle"))
                "list_apps" -> apps.list()
                "back" -> screen.back()
                "home" -> screen.home()
                "recents" -> screen.recents()

                // -------------------------------------------------- screen
                "read_screen" -> screen.read()
                "screenshot" -> screen.screenshot(step.bool("full") == true)
                "tap_text" -> screen.tapText(step.requireStr("text"), step.int("index") ?: 0)
                "tap_xy" -> screen.tap(step.int("x") ?: 0, step.int("y") ?: 0)
                "long_press_text" -> screen.longPress(step.requireStr("text"))
                "scroll" -> screen.scroll(step.str("direction") ?: "down", step.str("amount") ?: "screen")
                "swipe" -> screen.swipe(
                    step.int("x1") ?: 0, step.int("y1") ?: 0,
                    step.int("x2") ?: 0, step.int("y2") ?: 0,
                    step.int("duration_ms") ?: 300,
                )
                "type_text" -> screen.type(step.requireStr("text"), step.bool("submit") == true)
                "press_key" -> screen.pressKey(step.requireStr("key"))
                "wait" -> {
                    delay((step.int("ms") ?: 500).toLong())
                    StepOutcome(step, true, data = "waited")
                }

                // -------------------------------------------------- device
                "get_device_state" -> device.state()
                "get_battery" -> device.battery()
                "set_setting" -> device.setSetting(step.requireStr("setting"), step.requireStr("value"))
                "set_ringtone" -> device.setRingtone(step.requireStr("name"))
                "toggle" -> device.toggle(step.requireStr("feature"), step.bool("on") == true)
                "set_alarm" -> device.setAlarm(
                    step.int("hour") ?: 0, step.int("minute") ?: 0, step.str("label"),
                )
                "set_timer" -> device.setTimer(step.int("seconds") ?: 60, step.str("label"))
                "add_calendar_event" -> device.addCalendarEvent(
                    step.requireStr("title"), step.requireStr("start_iso"),
                    step.int("duration_min") ?: 60, step.str("location"),
                )
                "copy_to_clipboard" -> device.copy(step.requireStr("text"))
                "share_text" -> device.share(step.requireStr("text"))
                "open_settings_page" -> device.openSettingsPage(step.requireStr("page"))

                // --------------------------------------------------- comms
                "call" -> comms.call(step.requireStr("contact"))
                "send_sms" -> comms.sms(
                    step.requireStr("contact"), step.requireStr("message"), step.bool("send") == true,
                )
                "send_whatsapp" -> comms.whatsapp(step.requireStr("contact"), step.requireStr("message"))
                "whatsapp_call" -> comms.whatsappCall(step.requireStr("contact"), step.bool("video") == true)
                "send_email" -> comms.email(
                    step.requireStr("to"), step.requireStr("subject"), step.requireStr("body"),
                )
                "open_contact" -> comms.openContact(step.requireStr("contact"))

                // --------------------------------------------------- media
                "media_control" -> media.control(step.requireStr("command"))
                "record_audio" -> media.record(step.int("duration_s") ?: 10)
                "download_file" -> media.download(step.requireStr("url"), step.str("filename"))
                "download_audio" -> media.downloadAudio(step.requireStr("query"), step.str("bitrate"))
                "install_apk" -> media.installApk(step.requireStr("path"))

                // --------------------------------------------------- files
                "list_files" -> files.list(step.str("dir") ?: "Download")
                "move_file" -> files.move(step.requireStr("from"), step.requireStr("to"))
                "copy_file" -> files.copy(step.requireStr("from"), step.requireStr("to"))
                "rename_file" -> files.rename(step.requireStr("path"), step.requireStr("new_name"))
                "delete_file" -> files.delete(step.requireStr("path"))
                "create_folder" -> files.createFolder(step.requireStr("path"))

                // -------------------------------------------------- social
                "instagram_post" -> social.instagramPost(
                    step.requireStr("caption"), step.str("media_path"), step.bool("as_story") == true,
                )
                "instagram_dm" -> social.instagramDm(step.requireStr("handle"), step.requireStr("message"))
                "x_search" -> social.xSearch(step.requireStr("query"))
                "x_post" -> social.xPost(step.requireStr("text"))

                // ----------------------------------------------- assistant
                "speak" -> StepOutcome(step, true, data = "spoken")
                "notify" -> device.notify(step.requireStr("title"), step.requireStr("body"))
                "ask_user", "pause_for_user", "finish" ->
                    StepOutcome(step, true, data = "handled_by_loop")

                else -> StepOutcome(step, false, "اکشن پشتیبانی نمی‌شود: ${step.action}")
            }
        } catch (e: Exception) {
            StepOutcome(step, false, e.message ?: e::class.simpleName)
        }
    }

    // ---------------------------------------------------------------- helpers

    private fun openUrl(url: String): StepOutcome {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return start(intent, "opened $url")
    }

    private fun openProfile(platform: String, handle: String): StepOutcome {
        val clean = handle.removePrefix("@")
        val url = when (platform) {
            "x" -> "https://x.com/$clean"
            "instagram" -> "https://instagram.com/$clean"
            "telegram" -> "https://t.me/$clean"
            "github" -> "https://github.com/$clean"
            "youtube" -> "https://youtube.com/@$clean"
            "linkedin" -> "https://linkedin.com/in/$clean"
            else -> return StepOutcome(Step("open_profile"), false, "پلتفرم ناشناخته: $platform")
        }
        return openUrl(url)
    }

    private fun start(intent: Intent, successData: String): StepOutcome {
        return try {
            context.startActivity(intent)
            StepOutcome(Step("intent"), true, data = successData)
        } catch (e: Exception) {
            StepOutcome(Step("intent"), false, "برنامه‌ای برای این کار پیدا نشد: ${e.message}")
        }
    }
}

/** Resolves an app name (Persian or English) to a launchable package. */
class AppResolver(private val context: Context) {

    private val pm get() = context.packageManager

    fun open(name: String): StepOutcome {
        val pkg = resolve(name)
            ?: return StepOutcome(Step("open_app"), false, "برنامه‌ای با نام «$name» پیدا نشد")
        val intent = pm.getLaunchIntentForPackage(pkg)
            ?: return StepOutcome(Step("open_app"), false, "برنامه $pkg اجرا نمی‌شود")
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            StepOutcome(Step("open_app"), true, data = "opened $pkg")
        } catch (e: Exception) {
            StepOutcome(Step("open_app"), false, e.message)
        }
    }

    fun resolve(name: String): String? {
        val needle = name.trim().lowercase()
        if (needle.contains('.')) return needle // already a package name

        val aliases = mapOf(
            "اینستاگرام" to "com.instagram.android",
            "instagram" to "com.instagram.android",
            "تلگرام" to "org.telegram.messenger",
            "telegram" to "org.telegram.messenger",
            "واتساپ" to "com.whatsapp",
            "whatsapp" to "com.whatsapp",
            "یوتیوب" to "com.google.android.youtube",
            "youtube" to "com.google.android.youtube",
            "توییتر" to "com.twitter.android",
            "ایکس" to "com.twitter.android",
            "twitter" to "com.twitter.android",
            "x" to "com.twitter.android",
            "اسنپ" to "cab.snapp.passenger",
            "snapp" to "cab.snapp.passenger",
            "تپسی" to "com.tapsi.tapsi",
            "tapsi" to "com.tapsi.tapsi",
            "اسنپ‌فود" to "com.snappfood",
            "دیجی‌کالا" to "com.digikala",
            "chrome" to "com.android.chrome",
            "کروم" to "com.android.chrome",
            "دوربین" to "camera",
            "camera" to "camera",
            "گالری" to "gallery",
            "gallery" to "gallery",
            "تنظیمات" to "settings",
            "settings" to "settings",
            "ماشین‌حساب" to "calculator",
            "calculator" to "calculator",
        )
        aliases[needle]?.let { alias ->
            if (alias.contains('.')) return alias
            // Generic aliases: find a package that ends with the alias.
            return launchablePackages().firstOrNull { it.contains(alias, ignoreCase = true) }
        }

        // Fuzzy: match the app label the user sees.
        val exact = launchablePackages().firstOrNull { pkg ->
            val label = runCatching {
                pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            }.getOrNull() ?: return@firstOrNull false
            label.equals(name, ignoreCase = true)
        }
        if (exact != null) return exact

        return launchablePackages().firstOrNull { pkg ->
            val label = runCatching {
                pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            }.getOrNull() ?: return@firstOrNull false
            label.contains(name, ignoreCase = true) || pkg.contains(needle, ignoreCase = true)
        }
    }

    fun list(): StepOutcome {
        val items = launchablePackages().mapNotNull { pkg ->
            val label = runCatching {
                pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            }.getOrNull() ?: return@mapNotNull null
            "$label ($pkg)"
        }.sorted()
        return StepOutcome(Step("list_apps"), true, data = items.joinToString("\n"))
    }

    private fun launchablePackages(): List<String> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            android.content.pm.PackageManager.ResolveInfoFlags.of(0)
        } else 0
        @Suppress("DEPRECATION")
        val resolved = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(intent, flags)
        } else {
            pm.queryIntentActivities(intent, 0)
        }
        return resolved.mapNotNull { it.activityInfo?.packageName }.distinct()
    }
}
