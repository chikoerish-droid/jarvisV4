package ai.jarvis.app.exec

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.app.NotificationCompat
import ai.jarvis.app.R
import ai.jarvis.app.access.AccessibilityBridge
import ai.jarvis.core.Step
import ai.jarvis.core.StepOutcome
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import java.io.File

/**
 * Device state and system settings.
 *
 * Honesty rules baked in here:
 *   - Wi-Fi / Bluetooth / airplane mode cannot be toggled silently on modern
 *     Android. We open the right panel and report "opened the panel", never
 *     "turned it on".
 *   - DND needs a policy grant; without it we say so.
 *   - Brightness needs WRITE_SETTINGS; without it we open the page.
 */
class DeviceActions(private val context: Context) {

    private val audio get() = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun stateJson(): JsonObject {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        return JsonObject(
            mapOf(
                "foregroundApp" to JsonPrimitive(AccessibilityBridge.foregroundPackage() ?: "unknown"),
                "screenOn" to JsonPrimitive(pm.isInteractive),
                "battery" to JsonPrimitive(level),
                "ringerMode" to JsonPrimitive(
                    when (audio.ringerMode) {
                        AudioManager.RINGER_MODE_SILENT -> "silent"
                        AudioManager.RINGER_MODE_VIBRATE -> "vibrate"
                        else -> "normal"
                    },
                ),
                "mediaVolume" to JsonPrimitive(
                    (audio.getStreamVolume(AudioManager.STREAM_MUSIC) * 100) /
                        audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
                ),
                "dnd" to JsonPrimitive(
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
                    } else false,
                ),
                "accessibility" to JsonPrimitive(AccessibilityBridge.isConnected()),
                "sdk" to JsonPrimitive(Build.VERSION.SDK_INT),
            ),
        )
    }

    fun state(): StepOutcome = StepOutcome(Step("get_device_state"), true, data = stateJson().toString())

    fun battery(): StepOutcome {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = bm.isCharging
        return StepOutcome(
            Step("get_battery"), true,
            data = "battery=$level% charging=$charging",
        )
    }

    fun setSetting(setting: String, value: String): StepOutcome {
        return when (setting) {
            "ringer" -> {
                val mode = when (value.lowercase()) {
                    "silent" -> AudioManager.RINGER_MODE_SILENT
                    "vibrate" -> AudioManager.RINGER_MODE_VIBRATE
                    "normal" -> AudioManager.RINGER_MODE_NORMAL
                    else -> return StepOutcome(Step("set_setting"), false, "مقدار نامعتبر: $value")
                }
                audio.ringerMode = mode
                StepOutcome(Step("set_setting"), true, data = "ringer=$value")
            }
            "media_volume" -> {
                val pct = value.toIntOrNull()
                    ?: return StepOutcome(Step("set_setting"), false, "مقدار نامعتبر: $value")
                val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                audio.setStreamVolume(AudioManager.STREAM_MUSIC, (max * pct / 100), 0)
                StepOutcome(Step("set_setting"), true, data = "volume=$pct")
            }
            "brightness" -> {
                if (!Settings.System.canWrite(context)) {
                    openSettingsPage("display")
                    return StepOutcome(
                        Step("set_setting"), false,
                        "اجازه‌ی تغییر تنظیمات سیستم داده نشده؛ صفحه‌ی نمایش باز شد.",
                    )
                }
                val pct = value.toIntOrNull()
                    ?: return StepOutcome(Step("set_setting"), false, "مقدار نامعتبر: $value")
                Settings.System.putInt(
                    context.contentResolver,
                    Settings.System.SCREEN_BRIGHTNESS,
                    (255 * pct / 100).coerceIn(0, 255),
                )
                StepOutcome(Step("set_setting"), true, data = "brightness=$pct")
            }
            "dnd" -> {
                val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !nm.isNotificationPolicyAccessGranted) {
                    context.startActivity(
                        Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    )
                    return StepOutcome(
                        Step("set_setting"), false,
                        "برای حالت مزاحم‌نشو اجازه لازم است؛ صفحه‌ی مربوطه باز شد.",
                    )
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    nm.setInterruptionFilter(
                        if (value.lowercase() == "on") NotificationManager.INTERRUPTION_FILTER_NONE
                        else NotificationManager.INTERRUPTION_FILTER_ALL,
                    )
                }
                StepOutcome(Step("set_setting"), true, data = "dnd=$value")
            }
            else -> StepOutcome(Step("set_setting"), false, "تنظیم ناشناخته: $setting")
        }
    }

    fun setRingtone(name: String): StepOutcome {
        val file = findAudioFile(name)
            ?: return StepOutcome(Step("set_ringtone"), false, "فایل «$name» پیدا نشد")
        return try {
            // ContentResolver is the only way to set a ringtone from a file on
            // API 24+; a file:// Uri here would throw FileUriExposedException.
            val values = ContentValues().apply {
                put(android.provider.MediaStore.MediaColumns.DATA, file.absolutePath)
                put(android.provider.MediaStore.MediaColumns.TITLE, file.nameWithoutExtension)
                put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "audio/*")
                put(android.provider.MediaStore.Audio.Media.IS_RINGTONE, true)
            }
            val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                android.provider.MediaStore.Audio.Media.getContentUri(
                    android.provider.MediaStore.VOLUME_EXTERNAL,
                )
            } else {
                android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            }
            val uri = context.contentResolver.insert(collection, values)
                ?: return StepOutcome(Step("set_ringtone"), false, "ثبت فایل در رسانه ممکن نشد")
            RingtoneManager.setActualDefaultRingtoneUri(context, RingtoneManager.TYPE_RINGTONE, uri)
            StepOutcome(Step("set_ringtone"), true, data = "ringtone=${file.name}")
        } catch (e: Exception) {
            StepOutcome(Step("set_ringtone"), false, "تنظیم زنگ ممکن نشد: ${e.message}")
        }
    }

    private fun findAudioFile(name: String): File? {
        val dirs = listOf(
            File(context.getExternalFilesDir(null), "ringtones"),
            File("/storage/emulated/0/Ringtones"),
            File("/storage/emulated/0/Download"),
            File("/storage/emulated/0/Music"),
        )
        for (dir in dirs) {
            dir.listFiles()?.firstOrNull { it.name.equals(name, true) }?.let { return it }
        }
        return null
    }

    fun toggle(feature: String, on: Boolean): StepOutcome {
        // These cannot be flipped silently on modern Android. We open the panel
        // and say exactly that.
        val action = when (feature) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            "mobile_data" -> Settings.ACTION_DATA_ROAMING_SETTINGS
            "dnd" -> Settings.ACTION_ZEN_MODE_SETTINGS
            "flashlight" -> null
            else -> return StepOutcome(Step("toggle"), false, "گزینه ناشناخته: $feature")
        }

        if (feature == "flashlight") {
            return StepOutcome(
                Step("toggle"), false,
                "چراغ‌قوه از طریق دسترسی مستقیم قابل کنترل نیست؛ از کاشی تنظیمات سریع استفاده کنید.",
            )
        }

        return try {
            context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            StepOutcome(
                Step("toggle"), true,
                data = "opened the $feature panel (Android does not allow silent toggling)",
            )
        } catch (e: Exception) {
            StepOutcome(Step("toggle"), false, e.message)
        }
    }

    fun setAlarm(hour: Int, minute: Int, label: String?): StepOutcome {
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            if (!label.isNullOrBlank()) putExtra(AlarmClock.EXTRA_MESSAGE, label)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            StepOutcome(Step("set_alarm"), true, data = "alarm $hour:$minute")
        } catch (e: Exception) {
            StepOutcome(Step("set_alarm"), false, "ساعت پیدا نشد: ${e.message}")
        }
    }

    fun setTimer(seconds: Int, label: String?): StepOutcome {
        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            if (!label.isNullOrBlank()) putExtra(AlarmClock.EXTRA_MESSAGE, label)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            StepOutcome(Step("set_timer"), true, data = "timer ${seconds}s")
        } catch (e: Exception) {
            StepOutcome(Step("set_timer"), false, "برنامه‌ی ساعت پیدا نشد: ${e.message}")
        }
    }

    fun addCalendarEvent(title: String, startIso: String, durationMin: Int, location: String?): StepOutcome {
        val start = runCatching { java.time.LocalDateTime.parse(startIso) }.getOrNull()
            ?: return StepOutcome(Step("add_calendar_event"), false, "زمان نامعتبر: $startIso")
        val startMillis = start.atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
        val endMillis = startMillis + durationMin * 60_000L

        val intent = Intent(Intent.ACTION_INSERT).apply {
            data = CalendarContract.Events.CONTENT_URI
            putExtra(CalendarContract.Events.TITLE, title)
            putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, startMillis)
            putExtra(CalendarContract.EXTRA_EVENT_END_TIME, endMillis)
            if (!location.isNullOrBlank()) putExtra(CalendarContract.Events.EVENT_LOCATION, location)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            StepOutcome(Step("add_calendar_event"), true, data = "calendar composer opened")
        } catch (e: Exception) {
            StepOutcome(Step("add_calendar_event"), false, e.message)
        }
    }

    fun copy(text: String): StepOutcome {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Jarvis", text))
        return StepOutcome(Step("copy_to_clipboard"), true, data = "copied")
    }

    fun share(text: String): StepOutcome {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(Intent.createChooser(intent, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            StepOutcome(Step("share_text"), true, data = "share sheet opened")
        } catch (e: Exception) {
            StepOutcome(Step("share_text"), false, e.message)
        }
    }

    fun openSettingsPage(page: String): StepOutcome {
        val action = when (page) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "app_info" -> Settings.ACTION_APPLICATION_DETAILS_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "data_usage" -> Settings.ACTION_DATA_USAGE_SETTINGS
            "notification" -> Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS
            "default_apps" -> Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        val intent = Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (page == "app_info") intent.data = Uri.parse("package:${context.packageName}")
        return try {
            context.startActivity(intent)
            StepOutcome(Step("open_settings_page"), true, data = "opened $page settings")
        } catch (e: Exception) {
            StepOutcome(Step("open_settings_page"), false, e.message)
        }
    }

    fun notify(title: String, body: String): StepOutcome {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Jarvis", NotificationManager.IMPORTANCE_DEFAULT),
            )
        }
        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .build()
        nm.notify(System.currentTimeMillis().toInt(), notification)
        return StepOutcome(Step("notify"), true, data = "notified")
    }

    /** Saves a downloaded file into the public Downloads collection. */
    fun saveToDownloads(displayName: String, mime: String, bytes: ByteArray): Uri? {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, displayName)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return null
        resolver.openOutputStream(uri)?.use { it.write(bytes) }
        values.clear()
        values.put(MediaStore.Downloads.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        return uri
    }

    companion object {
        const val CHANNEL = "jarvis_default"
    }
}
