package ai.jarvis.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ai.jarvis.app.JarvisApp
import ai.jarvis.app.access.AccessibilityBridge
import ai.jarvis.app.exec.AppResolver
import ai.jarvis.app.exec.CommsActions
import ai.jarvis.app.exec.DeviceActions
import ai.jarvis.app.exec.Executor
import ai.jarvis.app.exec.FileActions
import ai.jarvis.app.exec.MediaActions
import ai.jarvis.app.exec.ScreenController
import ai.jarvis.app.exec.SocialActions
import ai.jarvis.app.net.HealthResult
import ai.jarvis.app.voice.VoiceController
import ai.jarvis.core.AgentLoop
import ai.jarvis.core.Device
import ai.jarvis.core.RunResult
import ai.jarvis.core.Step
import ai.jarvis.core.StepOutcome
import ai.jarvis.core.StopReason
import ai.jarvis.core.Turn
import ai.jarvis.core.Ui
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * The ViewModel that wires the pure-Kotlin agent loop to the real device.
 *
 * It owns:
 *   - the conversation transcript shown in the UI
 *   - the confirmation dialog queue (the loop suspends until the user answers)
 *   - the ask_user dialog queue
 *   - the running job, so the user can stop it
 */
class AgentViewModel(app: Application) : AndroidViewModel(app) {

    private val jarvis = app as JarvisApp
    private val settings = jarvis.settings
    private val bridge = jarvis.bridge

    val voice = VoiceController(app)

    private val deviceActions = DeviceActions(app)
    private val comms = CommsActions(app)
    private val media = MediaActions(app, settings)
    private val files = FileActions(app)
    private val social = SocialActions(app)
    private val apps = AppResolver(app)

    private val screen = ScreenController(
        bridgeProvider = { AccessibilityBridge.instance },
        screenshotProvider = { ScreenCaptureHolder.latest() },
    )

    private val executor = Executor(app, screen, deviceActions, comms, media, files, social, apps)

    // ------------------------------------------------------------------ state

    data class Message(val from: String, val text: String, val kind: Kind = Kind.NORMAL) {
        enum class Kind { NORMAL, ERROR, STEP, SUCCESS }
    }

    data class PendingConfirm(val step: Step, val deferred: CompletableDeferred<Boolean>)
    data class PendingQuestion(val question: String, val options: List<String>, val secret: Boolean, val deferred: CompletableDeferred<String?>)

    private val _messages = MutableStateFlow<List<Message>>(emptyList())
    val messages: StateFlow<List<Message>> = _messages.asStateFlow()

    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running.asStateFlow()

    private val _pendingConfirm = MutableStateFlow<PendingConfirm?>(null)
    val pendingConfirm: StateFlow<PendingConfirm?> = _pendingConfirm.asStateFlow()

    private val _pendingQuestion = MutableStateFlow<PendingQuestion?>(null)
    val pendingQuestion: StateFlow<PendingQuestion?> = _pendingQuestion.asStateFlow()

    private val _health = MutableStateFlow<HealthResult?>(null)
    val health: StateFlow<HealthResult?> = _health.asStateFlow()

    private var job: Job? = null
    private val history = mutableListOf<Turn>()

    // ------------------------------------------------------------------- loop

    private val device = object : Device {
        override suspend fun execute(step: Step): StepOutcome = executor.execute(step)
        override suspend fun deviceState() = executor.deviceState()
        override fun needsConfirmation(step: Step): Boolean = executor.needsConfirmation(step)
        override suspend fun confirm(step: Step): Boolean {
            val deferred = CompletableDeferred<Boolean>()
            _pendingConfirm.value = PendingConfirm(step, deferred)
            return deferred.await()
        }
    }

    private val ui = object : Ui {
        override suspend fun say(text: String) {
            addMessage(Message("jarvis", text))
            val snap = settings.snapshot()
            if (snap.speakReplies) voice.speak(text, snap.locale)
        }

        override suspend fun askUser(question: String, options: List<String>, secret: Boolean): String? {
            val deferred = CompletableDeferred<String?>()
            _pendingQuestion.value = PendingQuestion(question, options, secret, deferred)
            return deferred.await()
        }

        override suspend fun onStep(step: Step, outcome: StepOutcome) {
            val label = describeStep(step)
            val text = if (outcome.ok) "✓ $label" else "✗ $label — ${outcome.error ?: "ناموفق"}"
            addMessage(Message("step", text, if (outcome.ok) Message.Kind.STEP else Message.Kind.ERROR))
        }
    }

    fun submit(utterance: String) {
        if (utterance.isBlank() || _running.value) return
        addMessage(Message("user", utterance))
        _running.value = true

        job = viewModelScope.launch {
            val snap = settings.snapshot()
            val loop = AgentLoop(
                planner = bridge,
                device = device,
                ui = ui,
                maxIterations = snap.maxIterations,
            )
            val result = loop.run(utterance, history.toList(), snap.locale)
            history += Turn("user", utterance)
            if (result.speech.isNotBlank()) history += Turn("assistant", result.speech)
            if (history.size > 20) history.subList(0, history.size - 20).clear()

            when (result.reason) {
                StopReason.MAX_ITERATIONS ->
                    addMessage(Message("jarvis", "به سقف مراحل رسیدم و کار تمام نشد. می‌خواهید ادامه بدهم؟", Message.Kind.ERROR))
                StopReason.FAILED ->
                    addMessage(Message("jarvis", result.speech, Message.Kind.ERROR))
                else -> Unit
            }
            _running.value = false
        }
    }

    fun stop() {
        job?.cancel()
        job = null
        _running.value = false
        _pendingConfirm.value?.deferred?.complete(false)
        _pendingConfirm.value = null
        _pendingQuestion.value?.deferred?.complete(null)
        _pendingQuestion.value = null
        voice.stop()
        addMessage(Message("jarvis", "متوقف شد."))
    }

    fun answerConfirm(approved: Boolean) {
        _pendingConfirm.value?.deferred?.complete(approved)
        _pendingConfirm.value = null
    }

    fun answerQuestion(answer: String?) {
        _pendingQuestion.value?.deferred?.complete(answer)
        _pendingQuestion.value = null
    }

    // ------------------------------------------------------------------ voice

    fun startListening() {
        viewModelScope.launch {
            val snap = settings.snapshot()
            voice.listen(snap.locale) { text -> submit(text) }
        }
    }

    fun stopListening() = voice.stop()

    // ----------------------------------------------------------------- health

    fun testConnection() {
        viewModelScope.launch {
            _health.value = null
            _health.value = bridge.health()
        }
    }

    fun clearHealth() { _health.value = null }

    // ---------------------------------------------------------------- helpers

    private fun addMessage(message: Message) {
        _messages.value = _messages.value + message
    }

    fun clearTranscript() {
        _messages.value = emptyList()
        history.clear()
    }

    private fun describeStep(step: Step): String = when (step.action) {
        "open_app" -> "باز کردن ${step.str("app")}"
        "read_screen" -> "خواندن صفحه"
        "tap_text" -> "زدن «${step.str("text")}»"
        "tap_xy" -> "زدن (${step.int("x")}, ${step.int("y")})"
        "type_text" -> "تایپ متن"
        "scroll" -> "اسکرول ${step.str("direction")}"
        "call" -> "تماس با ${step.str("contact")}"
        "send_sms" -> "پیامک به ${step.str("contact")}"
        "open_url" -> "باز کردن لینک"
        "wait" -> "صبر"
        else -> step.action
    }

    override fun onCleared() {
        super.onCleared()
        voice.release()
    }
}
