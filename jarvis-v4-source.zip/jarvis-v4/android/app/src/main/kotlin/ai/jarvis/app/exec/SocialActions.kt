package ai.jarvis.app.exec

import android.content.Context
import android.content.Intent
import android.net.Uri
import ai.jarvis.core.Step
import ai.jarvis.core.StepOutcome
import java.io.File

/**
 * Social actions.
 *
 * Instagram and X have no public posting API for third-party apps, so the
 * honest route is the official Android share intent plus on-screen finishing.
 * We never claim a post was published when it was only composed.
 */
class SocialActions(private val context: Context) {

    fun instagramPost(caption: String, mediaPath: String?, asStory: Boolean): StepOutcome {
        val media = mediaPath?.let { File(it) }?.takeIf { it.exists() }
            ?: latestGalleryItem()

        if (media == null) {
            return StepOutcome(
                Step("instagram_post"), false,
                "تصویری برای انتشار پیدا نشد. مسیر فایل را بدهید یا از گالری انتخاب کنید.",
            )
        }

        val mime = when (media.extension.lowercase()) {
            "mp4", "mov" -> "video/*"
            else -> "image/*"
        }
        // A file:// Uri into another app throws FileUriExposedException on
        // API 24+, so the media goes through our FileProvider.
        val uri = try {
            androidx.core.content.FileProvider.getUriForFile(
                context, "${context.packageName}.fileprovider", media,
            )
        } catch (e: Exception) {
            return StepOutcome(
                Step("instagram_post"), false,
                "فایل در مسیر مجاز نیست (باید داخل پوشه‌های اشتراکی باشد): ${e.message}",
            )
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, caption)
            setPackage("com.instagram.android")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            StepOutcome(
                Step("instagram_post"), true,
                data = "Instagram composer opened (${if (asStory) "story" else "feed"}); the user finishes it on screen",
            )
        } catch (e: Exception) {
            StepOutcome(Step("instagram_post"), false, "اینستاگرام نصب نیست یا باز نشد: ${e.message}")
        }
    }

    fun instagramDm(handle: String, message: String): StepOutcome {
        val clean = handle.removePrefix("@")
        // Instagram has no documented DM intent; open the profile and let the
        // on-screen flow continue.
        val uri = Uri.parse("https://instagram.com/$clean")
        return try {
            context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            StepOutcome(
                Step("instagram_dm"), true,
                data = "profile opened; continue on screen to send the DM",
            )
        } catch (e: Exception) {
            StepOutcome(Step("instagram_dm"), false, e.message)
        }
    }

    fun xSearch(query: String): StepOutcome {
        val uri = Uri.parse("https://x.com/search?q=${Uri.encode(query)}")
        return try {
            context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            StepOutcome(Step("x_search"), true, data = "search opened")
        } catch (e: Exception) {
            StepOutcome(Step("x_search"), false, e.message)
        }
    }

    fun xPost(text: String): StepOutcome {
        if (text.length > 280) {
            return StepOutcome(Step("x_post"), false, "متن بیش از ۲۸۰ کاراکتر است (${text.length}).")
        }
        val uri = Uri.parse("https://x.com/intent/tweet?text=${Uri.encode(text)}")
        return try {
            context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            StepOutcome(Step("x_post"), true, data = "composer opened; the user presses Post")
        } catch (e: Exception) {
            StepOutcome(Step("x_post"), false, e.message)
        }
    }

    private fun latestGalleryItem(): File? {
        val dir = File("/storage/emulated/0/DCIM/Camera")
        return dir.listFiles()
            ?.filter { it.isFile && it.extension.lowercase() in setOf("jpg", "jpeg", "png", "mp4") }
            ?.maxByOrNull { it.lastModified() }
    }
}
