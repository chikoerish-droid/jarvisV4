package ai.jarvis.app.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import ai.jarvis.app.ui.theme.JarvisTheme

class MainActivity : ComponentActivity() {

    private val requestPermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) { /* results are read on demand by the actions themselves */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            JarvisTheme {
                val vm: AgentViewModel = viewModel()
                val state by vm.messages.collectAsStateWithLifecycle()
                val running by vm.running.collectAsStateWithLifecycle()
                val confirm by vm.pendingConfirm.collectAsStateWithLifecycle()
                val question by vm.pendingQuestion.collectAsStateWithLifecycle()
                val health by vm.health.collectAsStateWithLifecycle()

                JarvisApp(
                    messages = state,
                    running = running,
                    pendingConfirm = confirm,
                    pendingQuestion = question,
                    health = health,
                    voice = vm.voice,
                    onSubmit = vm::submit,
                    onStop = vm::stop,
                    onListen = vm::startListening,
                    onStopListening = vm::stopListening,
                    onConfirm = vm::answerConfirm,
                    onAnswer = vm::answerQuestion,
                    onTestConnection = vm::testConnection,
                    onClearHealth = vm::clearHealth,
                    onClearTranscript = vm::clearTranscript,
                    onRequestPermissions = {
                        requestPermissions.launch(
                            arrayOf(
                                android.Manifest.permission.RECORD_AUDIO,
                                android.Manifest.permission.CALL_PHONE,
                                android.Manifest.permission.SEND_SMS,
                                android.Manifest.permission.READ_CONTACTS,
                                android.Manifest.permission.POST_NOTIFICATIONS,
                            ),
                        )
                    },
                )
            }
        }
    }
}
