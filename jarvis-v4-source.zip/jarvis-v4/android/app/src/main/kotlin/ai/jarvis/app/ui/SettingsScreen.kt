package ai.jarvis.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ai.jarvis.app.JarvisApp
import ai.jarvis.app.access.AccessibilityBridge
import kotlinx.coroutines.launch

/**
 * Settings.
 *
 * Every field here is something the user must supply or grant. There is no
 * model key field, because the app never holds one — that is the whole point
 * of the relay architecture. The screen says so explicitly so nobody goes
 * looking for it.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val app = context.applicationContext as JarvisApp
    val settings = app.settings
    val scope = rememberCoroutineScope()

    var serverUrl by remember { mutableStateOf("") }
    var token by remember { mutableStateOf("") }
    var locale by remember { mutableStateOf("fa-IR") }
    var speak by remember { mutableStateOf(true) }
    var confirmRisky by remember { mutableStateOf(true) }
    var autoListen by remember { mutableStateOf(false) }
    var maxIterations by remember { mutableStateOf(6f) }
    var saved by remember { mutableStateOf(false) }
    val accessibilityOn by AccessibilityBridge.connected.collectAsStateSafe()

    LaunchedEffect(Unit) {
        val snap = settings.snapshot()
        serverUrl = snap.serverUrl
        token = snap.deviceToken
        locale = snap.locale
        speak = snap.speakReplies
        confirmRisky = snap.confirmRisky
        autoListen = snap.autoListen
        maxIterations = snap.maxIterations.toFloat()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("تنظیمات") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            SectionTitle("سرور")
            OutlinedTextField(
                value = serverUrl,
                onValueChange = { serverUrl = it },
                label = { Text("آدرس سرور") },
                placeholder = { Text("https://your-jarvis.vercel.app") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Next),
            )
            OutlinedTextField(
                value = token,
                onValueChange = { token = it },
                label = { Text("توکن دستگاه") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
            )
            Text(
                "این توکن فقط اجازه‌ی اتصال این گوشی به سرور شماست. کلید مدل هرگز روی گوشی نیست.",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            Button(
                onClick = {
                    scope.launch {
                        settings.setServerUrl(serverUrl)
                        settings.setDeviceToken(token)
                        settings.setLocale(locale)
                        settings.setSpeakReplies(speak)
                        settings.setConfirmRisky(confirmRisky)
                        settings.setAutoListen(autoListen)
                        settings.setMaxIterations(maxIterations.toInt())
                        saved = true
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text(if (saved) "ذخیره شد ✓" else "ذخیره") }

            SectionTitle("دسترسی‌ها")
            SettingRow(
                title = "سرویس دسترسی (Accessibility)",
                subtitle = if (accessibilityOn) "فعال است" else "خاموش است — بدون آن Jarvis صفحه را نمی‌بیند",
            ) {
                TextButton(onClick = {
                    context.startActivity(
                        android.content.Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)
                            .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK),
                    )
                }) { Text("باز کردن") }
            }
            SettingRow(
                title = "ضبط صفحه",
                subtitle = "برای دیدن تصاویر و ویدیوها لازم است",
            ) {
                TextButton(onClick = {
                    context.startActivity(
                        android.content.Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
                            .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK),
                    )
                }) { Text("باز کردن") }
            }

            SectionTitle("رفتار")
            SettingRow(title = "خواندن پاسخ‌ها با صدا", subtitle = null) {
                Switch(checked = speak, onCheckedChange = { speak = it })
            }
            SettingRow(title = "تأیید قبل از کارهای حساس", subtitle = "تماس، ارسال، حذف، نصب") {
                Switch(checked = confirmRisky, onCheckedChange = { confirmRisky = it })
            }
            SettingRow(title = "گوش دادن خودکار در شروع", subtitle = null) {
                Switch(checked = autoListen, onCheckedChange = { autoListen = it })
            }

            SectionTitle("زبان")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("fa-IR" to "فارسی", "en-US" to "English").forEach { (tag, label) ->
                    Button(
                        onClick = { locale = tag },
                        enabled = locale != tag,
                    ) { Text(label) }
                }
            }

            SectionTitle("سقف مراحل")
            Text("حداکثر ${maxIterations.toInt()} مرحله برای هر فرمان", fontSize = 12.sp)
            Slider(
                value = maxIterations,
                onValueChange = { maxIterations = it },
                valueRange = 1f..20f,
                steps = 18,
            )

            SectionTitle("درباره")
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(14.dp)) {
                    Text("Jarvis 2.0.0", fontSize = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "مغز روی سرور شماست. گوشی فقط می‌شنود، می‌بیند و انجام می‌دهد. " +
                            "هیچ کلید مدلی داخل این برنامه نیست.",
                        fontSize = 11.sp,
                    )
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 8.dp),
    )
}

@Composable
private fun SettingRow(title: String, subtitle: String?, trailing: @Composable () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp)
            if (subtitle != null) {
                Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        trailing()
    }
}

@Composable
private fun <T> kotlinx.coroutines.flow.StateFlow<T>.collectAsStateSafe() =
    androidx.lifecycle.compose.collectAsStateWithLifecycle()
