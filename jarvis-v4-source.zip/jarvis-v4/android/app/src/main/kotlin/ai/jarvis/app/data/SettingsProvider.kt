package ai.jarvis.app.data

/**
 * The read side of the settings, as an interface.
 *
 * This exists so the network layer can be unit tested without an Android
 * Context. SettingsStore is the real implementation; the tests use a plain
 * data holder.
 */
interface SettingsProvider {
    suspend fun snapshot(): SettingsStore.Snapshot
}
