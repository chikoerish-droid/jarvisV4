package ai.jarvis.app.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale

/**
 * Speech in and out.
 *
 * Uses the platform SpeechRecognizer and TextToSpeech, so there is no extra
 * key and no extra service. Persian is supported when the device has a
 * Persian recognizer; if it does not, we say so instead of silently
 * transcribing nothing.
 */
class VoiceController(private val context: Context) {

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    val listening = MutableStateFlow(false)
    val partial = MutableStateFlow("")
    val error = MutableStateFlow<String?>(null)

    fun initTts(localeTag: String) {
        if (tts != null) {
            tts?.language = Locale.forLanguageTag(localeTag)
            return
        }
        tts = TextToSpeech(context) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) tts?.language = Locale.forLanguageTag(localeTag)
        }
    }

    fun speak(text: String, localeTag: String) {
        if (text.isBlank()) return
        if (!ttsReady) initTts(localeTag)
        tts?.language = Locale.forLanguageTag(localeTag)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    fun stopSpeaking() {
        tts?.stop()
    }

    fun isSpeechAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    /**
     * Starts listening. [onResult] is called once with the final transcript.
     * Errors are surfaced through [error] so the UI can show them.
     */
    fun listen(localeTag: String, onResult: (String) -> Unit) {
        if (!isSpeechAvailable()) {
            error.value = "موتور تشخیص گفتار روی این دستگاه در دسترس نیست."
            return
        }
        stop()

        val r = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer = r

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, localeTag)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, localeTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500)
        }

        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                listening.value = true
                error.value = null
                partial.value = ""
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                listening.value = false
            }

            override fun onError(errorCode: Int) {
                listening.value = false
                error.value = when (errorCode) {
                    SpeechRecognizer.ERROR_NO_MATCH -> "چیزی نشنیدم. دوباره بگویید."
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "صدایی نیامد."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "اجازه‌ی میکروفون داده نشده است."
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                        "تشخیص گفتار به شبکه نیاز دارد و اتصال برقرار نشد."
                    else -> "خطای تشخیص گفتار ($errorCode)."
                }
            }

            override fun onResults(results: Bundle?) {
                listening.value = false
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    ?.trim()
                    .orEmpty()
                if (text.isNotEmpty()) onResult(text)
                else error.value = "چیزی نشنیدم."
            }

            override fun onPartialResults(partialResults: Bundle?) {
                partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    ?.let { partial.value = it }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        r.startListening(intent)
    }

    fun stop() {
        recognizer?.let {
            runCatching { it.stopListening() }
            runCatching { it.destroy() }
        }
        recognizer = null
        listening.value = false
    }

    fun release() {
        stop()
        tts?.shutdown()
        tts = null
        ttsReady = false
    }
}
