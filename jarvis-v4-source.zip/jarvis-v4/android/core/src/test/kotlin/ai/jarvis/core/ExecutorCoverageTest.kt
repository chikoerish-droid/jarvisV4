package ai.jarvis.core

import java.io.File
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

/**
 * Static coverage check between the action vocabulary and the Android executor.
 *
 * The Android SDK is not available in every build environment (CI, a fresh
 * laptop before Android Studio is set up), so the :app module's own tests
 * cannot always run. This test does not need Android: it parses Executor.kt as
 * text and asserts that
 *
 *   - every action in ActionSpec has a branch in Executor's `when`, and
 *   - Executor has no branch for an action that is not in ActionSpec.
 *
 * It is the cheap safety net that catches "I added an action but forgot to
 * implement it", which is exactly the class of drift the v3 gap review found.
 */
class ExecutorCoverageTest {

    private val executorPath = File("../app/src/main/kotlin/ai/jarvis/app/exec/Executor.kt")

    private fun handledActions(): Set<String> {
        val full = executorPath.readText()
        // Only the body of execute() dispatches action names; other `when`
        // blocks in the file switch on settings keys, platforms or keys.
        val start = full.indexOf("override suspend fun execute")
        val end = full.indexOf("// ---------------------------------------------------------------- helpers")
        require(start in 0 until end) { "could not locate the execute() body in Executor.kt" }
        val src = full.substring(start, end)

        // Matches both `"a" -> ...` and `"a", "b", "c" -> ...`
        val re = Regex("\"([a-z][a-z0-9_]*)\"(?:\\s*,\\s*\"[a-z][a-z0-9_]*\")*\\s*->")
        val out = mutableSetOf<String>()
        for (m in re.findAll(src)) {
            Regex("\"([a-z][a-z0-9_]*)\"").findAll(m.value).forEach { out += it.groupValues[1] }
        }
        return out
    }

    @Test
    fun `the executor source exists`() {
        assertTrue(
            executorPath.exists(),
            "Executor.kt not found at ${executorPath.absolutePath} (working dir: ${File(".").absolutePath})",
        )
    }

    @Test
    fun `every declared action has a branch in the executor`() {
        val handled = handledActions()
        val missing = ActionSpec.allWireNames.filter { it !in handled }
        assertEquals(
            emptyList(), missing,
            "ActionSpec declares actions the executor does not handle: ${missing.joinToString()}",
        )
    }

    @Test
    fun `the executor has no branch for an undeclared action`() {
        val handled = handledActions()
        val declared = ActionSpec.allWireNames.toSet()
        // Loop-level actions are handled inside AgentLoop, and the executor also
        // has internal non-action branches; exclude anything not in the enum
        // that is clearly internal.
        val internal = setOf("intent", "screen")
        val extra = handled.filter { it !in declared && it !in internal }
        assertEquals(
            emptyList(), extra,
            "Executor handles actions that are not in ActionSpec: ${extra.joinToString()}",
        )
    }

    @Test
    fun `the executor dispatches a meaningful number of actions`() {
        val handled = handledActions()
        assertTrue(handled.size >= 45, "only ${handled.size} branches found — parsing may be wrong")
    }
}
