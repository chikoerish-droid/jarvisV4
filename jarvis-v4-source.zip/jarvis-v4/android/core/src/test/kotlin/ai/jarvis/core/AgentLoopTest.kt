package ai.jarvis.core

import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

/**
 * Tests for the observe -> replan loop. These are the tests that would have
 * caught the v3 "it only runs the first plan" bug.
 */

private class FakePlanner(private val responses: MutableList<PlanResponse>) : Planner {
    val requests = mutableListOf<PlanRequest>()
    override suspend fun plan(request: PlanRequest): PlanResponse {
        requests += request
        return if (responses.isEmpty()) PlanResponse(speech = "تمام", done = true)
        else responses.removeAt(0)
    }
}

private class FakeDevice(
    private val results: MutableMap<String, StepOutcome> = mutableMapOf(),
    private val confirmAnswer: Boolean = true,
) : Device {
    val executed = mutableListOf<Step>()
    val confirmed = mutableListOf<Step>()

    override suspend fun execute(step: Step): StepOutcome {
        executed += step
        return results[step.action] ?: StepOutcome(step, ok = true)
    }

    override suspend fun deviceState(): JsonObject =
        JsonObject(mapOf("foregroundApp" to JsonPrimitive("com.test")))

    override fun needsConfirmation(step: Step): Boolean = Guard.needsConfirmation(step)

    override suspend fun confirm(step: Step): Boolean {
        confirmed += step
        return confirmAnswer
    }
}

private class FakeUi : Ui {
    val spoken = mutableListOf<String>()
    val asked = mutableListOf<String>()
    var answer: String? = "پاسخ کاربر"

    override suspend fun say(text: String) { spoken += text }
    override suspend fun askUser(question: String, options: List<String>, secret: Boolean): String? {
        asked += question
        return answer
    }
    override suspend fun onStep(step: Step, outcome: StepOutcome) { /* no-op */ }
}

private fun step(action: String, vararg params: Pair<String, String>) =
    Step(action, params.associate { it.first to JsonPrimitive(it.second) })

class AgentLoopTest {

    @Test
    fun `a single plan that finishes stops after one iteration`() = runTest {
        val planner = FakePlanner(mutableListOf(
            PlanResponse(speech = "باز کردم", steps = listOf(step("open_app", "app" to "Instagram")), done = true),
        ))
        val device = FakeDevice()
        val ui = FakeUi()
        val loop = AgentLoop(planner, device, ui)

        val result = loop.run("اینستاگرام را باز کن")

        assertEquals(StopReason.DONE, result.reason)
        assertEquals(1, result.iterations)
        assertEquals(1, device.executed.size)
        assertEquals("باز کردم", result.speech)
    }

    @Test
    fun `the loop replans after observing the screen`() = runTest {
        // THE v3 BUG: v3 would stop after the first plan. This asserts the
        // second plan is actually requested, with the screen data attached.
        val planner = FakePlanner(mutableListOf(
            PlanResponse(
                speech = "صفحه را می‌خوانم",
                steps = listOf(step("read_screen")),
            ),
            PlanResponse(
                speech = "دکمه را زدم",
                steps = listOf(step("tap_text", "text" to "جستجو")),
                done = true,
            ),
        ))
        val device = FakeDevice(mutableMapOf(
            "read_screen" to StepOutcome(step("read_screen"), ok = true, data = "[button] جستجو"),
        ))
        val ui = FakeUi()
        val loop = AgentLoop(planner, device, ui)

        val result = loop.run("جستجو کن")

        assertEquals(StopReason.DONE, result.reason)
        assertEquals(2, result.iterations)
        assertEquals(2, planner.requests.size)

        // The second request must be a continuation carrying the observation.
        val second = planner.requests[1]
        assertEquals("step", second.mode)
        assertEquals("read_screen", second.observation?.action)
        assertEquals("[button] جستجو", second.observation?.data)
    }

    @Test
    fun `a failed step is fed back so the model can recover`() = runTest {
        val planner = FakePlanner(mutableListOf(
            // Two steps: the first fails, so the second must NOT run blindly.
            PlanResponse(speech = "می‌زنم", steps = listOf(
                step("tap_text", "text" to "خرید"),
                step("back"),
            )),
            PlanResponse(speech = "دوباره تلاش می‌کنم", steps = listOf(step("read_screen"))),
            PlanResponse(speech = "تمام", done = true),
        ))
        val device = FakeDevice(mutableMapOf(
            "tap_text" to StepOutcome(step("tap_text"), ok = false, error = "element_not_found"),
        ))
        val loop = AgentLoop(planner, device, FakeUi())

        val result = loop.run("خرید کن")

        assertEquals(StopReason.DONE, result.reason)
        val second = planner.requests[1]
        assertEquals(false, second.observation?.ok)
        assertEquals("element_not_found", second.observation?.error)
        // The rest of the failed plan is abandoned, not run blind.
        assertTrue(device.executed.none { it.action == "back" }, "the step after a failure must not run")
        // The model's recovery step did run.
        assertTrue(device.executed.any { it.action == "read_screen" })
    }

    @Test
    fun `a high-risk step asks for confirmation and is skipped when declined`() = runTest {
        val planner = FakePlanner(mutableListOf(
            PlanResponse(speech = "تماس می‌گیرم", steps = listOf(step("call", "contact" to "علی"))),
            PlanResponse(speech = "لغو شد", done = true),
        ))
        val device = FakeDevice(confirmAnswer = false)
        val loop = AgentLoop(planner, device, FakeUi())

        val result = loop.run("به علی زنگ بزن")

        assertEquals(1, device.confirmed.size)
        assertEquals(0, device.executed.size, "a declined step must never execute")
        assertTrue(result.outcomes.any { it.skipped })
    }

    @Test
    fun `a confirmed high-risk step executes`() = runTest {
        val planner = FakePlanner(mutableListOf(
            PlanResponse(speech = "تماس می‌گیرم", steps = listOf(step("call", "contact" to "علی")), done = true),
        ))
        val device = FakeDevice(confirmAnswer = true)
        val loop = AgentLoop(planner, device, FakeUi())

        loop.run("به علی زنگ بزن")

        assertEquals(1, device.confirmed.size)
        assertEquals(1, device.executed.size)
    }

    @Test
    fun `ask_user pauses, collects the answer and continues`() = runTest {
        val planner = FakePlanner(mutableListOf(
            PlanResponse(
                speech = "رمز را بپرس",
                steps = listOf(Step("ask_user", mapOf("question" to JsonPrimitive("رمز کارت؟"), "secret" to JsonPrimitive(true)))),
            ),
            PlanResponse(speech = "انجام شد", done = true),
        ))
        val ui = FakeUi().apply { answer = "1234" }
        val loop = AgentLoop(planner, FakeDevice(), ui)

        val result = loop.run("پرداخت کن")

        assertEquals(StopReason.DONE, result.reason)
        assertEquals(listOf("رمز کارت؟"), ui.asked)
        // The answer is carried into the next request as an observation.
        assertEquals("1234", planner.requests[1].observation?.data)
    }

    @Test
    fun `pause_for_user stops the run and reports why`() = runTest {
        val planner = FakePlanner(mutableListOf(
            PlanResponse(
                speech = "به صفحه پرداخت رسیدیم",
                steps = listOf(Step("pause_for_user", mapOf("reason" to JsonPrimitive("کرایه ۸۵ هزار تومان است؛ تایید کنید")))),
            ),
        ))
        val loop = AgentLoop(planner, FakeDevice(), FakeUi())

        val result = loop.run("اسنپ بگیر")

        assertEquals(StopReason.NEEDS_USER, result.reason)
        assertTrue(result.speech.contains("۸۵"))
    }

    @Test
    fun `finish ends the run with the model's summary`() = runTest {
        val planner = FakePlanner(mutableListOf(
            PlanResponse(
                speech = "دارم تمام می‌کنم",
                steps = listOf(Step("finish", mapOf("summary" to JsonPrimitive("پیام ارسال شد")))),
            ),
        ))
        val loop = AgentLoop(planner, FakeDevice(), FakeUi())

        val result = loop.run("پیام بفرست")

        assertEquals(StopReason.DONE, result.reason)
        assertEquals("پیام ارسال شد", result.speech)
    }

    @Test
    fun `the iteration cap is enforced and reported honestly`() = runTest {
        // A model that never finishes must not loop forever.
        val responses = MutableList(20) {
            PlanResponse(speech = "ادامه", steps = listOf(step("read_screen")))
        }
        val planner = FakePlanner(responses)
        val loop = AgentLoop(planner, FakeDevice(), FakeUi(), maxIterations = 3)

        val result = loop.run("کاری کن")

        assertEquals(StopReason.MAX_ITERATIONS, result.reason)
        assertEquals(3, result.iterations)
        assertEquals(3, planner.requests.size)
    }

    @Test
    fun `a network failure stops the run with a real error, not a fake success`() = runTest {
        val planner = object : Planner {
            override suspend fun plan(request: PlanRequest): PlanResponse = throw RuntimeException("timeout")
        }
        val loop = AgentLoop(planner, FakeDevice(), FakeUi())

        val result = loop.run("سلام")

        assertEquals(StopReason.FAILED, result.reason)
        assertTrue(result.speech.contains("timeout"))
    }

    @Test
    fun `an empty plan is treated as done`() = runTest {
        val planner = FakePlanner(mutableListOf(PlanResponse(speech = "چیزی برای انجام نبود", steps = emptyList())))
        val loop = AgentLoop(planner, FakeDevice(), FakeUi())

        val result = loop.run("هیچ")

        assertEquals(StopReason.DONE, result.reason)
    }

    @Test
    fun `history is carried into the request`() = runTest {
        val planner = FakePlanner(mutableListOf(PlanResponse(speech = "باشه", done = true)))
        val loop = AgentLoop(planner, FakeDevice(), FakeUi())

        loop.run("و بعدش؟", history = listOf(Turn("user", "اینستاگرام را باز کن"), Turn("assistant", "باز شد")))

        val req = planner.requests.first()
        assertTrue(req.history.any { it.content == "اینستاگرام را باز کن" })
        assertTrue(req.history.any { it.content == "باز شد" })
    }

    @Test
    fun `steps per plan are capped so one bad plan cannot run away`() = runTest {
        val many = (1..20).map { step("back") }
        val planner = FakePlanner(mutableListOf(
            PlanResponse(speech = "x", steps = many),
            PlanResponse(speech = "y", done = true),
        ))
        val device = FakeDevice()
        val loop = AgentLoop(planner, device, FakeUi(), maxStepsPerPlan = 5)

        loop.run("برگرد")

        assertEquals(5, device.executed.size)
    }
}
