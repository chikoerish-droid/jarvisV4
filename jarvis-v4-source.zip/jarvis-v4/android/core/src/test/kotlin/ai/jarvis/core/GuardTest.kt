package ai.jarvis.core

import kotlinx.serialization.json.JsonPrimitive
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

class GuardTest {

    private fun step(action: String, vararg params: Pair<String, String>) =
        Step(action, params.associate { it.first to JsonPrimitive(it.second) })

    @Test
    fun `every action the server can send is known to the device`() {
        // The server's list is the contract. If this fails, the two halves have
        // drifted and the app would silently ignore a real action.
        val serverActions = listOf(
            "open_app", "open_url", "open_profile", "list_apps", "back", "home", "recents",
            "read_screen", "screenshot", "tap_text", "tap_xy", "long_press_text", "scroll",
            "swipe", "type_text", "press_key", "wait",
            "get_device_state", "get_battery", "set_setting", "set_ringtone", "toggle",
            "set_alarm", "set_timer", "add_calendar_event", "copy_to_clipboard", "share_text",
            "open_settings_page",
            "call", "send_sms", "send_whatsapp", "whatsapp_call", "send_email", "open_contact",
            "media_control", "record_audio", "download_file", "download_audio", "install_apk",
            "list_files", "move_file", "copy_file", "rename_file", "delete_file", "create_folder",
            "instagram_post", "instagram_dm", "x_search", "x_post",
            "ask_user", "pause_for_user", "speak", "notify", "finish",
        )
        for (name in serverActions) {
            assertNotNull(ActionSpec.of(name), "device does not know the action \"$name\"")
        }
        assertEquals(serverActions.size, ActionSpec.allWireNames.size, "device has extra actions the server cannot send")
    }

    @Test
    fun `unknown actions are refused with a reason`() {
        val reason = Guard.refuseReason(step("format_disk"))
        assertNotNull(reason)
        assertTrue(reason.contains("format_disk"))
    }

    @Test
    fun `http urls are refused, https is allowed`() {
        assertNotNull(Guard.refuseReason(step("open_url", "url" to "http://example.com")))
        assertNull(Guard.refuseReason(step("open_url", "url" to "https://example.com")))
    }

    @Test
    fun `javascript and intent urls are refused`() {
        assertNotNull(Guard.refuseReason(step("open_url", "url" to "javascript:alert(1)")))
        assertNotNull(Guard.refuseReason(step("open_url", "url" to "intent://evil")))
        assertNotNull(Guard.refuseReason(step("open_url", "url" to "file:///etc/passwd")))
    }

    @Test
    fun `high risk actions always need confirmation`() {
        for (name in listOf("call", "send_sms", "delete_file", "install_apk", "instagram_post", "x_post")) {
            assertTrue(Guard.needsConfirmation(step(name)), "$name must need confirmation")
        }
    }

    @Test
    fun `a server flag can force confirmation on a low risk action`() {
        val s = Step("open_app", mapOf("app" to JsonPrimitive("X")), confirmBefore = true)
        assertTrue(Guard.needsConfirmation(s))
    }

    @Test
    fun `a plain read is safe`() {
        assertTrue(Guard.isSafe(step("read_screen")))
        assertFalse(Guard.isSafe(step("call", "contact" to "x")))
    }

    @Test
    fun `an over-long type_text is refused`() {
        val long = "x".repeat(5000)
        assertNotNull(Guard.refuseReason(step("type_text", "text" to long)))
    }

    @Test
    fun `every declared action is either implemented or explicitly listed`() {
        // This is the honesty check: nothing is silently missing.
        val notImplemented = ActionSpec.notImplemented
        // Currently everything is implemented; if that changes the README must
        // list it, and this test documents the expectation.
        assertEquals(emptyList(), notImplemented)
    }
}
