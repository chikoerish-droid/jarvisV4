package ai.jarvis.core

import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertNull
import kotlin.test.assertTrue

class ProtocolTest {

    @Test
    fun `parses a real server response with numeric parameters`() {
        // This is the exact shape the server sends. v3 crashed here because it
        // deserialized params as Map<String, String>.
        val json = """
            {
              "requestId": "abc123",
              "mode": "plan",
              "speech": "باشه، بازش می‌کنم",
              "steps": [
                {"action": "open_app", "params": {"app": "اینستاگرام"}},
                {"action": "tap_xy", "params": {"x": 540, "y": 1200}},
                {"action": "wait", "params": {"ms": 800}},
                {"action": "type_text", "params": {"text": "سلام", "submit": true}}
              ],
              "needsUser": false,
              "done": false,
              "provider": "gemini",
              "model": "gemini-2.5-flash",
              "dropped": []
            }
        """.trimIndent()

        val response = JarvisJson.decodeFromString<PlanResponse>(json)

        assertEquals("باشه، بازش می‌کنم", response.speech)
        assertEquals(4, response.steps.size)
        assertEquals("اینستاگرام", response.steps[0].str("app"))
        assertEquals(540, response.steps[1].int("x"))
        assertEquals(1200, response.steps[1].int("y"))
        assertEquals(800, response.steps[2].int("ms"))
        assertEquals("سلام", response.steps[3].str("text"))
        assertEquals(true, response.steps[3].bool("submit"))
    }

    @Test
    fun `numeric parameters sent as strings still parse`() {
        val step = Step("tap_xy", mapOf("x" to JsonPrimitive("540"), "y" to JsonPrimitive("1200")))
        assertEquals(540, step.int("x"))
        assertEquals(1200, step.int("y"))
    }

    @Test
    fun `a double where an int is expected is truncated, not crashed`() {
        val step = Step("wait", mapOf("ms" to JsonPrimitive(800.7)))
        assertEquals(800, step.int("ms"))
    }

    @Test
    fun `missing parameters return null instead of throwing`() {
        val step = Step("tap_text", emptyMap())
        assertNull(step.str("text"))
        assertNull(step.int("index"))
        assertNull(step.bool("submit"))
    }

    @Test
    fun `requireStr throws a typed exception naming the action and parameter`() {
        val step = Step("tap_text", emptyMap())
        val e = assertFailsWith<MissingParamException> { step.requireStr("text") }
        assertTrue(e.message!!.contains("tap_text"))
        assertTrue(e.message!!.contains("text"))
    }

    @Test
    fun `unknown fields from a newer server are ignored`() {
        val json = """{"speech":"x","steps":[],"someFutureField":42}"""
        val response = JarvisJson.decodeFromString<PlanResponse>(json)
        assertEquals("x", response.speech)
    }

    @Test
    fun `confirm_before maps to confirmBefore`() {
        val json = """{"action":"call","params":{"contact":"علی"},"confirm_before":true}"""
        val step = JarvisJson.decodeFromString<Step>(json)
        assertTrue(step.confirmBefore)
    }

    @Test
    fun `a request serializes with the fields the server expects`() {
        val request = PlanRequest(
            utterance = "سلام",
            mode = "plan",
            locale = "fa-IR",
            iteration = 0,
            history = listOf(Turn("user", "سلام")),
            deviceState = buildJsonObject { put("foregroundApp", "com.android.chrome") },
        )
        val text = JarvisJson.encodeToString(PlanRequest.serializer(), request)
        assertTrue(text.contains("\"utterance\":\"سلام\""))
        assertTrue(text.contains("\"mode\":\"plan\""))
        assertTrue(text.contains("com.android.chrome"))
        // Nulls are omitted so the payload stays small.
        assertTrue(!text.contains("screenImage"))
    }
}
