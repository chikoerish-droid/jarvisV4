package ai.jarvis.core

import kotlinx.coroutines.CancellationException

/**
 * The agent loop — the single most important fix over v3.
 *
 * v3 ran `plan.steps` once and stopped. `read_screen` existed but its result
 * was thrown away, so a plan that mis-targeted a button failed permanently and
 * the model never saw the screen. That is why the app felt like "an offline
 * app with a fixed command list".
 *
 * This loop is:
 *
 *     plan -> execute steps -> collect observations -> replan -> ...
 *
 * and it stops for exactly one of five reasons, all of which are reported to
 * the user honestly:
 *
 *   DONE            the model said the task is finished
 *   NEEDS_USER      the model asked a question (ask_user / pause_for_user)
 *   MAX_ITERATIONS  the budget ran out — we say so, we do not pretend
 *   FAILED          a step failed and the model could not recover
 *   CANCELLED       the user stopped it
 *
 * It is pure Kotlin with injected dependencies, so the whole thing is unit
 * tested without a phone (see AgentLoopTest).
 */

/** What the loop needs from the network. */
interface Planner {
    suspend fun plan(request: PlanRequest): PlanResponse
}

/** What the loop needs from the device. */
interface Device {
    /** Runs one step. Must never throw; failures come back as ok=false. */
    suspend fun execute(step: Step): StepOutcome

    /** Current device state, or null when it cannot be read. */
    suspend fun deviceState(): kotlinx.serialization.json.JsonObject?

    /** True when the step needs a human "yes" before it may run. */
    fun needsConfirmation(step: Step): Boolean

    /** Asks the user to confirm. Returns false to skip the step. */
    suspend fun confirm(step: Step): Boolean
}

/** What the loop needs from the user interface. */
interface Ui {
    suspend fun say(text: String)
    suspend fun askUser(question: String, options: List<String>, secret: Boolean): String?
    suspend fun onStep(step: Step, outcome: StepOutcome)
}

class AgentLoop(
    private val planner: Planner,
    private val device: Device,
    private val ui: Ui,
    private val maxIterations: Int = 6,
    private val maxStepsPerPlan: Int = 8,
) {

    /**
     * Runs one user command to completion.
     *
     * @param utterance what the user said
     * @param history   previous turns, oldest first
     * @param locale    BCP-47 tag, e.g. "fa-IR"
     */
    suspend fun run(
        utterance: String,
        history: List<Turn> = emptyList(),
        locale: String = "fa-IR",
    ): RunResult {
        val outcomes = mutableListOf<StepOutcome>()
        val conversation = history.toMutableList()
        conversation += Turn("user", utterance)

        var iteration = 0
        var lastSpeech = ""
        var observation: Observation? = null
        var mode = "plan"

        while (iteration < maxIterations) {
            iteration++

            val request = PlanRequest(
                utterance = if (mode == "plan") utterance else "",
                mode = mode,
                locale = locale,
                iteration = iteration - 1,
                history = conversation.takeLast(12),
                deviceState = runCatching { device.deviceState() }.getOrNull(),
                observation = observation,
            )

            val response = try {
                planner.plan(request)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                return RunResult(
                    reason = StopReason.FAILED,
                    speech = lastSpeech.ifBlank { "ارتباط با سرور برقرار نشد: ${e.message}" },
                    outcomes = outcomes,
                    iterations = iteration,
                )
            }

            if (response.speech.isNotBlank()) {
                lastSpeech = response.speech
                ui.say(response.speech)
                conversation += Turn("assistant", response.speech)
            }

            if (response.needsUser) {
                return RunResult(StopReason.NEEDS_USER, lastSpeech, outcomes, iteration)
            }
            if (response.done && response.steps.isEmpty()) {
                return RunResult(StopReason.DONE, lastSpeech, outcomes, iteration)
            }
            if (response.steps.isEmpty()) {
                return RunResult(StopReason.DONE, lastSpeech, outcomes, iteration)
            }

            // Execute this plan's steps, collecting observations.
            var pendingObservation: Observation? = null
            var askedUser = false
            var finished = false

            for (step in response.steps.take(maxStepsPerPlan)) {
                if (step.action == "finish") {
                    val summary = step.str("summary") ?: lastSpeech
                    if (summary.isNotBlank()) {
                        lastSpeech = summary
                        ui.say(summary)
                    }
                    finished = true
                    break
                }

                if (step.action == "ask_user") {
                    val question = step.str("question") ?: "?"
                    val options = step.str("options")
                        ?.split(',')
                        ?.map { it.trim() }
                        ?.filter { it.isNotEmpty() }
                        ?: emptyList()
                    val answer = ui.askUser(question, options, step.bool("secret") == true)
                    if (answer == null) {
                        return RunResult(StopReason.CANCELLED, lastSpeech, outcomes, iteration)
                    }
                    conversation += Turn("user", answer)
                    pendingObservation = Observation("ask_user", true, data = answer)
                    askedUser = true
                    break
                }

                if (step.action == "pause_for_user") {
                    val reason = step.str("reason") ?: "ادامه با شماست."
                    ui.say(reason)
                    return RunResult(StopReason.NEEDS_USER, reason, outcomes, iteration)
                }

                if (device.needsConfirmation(step)) {
                    val approved = device.confirm(step)
                    if (!approved) {
                        val skipped = StepOutcome(step, ok = false, error = "user_declined", skipped = true)
                        outcomes += skipped
                        ui.onStep(step, skipped)
                        pendingObservation = Observation(step.action, false, error = "user_declined")
                        break
                    }
                }

                val outcome = try {
                    device.execute(step)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    StepOutcome(step, ok = false, error = e.message ?: e::class.simpleName)
                }
                outcomes += outcome
                ui.onStep(step, outcome)

                if (!outcome.ok) {
                    // Feed the failure back so the model can recover instead of
                    // repeating the same blind step.
                    pendingObservation = Observation(step.action, false, error = outcome.error)
                    break
                }

                if (outcome.data != null) {
                    pendingObservation = Observation(step.action, true, data = outcome.data)
                }
            }

            if (finished) {
                return RunResult(StopReason.DONE, lastSpeech, outcomes, iteration)
            }
            if (askedUser) {
                // Continue the loop with the answer as the observation.
                observation = pendingObservation
                mode = "step"
                continue
            }

            // The plan said it was the last one and every step succeeded:
            // stop here instead of spending another model call to be told so.
            val allOk = outcomes.takeLast(response.steps.size).all { it.ok }
            if (response.done && allOk) {
                return RunResult(StopReason.DONE, lastSpeech, outcomes, iteration)
            }

            observation = pendingObservation
            mode = "step"
        }

        return RunResult(
            reason = StopReason.MAX_ITERATIONS,
            speech = lastSpeech.ifBlank { "به سقف مراحل رسیدم و کار تمام نشد." },
            outcomes = outcomes,
            iterations = iteration,
        )
    }
}
