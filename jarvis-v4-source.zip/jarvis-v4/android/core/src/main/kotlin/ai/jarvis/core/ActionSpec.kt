package ai.jarvis.core

/**
 * The device-side action vocabulary.
 *
 * This must stay in lock-step with server/lib/actions.js. The server test
 * suite reads this file and fails if the two lists differ, so a new action
 * cannot be added on one side only — which is exactly how v3 drifted.
 *
 * `implemented = false` means the action is declared but the executor does not
 * handle it yet. The executor returns a clear "not implemented" error for
 * those instead of silently doing nothing, and the README lists them.
 */
enum class ActionSpec(
    val wire: String,
    val implemented: Boolean = true,
    val needsConfirmation: Boolean = false,
) {
    // apps
    OPEN_APP("open_app"),
    OPEN_URL("open_url"),
    OPEN_PROFILE("open_profile"),
    LIST_APPS("list_apps"),
    BACK("back"),
    HOME("home"),
    RECENTS("recents"),

    // screen
    READ_SCREEN("read_screen"),
    SCREENSHOT("screenshot", needsConfirmation = true),
    TAP_TEXT("tap_text"),
    TAP_XY("tap_xy"),
    LONG_PRESS_TEXT("long_press_text"),
    SCROLL("scroll"),
    SWIPE("swipe"),
    TYPE_TEXT("type_text"),
    PRESS_KEY("press_key"),
    WAIT("wait"),

    // device
    GET_DEVICE_STATE("get_device_state"),
    GET_BATTERY("get_battery"),
    SET_SETTING("set_setting"),
    SET_RINGTONE("set_ringtone"),
    TOGGLE("toggle"),
    SET_ALARM("set_alarm"),
    SET_TIMER("set_timer"),
    ADD_CALENDAR_EVENT("add_calendar_event"),
    COPY_TO_CLIPBOARD("copy_to_clipboard"),
    SHARE_TEXT("share_text"),
    OPEN_SETTINGS_PAGE("open_settings_page"),

    // comms
    CALL("call", needsConfirmation = true),
    SEND_SMS("send_sms", needsConfirmation = true),
    SEND_WHATSAPP("send_whatsapp", needsConfirmation = true),
    WHATSAPP_CALL("whatsapp_call", needsConfirmation = true),
    SEND_EMAIL("send_email", needsConfirmation = true),
    OPEN_CONTACT("open_contact"),

    // media
    MEDIA_CONTROL("media_control"),
    RECORD_AUDIO("record_audio"),
    DOWNLOAD_FILE("download_file"),
    DOWNLOAD_AUDIO("download_audio"),
    INSTALL_APK("install_apk", needsConfirmation = true),

    // files
    LIST_FILES("list_files"),
    MOVE_FILE("move_file"),
    COPY_FILE("copy_file"),
    RENAME_FILE("rename_file"),
    DELETE_FILE("delete_file", needsConfirmation = true),
    CREATE_FOLDER("create_folder"),

    // social
    INSTAGRAM_POST("instagram_post", needsConfirmation = true),
    INSTAGRAM_DM("instagram_dm", needsConfirmation = true),
    X_SEARCH("x_search"),
    X_POST("x_post", needsConfirmation = true),

    // assistant
    ASK_USER("ask_user"),
    PAUSE_FOR_USER("pause_for_user"),
    SPEAK("speak"),
    NOTIFY("notify"),
    FINISH("finish");

    companion object {
        private val byWire = entries.associateBy { it.wire }

        fun of(wire: String): ActionSpec? = byWire[wire]

        val allWireNames: List<String> get() = entries.map { it.wire }

        val notImplemented: List<String> get() = entries.filter { !it.implemented }.map { it.wire }
    }
}
