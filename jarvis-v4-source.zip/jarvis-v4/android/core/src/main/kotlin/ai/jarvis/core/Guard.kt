package ai.jarvis.core

/**
 * Client-side guard rails.
 *
 * The server already validates the plan, but the phone must not trust the
 * network either: a compromised or misconfigured server, or a proxy, could
 * still send something dangerous. These checks run on the device, before any
 * step is executed.
 */
object Guard {

    /** Actions that may never run without an explicit human confirmation. */
    val alwaysConfirm: Set<String> = ActionSpec.entries
        .filter { it.needsConfirmation }
        .map { it.wire }
        .toSet()

    /** Actions that are never allowed to run automatically at all. */
    val neverAutomatic: Set<String> = setOf("install_apk", "delete_file")

    /** URL schemes the app will open. */
    private val allowedSchemes = setOf("https")

    fun needsConfirmation(step: Step): Boolean =
        step.confirmBefore || step.action in alwaysConfirm

    /**
     * Returns null when the step is acceptable, or a human-readable reason
     * when it must be refused.
     */
    fun refuseReason(step: Step): String? {
        val spec = ActionSpec.of(step.action)
            ?: return "اکشن ناشناخته: ${step.action}"

        if (!spec.implemented) {
            return "این قابلیت هنوز پیاده‌سازی نشده است: ${step.action}"
        }

        when (step.action) {
            "open_url" -> {
                val url = step.str("url") ?: return "آدرس خالی است"
                val scheme = url.substringBefore("://", "").lowercase()
                if (scheme !in allowedSchemes) return "فقط آدرس‌های https مجاز هستند"
            }
            "download_file", "download_audio" -> {
                val url = step.str("url")
                if (url != null) {
                    val scheme = url.substringBefore("://", "").lowercase()
                    if (scheme !in allowedSchemes) return "فقط آدرس‌های https مجاز هستند"
                }
            }
            "type_text" -> {
                val text = step.str("text") ?: return "متنی برای تایپ نیست"
                if (text.length > 4000) return "متن برای تایپ بیش از حد بلند است"
            }
        }
        return null
    }

    /** True when the step is safe to run with no confirmation. */
    fun isSafe(step: Step): Boolean = refuseReason(step) == null && !needsConfirmation(step)
}
