package ai.jarvis.core

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonPrimitive

/**
 * The wire protocol between the phone and the relay server.
 *
 * Parameters are [JsonElement], not String. The v3 client used
 * Map<String, String> and crashed on every numeric parameter (x, y,
 * duration_ms) because the server sends real numbers. That is fixed here and
 * covered by a test.
 */

@OptIn(kotlinx.serialization.ExperimentalSerializationApi::class)
val JarvisJson: Json = Json {
    ignoreUnknownKeys = true
    isLenient = true
    encodeDefaults = true
    explicitNulls = false
}

@Serializable
data class PlanRequest(
    val utterance: String = "",
    val mode: String = "plan",              // "plan" | "step"
    val locale: String = "fa-IR",
    val iteration: Int = 0,
    val history: List<Turn> = emptyList(),
    val deviceState: JsonObject? = null,
    val observation: Observation? = null,
    val screenImage: String? = null,        // base64 JPEG, no data: prefix
    val screenImageMime: String? = null,
)

@Serializable
data class Turn(val role: String, val content: String)

@Serializable
data class Observation(
    val action: String,
    val ok: Boolean,
    val error: String? = null,
    val data: String? = null,
)

@Serializable
data class PlanResponse(
    val requestId: String? = null,
    val mode: String? = null,
    val speech: String = "",
    val steps: List<Step> = emptyList(),
    val needsUser: Boolean = false,
    val done: Boolean = false,
    val provider: String? = null,
    val model: String? = null,
    val dropped: List<String> = emptyList(),
)

@Serializable
data class Step(
    val action: String,
    val params: Map<String, JsonElement> = emptyMap(),
    val say: String? = null,
    @SerialName("confirm_before") val confirmBefore: Boolean = false,
) {
    // --- typed parameter accessors -----------------------------------------
    // Every one of these is null-safe and never throws on a wrong type, so a
    // malformed plan degrades to "missing parameter" instead of a crash.

    fun str(key: String): String? =
        (params[key] as? JsonPrimitive)?.takeIf { it.isString }?.content
            ?: (params[key] as? JsonPrimitive)?.content

    fun int(key: String): Int? =
        (params[key] as? JsonPrimitive)?.let { it.intOrNull ?: it.doubleOrNull?.toInt() }

    fun double(key: String): Double? =
        (params[key] as? JsonPrimitive)?.let { it.doubleOrNull ?: it.intOrNull?.toDouble() }

    fun bool(key: String): Boolean? =
        (params[key] as? JsonPrimitive)?.booleanOrNull

    fun requireStr(key: String): String =
        str(key) ?: throw MissingParamException(action, key)
}

class MissingParamException(action: String, param: String) :
    IllegalArgumentException("Action \"$action\" is missing required parameter \"$param\"")

/** A single executed step and what came back from the device. */
data class StepOutcome(
    val step: Step,
    val ok: Boolean,
    val error: String? = null,
    val data: String? = null,
    val skipped: Boolean = false,
)

/** Why a run stopped. */
enum class StopReason {
    DONE,
    NEEDS_USER,
    MAX_ITERATIONS,
    FAILED,
    CANCELLED,
}

data class RunResult(
    val reason: StopReason,
    val speech: String,
    val outcomes: List<StepOutcome>,
    val iterations: Int,
)
