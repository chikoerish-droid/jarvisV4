plugins {
    id("org.jetbrains.kotlin.jvm")
    id("org.jetbrains.kotlin.plugin.serialization")
}

/**
 * :core — the part of the app that is pure Kotlin.
 *
 * It has no Android dependency at all, which is deliberate:
 *   - it compiles and its unit tests run on any machine with a JDK,
 *     including CI, without an Android SDK;
 *   - the plan model, the wire protocol, the validation and the
 *     observe -> replan loop are all testable in isolation.
 *
 * The Android module (:app) depends on this and adds the device side:
 * accessibility, speech, settings, UI.
 */

kotlin {
    jvmToolchain(17)
}

dependencies {
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.9.0")

    testImplementation(kotlin("test"))
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.9.0")
}

tasks.test {
    useJUnitPlatform()
    testLogging {
        events("passed", "skipped", "failed")
        showStandardStreams = false
    }
}
