# Jarvis 2.0.0 — what was built, what changed, what is not done

Read this first. It is deliberately blunt.

---

## The one-line summary

A complete, buildable Android client (Kotlin, 2 modules) plus a complete relay
server (Node / Vercel Functions). The phone is ears, eyes and hands; the brain
and the model key stay on the server. Everything that could be verified without
an Android SDK **was** verified.

---

## Build / verification status — exact

| Component | Built | Linted | Tested | How |
|---|---|---|---|---|
| `server/` (relay) | ✅ `npm install` | ✅ `eslint` clean | ✅ **53/53** `node --test` | Run for real in this environment |
| `android/core` (pure Kotlin) | ✅ Gradle 8.9 + JDK 17 | ✅ compiler warnings only | ✅ **34/34** JUnit 5 | Run for real in this environment |
| `android/app` (Android UI + device) | ⚠️ **NOT compiled** | ⚠️ not run | ⚠️ not run | No Android SDK here |
| APK | ❌ **not produced** | — | — | Sandbox policy blocks Android SDK/APK builds |

**Why the APK is missing is not a code problem.** This sandbox refuses to
download the Android SDK or run an APK build at all. I tried; the download was
blocked by policy. You build it on your machine — it takes about 10 minutes and
`BUILD_GUIDE_FA.md` has every command.

**What this means for you:** you should expect to fix one or two small compile
errors on your first build (a missing import, an experimental-API annotation).
That is normal for a project of this size that could not be compiler-checked.
Send me the error text and I will fix it exactly.

---

## What was built

### Server (`server/`) — the brain

```
server/
├── api/plan.js              POST /api/plan        — the single endpoint the phone uses
├── api/health.js            GET  /api/health      — "Test connection" (authenticated)
├── api/resolve-audio.js     POST /api/resolve-audio — audio extraction proxy
├── lib/actions.js           THE action vocabulary (54 actions, one source of truth)
├── lib/schema.js            JSON Schema generated from the table
├── lib/prompt.js            system prompt generated from the same table
├── lib/validate.js          server-side validation of every model answer
├── lib/providers/           gemini | openai | openrouter behind one interface
├── lib/auth.js              constant-time, fail-closed device token
├── lib/ratelimit.js         Upstash (global) or in-memory (per instance)
├── lib/handler.js           the HTTP layer, framework-free
├── local.js                 `npm run dev`, no Vercel CLI needed
└── test/                    53 tests
```

### Android (`android/`) — ears, eyes, hands

```
android/
├── core/                    PURE Kotlin, no Android — this is the tested part
│   ├── Protocol.kt          wire protocol; params are JsonElement (the v3 crash fix)
│   ├── AgentLoop.kt         plan -> observe -> replan loop (the core fix)
│   ├── ActionSpec.kt        device-side action vocabulary
│   ├── Guard.kt             client-side safety (https only, confirm gates)
│   └── src/test/            34 tests
└── app/                     Android module
    ├── access/AccessibilityBridge.kt   the eyes (screen as text) and hands
    ├── exec/                 Executor + Screen/Device/Comms/Media/File/Social
    ├── net/BridgeClient.kt   OkHttp, Bearer token, no model key anywhere
    ├── voice/                platform STT + TTS
    ├── service/              foreground service, Quick Settings tile, screen capture
    └── ui/                   Compose: conversation, settings, confirm/ask dialogs
```

---

## What changed versus the reports you gave me

### From the gap review (`jarvis-gap-review`)

| Gap in v3 | What I did |
|---|---|
| `read_screen` existed but its result was **thrown away**; the app ran one plan and stopped | `AgentLoop` now runs **plan → execute → observe → replan**, up to N iterations, feeding the screen back to the model. `AgentLoopTest` proves the second model call receives the observation. |
| No `tap_xy`, `swipe`, `type_text`, `scroll` | All implemented in `ScreenController` via `dispatchGesture` / `AccessibilityNodeInfo`. |
| No confirmation for risky actions | Two layers: the server forces `confirm_before` on high-risk actions, and `Guard`/the loop asks the user on the device. `call`, `send_sms`, `delete_file`, `install_apk`, social posts all gated. |
| Server and device action lists drifted | The server test **reads `ActionSpec.kt`** and fails on any difference. The core test **parses `Executor.kt`** and fails if any action lacks a branch. Drift is now a red test, not a runtime surprise. |
| No screenshot / vision path | MediaProjection service + `ScreenCaptureHolder`; `screenshot` returns a clear error when the grant is missing. |
| Persian-only in places | Locale is a setting (`fa-IR` / `en-US`), threaded through the prompt, STT and TTS. |

### From the server assessment (`jarvis-server-assessment`)

| Problem in v3 | What I did |
|---|---|
| No authentication on the model endpoint | `JARVIS_DEVICE_TOKEN`, constant-time compare, **fail-closed** (500 if unset, never open). |
| Health check probed an authenticated route without a token | `/api/health` uses the same auth; it reports `provider`, `model` and `key_configured` but never the key. |
| No rate limiting | Per-token limiter; Upstash when configured (global), in-memory otherwise, and the response header says which (`X-RateLimit-Scope`). |
| Keys could leak via logs | No key is ever logged; the key is never in a response; `X-Request-Id` correlates logs without content. |
| "Download this song as mp3" downloaded an **HTML page** as .mp3 | `download_audio` calls `/api/resolve-audio`, which **501s honestly** when no resolver is configured instead of writing a fake audio file. |
| No CORS policy | Closed by default; echoes only origins in `ALLOWED_ORIGINS`. |
| No structured logging / correlation | Every response carries `X-Request-Id`; every log line carries it. |

### From the build-failure analysis (`jarvis-android-bug-analysis`)

| Cause | What I did |
|---|---|
| Floating `compileSdk` fell back to a version that was not installed | `compileSdk = 35`, `targetSdk = 35`, `minSdk = 26` are **explicit constants**. |
| Missing `local.properties` produced a confusing failure | `local.properties.example` documents every platform's path; the guide puts this first. |
| No Gradle wrapper committed | `gradlew`, `gradlew.bat` and `gradle-wrapper.jar` are generated and included (Gradle 8.9). |
| `params` deserialized as `Map<String, String>` → crash on every numeric parameter | `Step.params` is `Map<String, JsonElement>` with null-safe `int()/bool()/str()` accessors. `ProtocolTest` parses the exact payload the server sends. |

### From the settings audit (`jarvis-settings-audit`)

| Problem in v3 | What I did |
|---|---|
| "Test connection" reported failure even when the server was healthy | It now calls `/api/health` with the token and distinguishes *unreachable* / *bad token* / *server has no key* / *healthy*, each with its own Persian message. |
| Settings did not persist | DataStore, with typed setters and a `Snapshot` read. |
| Token stored in plain SharedPreferences and backed up to Google | DataStore + `allowBackup=false` + `data_extraction_rules.xml` excluding the token from cloud backup **and** device transfer. |
| Confusing or missing fields | Grouped into سرور / دسترسی‌ها / رفتار / زبان / سقف مراحل, each with a one-line explanation of what it is for. |

---

## What is NOT done — the honest list

### Not verified at all (no Android SDK here)

1. ⚠️ `android/app` has **never been compiled**. Expect small fixes on first build.
2. ⚠️ `:app:lintDebug` and `:app:testDebugUnitTest` (the MockWebServer tests) were **written but never run**.
3. ⚠️ The app has **never run on a phone or emulator**. No claim about how it behaves on a real device is verified.
4. ⚠️ The accessibility tree walker is **untested against real apps** — Instagram, Snapp, Telegram all render differently and will need tuning. This is the single most likely source of friction in practice.

### Not implemented, by design or by limit

5. ❌ **Always-on "Hey Jarvis" hotword.** Android forbids third-party apps from holding the mic permanently; only the system assistant can. The app ships a Quick Settings tile plus the `ASSIST` intent, and if the user makes Jarvis the default assistant, long-press-home opens it. See `BUILD_GUIDE_FA.md` §5.
6. ❌ **Google Play distribution.** Google's Play policy prohibits using the Accessibility API for autonomous control of other apps. This app will be **rejected** if submitted to Play as-is. It is fine as a sideloaded/personal app or via a private channel (MDM, direct APK). **You must decide the distribution route before you depend on it.**
7. ❌ **WhatsApp voice/video call.** No public API. The app opens the chat and tells the user to press call; it does not claim success.
8. ❌ **Silent Wi-Fi / Bluetooth / airplane toggles.** Modern Android forbids them. The app opens the right panel and says exactly that.
9. ❌ **Instagram DM by intent.** No documented intent. The app opens the profile; on-screen continuation is needed.
10. ❌ **Payment screens.** Deliberately a hard stop: `pause_for_user` before any payment. The app never enters a card password or OTP; it uses `ask_user(secret=true)` so the user types it.
11. ❌ **Real audio extraction (YouTube → mp3).** Needs a resolver service you operate. Without `AUDIO_RESOLVER_URL` the endpoint answers 501 honestly. I did not ship a resolver because that is a legal grey area that depends on your jurisdiction and it is your call, not mine.
12. ❌ **Model streaming.** Responses arrive whole. Sentences feel slower than a streaming assistant. A `/api/plan` SSE variant is the obvious next step.
13. ❌ **Voice Activity Detection / barge-in.** Push-to-talk only.
14. ❌ **Offline mode.** By design: no model on the device. Without network the app can still do nothing except show the last transcript.
15. ❌ **Per-user accounts.** One device token per install (comma-separated tokens are supported server-side for multiple devices, but there is no user database).
16. ❌ **i18n beyond fa/en.** The prompt and UI strings are fa/en only.

### Known weak points I want to name

- **Latency.** Each loop iteration is one model call (1–4 s). A task needing four iterations is 5–15 s. That is acceptable for "open Instagram and read my messages", painful for "scroll and like 20 posts".
- **Accessibility trees are noisy.** I prune to 120 elements; some apps still produce garbage. The model will sometimes tap the wrong thing; that is why the loop re-reads the screen instead of trusting a long plan.
- **FLAG_SECURE apps** (banking, some payment screens) return an empty tree. The prompt tells the model to stop and hand over rather than loop.
- **The in-memory rate limiter** resets on a cold start. For real use, set the Upstash variables.
- **`instagram_post`** relies on the system share sheet; Instagram's own UI still needs a human to press "Share". The app reports "composer opened", never "posted".

---

## Files to read, in order

1. `BUILD_GUIDE_FA.md` — build it.
2. `server/.env.example` — what the server needs.
3. `android/app/src/main/kotlin/ai/jarvis/app/exec/Executor.kt` — every action, and what it honestly reports.
4. `android/core/src/main/kotlin/ai/jarvis/core/AgentLoop.kt` — the loop that makes it an agent and not a command list.
5. `server/lib/actions.js` — the vocabulary both halves must agree on.
