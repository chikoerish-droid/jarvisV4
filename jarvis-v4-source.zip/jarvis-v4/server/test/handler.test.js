import { test, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { handlePlan, handleHealth } from '../lib/handler.js';
import { _resetMemoryLimiter } from '../lib/ratelimit.js';

/**
 * End-to-end tests of the HTTP layer with a fake model provider.
 * No real key is needed: the provider module is replaced by a stub that
 * returns whatever the test wants, so the auth / validation / error paths are
 * exercised for real.
 */

const TOKEN = 'e2e-token-abcdef';

function makeRes() {
  const res = {
    statusCode: 0,
    headers: {},
    body: '',
    setHeader(k, v) { this.headers[k.toLowerCase()] = v; },
    end(chunk) { if (chunk) this.body += chunk; },
    json() { return JSON.parse(this.body || '{}'); },
  };
  return res;
}

function makeReq({ method = 'POST', headers = {}, body = null } = {}) {
  return { method, headers, body };
}

beforeEach(() => {
  process.env.JARVIS_DEVICE_TOKEN = TOKEN;
  process.env.AI_PROVIDER = 'gemini';
  process.env.GEMINI_API_KEY = 'fake-key-for-tests';
  process.env.RATE_LIMIT_PER_MIN = '100';
  delete process.env.UPSTASH_REDIS_REST_URL;
  _resetMemoryLimiter();
});

test('health requires the device token', async () => {
  const res = makeRes();
  await handleHealth(makeReq({ method: 'GET' }), res);
  assert.equal(res.statusCode, 401);
  assert.equal(res.json().error, 'missing_token');
});

test('health reports the provider and that the key is configured', async () => {
  const res = makeRes();
  await handleHealth(makeReq({ method: 'GET', headers: { authorization: `Bearer ${TOKEN}` } }), res);
  assert.equal(res.statusCode, 200);
  const body = res.json();
  assert.equal(body.ok, true);
  assert.equal(body.provider, 'gemini');
  assert.equal(body.key_configured, true);
  assert.equal(body.token_required, true);
  // The key itself must never appear in the response.
  assert.ok(!res.body.includes('fake-key-for-tests'));
});

test('health is fail-closed when the token is not configured', async () => {
  delete process.env.JARVIS_DEVICE_TOKEN;
  const res = makeRes();
  await handleHealth(makeReq({ method: 'GET', headers: { authorization: `Bearer ${TOKEN}` } }), res);
  assert.equal(res.statusCode, 500);
  assert.equal(res.json().error, 'server_misconfigured');
});

test('plan rejects a missing token', async () => {
  const res = makeRes();
  await handlePlan(makeReq({ body: { utterance: 'سلام' } }), res);
  assert.equal(res.statusCode, 401);
});

test('plan rejects a missing utterance', async () => {
  const res = makeRes();
  await handlePlan(makeReq({ headers: { authorization: `Bearer ${TOKEN}` }, body: { utterance: '' } }), res);
  assert.equal(res.statusCode, 400);
  assert.equal(res.json().error, 'missing_utterance');
});

test('plan rejects an over-long utterance', async () => {
  process.env.MAX_UTTERANCE_CHARS = '10';
  const res = makeRes();
  await handlePlan(makeReq({
    headers: { authorization: `Bearer ${TOKEN}` },
    body: { utterance: 'x'.repeat(50) },
  }), res);
  assert.equal(res.statusCode, 413);
  delete process.env.MAX_UTTERANCE_CHARS;
});

test('plan returns 500 when the provider key is missing', async () => {
  delete process.env.GEMINI_API_KEY;
  const res = makeRes();
  await handlePlan(makeReq({
    headers: { authorization: `Bearer ${TOKEN}` },
    body: { utterance: 'سلام' },
  }), res);
  assert.equal(res.statusCode, 500);
  assert.equal(res.json().error, 'server_misconfigured');
});

test('plan returns 500 for an unknown provider', async () => {
  process.env.AI_PROVIDER = 'not-a-provider';
  const res = makeRes();
  await handlePlan(makeReq({
    headers: { authorization: `Bearer ${TOKEN}` },
    body: { utterance: 'سلام' },
  }), res);
  assert.equal(res.statusCode, 500);
});

test('plan rate-limits after the configured number of requests', async () => {
  process.env.RATE_LIMIT_PER_MIN = '1';
  _resetMemoryLimiter();
  const req = () => makeReq({ headers: { authorization: `Bearer ${TOKEN}` }, body: { utterance: 'سلام' } });
  const first = makeRes();
  await handlePlan(req(), first);
  // The first call reaches the model and fails on the fake key (502), which is
  // fine — what matters is that it was not rate limited.
  assert.notEqual(first.statusCode, 429);

  const second = makeRes();
  await handlePlan(req(), second);
  assert.equal(second.statusCode, 429);
  assert.equal(second.json().error, 'rate_limited');
  assert.ok(second.headers['retry-after']);
});

test('plan rejects a non-POST method', async () => {
  const res = makeRes();
  await handlePlan(makeReq({ method: 'GET', headers: { authorization: `Bearer ${TOKEN}` } }), res);
  assert.equal(res.statusCode, 405);
});

test('CORS is closed by default', async () => {
  const res = makeRes();
  await handleHealth(makeReq({
    method: 'GET',
    headers: { authorization: `Bearer ${TOKEN}`, origin: 'https://evil.example' },
  }), res);
  assert.equal(res.headers['access-control-allow-origin'], undefined);
});

test('CORS echoes only an explicitly allowed origin', async () => {
  process.env.ALLOWED_ORIGINS = 'https://mine.example';
  const res = makeRes();
  await handleHealth(makeReq({
    method: 'GET',
    headers: { authorization: `Bearer ${TOKEN}`, origin: 'https://mine.example' },
  }), res);
  assert.equal(res.headers['access-control-allow-origin'], 'https://mine.example');
  delete process.env.ALLOWED_ORIGINS;
});
