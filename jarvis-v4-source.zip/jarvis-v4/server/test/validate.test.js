import { test } from 'node:test';
import assert from 'node:assert/strict';
import { validatePlan, validateStep, validateStepResponse } from '../lib/validate.js';

test('a clean plan passes through unchanged', () => {
  const { plan, dropped } = validatePlan({
    speech: 'باشه',
    steps: [{ action: 'open_app', params: { app: 'اینستاگرام' } }],
  });
  assert.equal(plan.speech, 'باشه');
  assert.equal(plan.steps.length, 1);
  assert.equal(plan.steps[0].action, 'open_app');
  assert.equal(plan.steps[0].params.app, 'اینستاگرام');
  assert.deepEqual(dropped, []);
});

test('unknown actions are dropped, not executed', () => {
  const { plan, dropped } = validatePlan({
    speech: 'x',
    steps: [
      { action: 'rm_rf_everything', params: {} },
      { action: 'open_app', params: { app: 'Telegram' } },
    ],
  });
  assert.equal(plan.steps.length, 1);
  assert.equal(plan.steps[0].action, 'open_app');
  assert.ok(dropped.some((d) => d.includes('rm_rf_everything')));
});

test('unknown parameters are stripped', () => {
  const { plan, dropped } = validatePlan({
    speech: 'x',
    steps: [{ action: 'open_app', params: { app: 'Telegram', shell: 'rm -rf /' } }],
  });
  assert.equal(plan.steps[0].params.shell, undefined);
  assert.ok(dropped.some((d) => d.includes('shell')));
});

test('a step missing a required parameter is rejected', () => {
  const { plan, dropped } = validatePlan({
    speech: 'x',
    steps: [{ action: 'tap_text', params: {} }],
  });
  assert.equal(plan.steps.length, 0);
  assert.ok(dropped.some((d) => d.includes('missing required "text"')));
});

test('numeric strings are coerced and clamped', () => {
  const step = validateStep({ action: 'tap_xy', params: { x: '540', y: '1200' } });
  assert.equal(step.params.x, 540);
  assert.equal(step.params.y, 1200);

  const clamped = validateStep({ action: 'wait', params: { ms: 999999 } });
  assert.equal(clamped.params.ms, 10000);

  const low = validateStep({ action: 'wait', params: { ms: 1 } });
  assert.equal(low.params.ms, 200);
});

test('booleans arrive as strings and are coerced', () => {
  const step = validateStep({ action: 'type_text', params: { text: 'hi', submit: 'true' } });
  assert.equal(step.params.submit, true);
  const step2 = validateStep({ action: 'type_text', params: { text: 'hi', submit: 'no' } });
  assert.equal(step2.params.submit, false);
});

test('enums are matched case-insensitively and rejected when invalid', () => {
  const ok = validateStep({ action: 'scroll', params: { direction: 'DOWN' } });
  assert.equal(ok.params.direction, 'down');

  const bad = validateStep({ action: 'scroll', params: { direction: 'sideways' } });
  assert.equal(bad, null);
});

test('high-risk actions always get confirm_before', () => {
  const step = validateStep({ action: 'call', params: { contact: 'علی' } });
  assert.equal(step.confirm_before, true);

  const sms = validateStep({ action: 'send_sms', params: { contact: 'علی', message: 'سلام' } });
  assert.equal(sms.confirm_before, true);
});

test('a low-risk action can opt into confirmation', () => {
  const step = validateStep({ action: 'open_app', params: { app: 'X' }, confirm_before: true });
  assert.equal(step.confirm_before, true);
});

test('send_sms defaults to the composer, never a silent send', () => {
  // The v3 bug: an absent `send` field fell through to SmsManager.sendTextMessage.
  const step = validateStep({ action: 'send_sms', params: { contact: '0912', message: 'hi' } });
  assert.notEqual(step.params.send, true);
  assert.equal(step.confirm_before, true);
});

test('an empty plan is marked done rather than pretending to work', () => {
  const { plan } = validatePlan({ speech: '', steps: [] });
  assert.equal(plan.done, true);
  assert.ok(plan.speech.length > 0);
});

test('step count is capped', () => {
  const steps = Array.from({ length: 30 }, () => ({ action: 'back', params: {} }));
  const { plan, dropped } = validatePlan({ speech: 'x', steps });
  assert.equal(plan.steps.length, 12);
  assert.ok(dropped.some((d) => d.includes('truncated')));
});

test('step response validates a single step', () => {
  const { plan } = validateStepResponse({
    speech: 'ادامه می‌دهم',
    step: { action: 'read_screen', params: {} },
  });
  assert.equal(plan.step.action, 'read_screen');
  assert.equal(plan.done, false);
});

test('step response with nothing runnable is done', () => {
  const { plan } = validateStepResponse({ speech: 'تمام شد' });
  assert.equal(plan.done, true);
});

test('non-object input does not throw', () => {
  assert.doesNotThrow(() => validatePlan(null));
  assert.doesNotThrow(() => validatePlan({ steps: 'nope' }));
  assert.doesNotThrow(() => validateStep(null));
});
