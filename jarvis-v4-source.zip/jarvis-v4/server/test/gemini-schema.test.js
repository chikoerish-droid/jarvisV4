import { test } from 'node:test';
import assert from 'node:assert/strict';
import { toGeminiSchema } from '../lib/providers/gemini.js';
import { planSchema } from '../lib/schema.js';

test('Gemini schema strips keys the live API rejects', () => {
  const cleaned = toGeminiSchema(planSchema());
  const text = JSON.stringify(cleaned);
  assert.ok(!text.includes('additionalProperties'), 'additionalProperties must be removed');
  assert.ok(!text.includes('$schema'));
});

test('Gemini schema keeps the parts that matter', () => {
  const cleaned = toGeminiSchema(planSchema());
  assert.equal(cleaned.type, 'object');
  assert.ok(cleaned.properties.steps);
  assert.ok(Array.isArray(cleaned.properties.steps.items.properties.action.enum));
  assert.ok(cleaned.properties.steps.items.properties.action.enum.includes('read_screen'));
});

test('the original schema object is not mutated', () => {
  const original = planSchema();
  toGeminiSchema(original);
  assert.equal(original.additionalProperties, false);
});
