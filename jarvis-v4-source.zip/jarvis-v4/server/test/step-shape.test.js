import { test } from 'node:test';
import assert from 'node:assert/strict';
import { validateStepResponse } from '../lib/validate.js';

/**
 * Regression: the step-mode schema asks for a singular `step`, but models
 * frequently answer with a one-element `steps` array (the shape they used in
 * plan mode). Before this was handled, such an answer was silently treated as
 * "done" and the task ended after the first action.
 */

test('step mode accepts a singular step', () => {
  const { plan } = validateStepResponse({
    speech: 'ok',
    step: { action: 'tap_text', params: { text: 'Messages' } },
  });
  assert.equal(plan.step.action, 'tap_text');
  assert.equal(plan.done, false);
});

test('step mode also accepts a one element steps array', () => {
  const { plan } = validateStepResponse({
    speech: 'ok',
    steps: [{ action: 'tap_text', params: { text: 'Messages' } }],
  });
  assert.ok(plan.step, 'a steps[] answer must not be discarded');
  assert.equal(plan.step.action, 'tap_text');
  assert.equal(plan.done, false);
});

test('step mode still finishes when there is genuinely nothing to do', () => {
  const { plan } = validateStepResponse({ speech: 'done', done: true });
  assert.equal(plan.step, null);
  assert.equal(plan.done, true);
});

test('an unknown action in step mode ends the task rather than looping', () => {
  const { plan, dropped } = validateStepResponse({
    step: { action: 'not_a_real_action', params: {} },
  });
  assert.equal(plan.step, null);
  assert.equal(plan.done, true);
  assert.ok(dropped.some((d) => d.includes('unknown action')));
});
