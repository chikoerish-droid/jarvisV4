import { test } from 'node:test';
import assert from 'node:assert/strict';
import { ACTIONS, ACTION_NAMES, ALWAYS_CONFIRM, OBSERVING_ACTIONS } from '../lib/actions.js';
import { planSchema, stepSchema, paramReference } from '../lib/schema.js';
import { systemPrompt, stepPrompt } from '../lib/prompt.js';

test('action table is non-trivial and every entry is well formed', () => {
  assert.ok(ACTION_NAMES.length >= 45, `expected >=45 actions, got ${ACTION_NAMES.length}`);
  for (const name of ACTION_NAMES) {
    const a = ACTIONS[name];
    assert.match(name, /^[a-z][a-z0-9_]*$/, `bad action name: ${name}`);
    assert.equal(typeof a.desc, 'string');
    assert.ok(a.desc.length > 10, `${name} needs a real description`);
    assert.ok(['low', 'medium', 'high'].includes(a.risk), `${name} has a bad risk level`);
    assert.equal(typeof a.group, 'string');
    for (const [pname, p] of Object.entries(a.params)) {
      assert.match(pname, /^[a-z][a-z0-9_]*$/, `${name}.${pname} bad param name`);
      assert.ok(['string', 'number', 'boolean', 'enum'].includes(p.type), `${name}.${pname} bad type`);
      if (p.type === 'enum') {
        assert.ok(Array.isArray(p.values) && p.values.length > 0, `${name}.${pname} enum needs values`);
      }
    }
  }
});

test('every risky action is in the always-confirm set', () => {
  for (const name of ACTION_NAMES) {
    if (ACTIONS[name].risk === 'high') {
      assert.ok(ALWAYS_CONFIRM.has(name), `${name} is high risk but not in ALWAYS_CONFIRM`);
    }
  }
});

test('observing actions include the ones the loop depends on', () => {
  for (const required of ['read_screen', 'screenshot', 'get_device_state', 'list_apps', 'list_files']) {
    assert.ok(OBSERVING_ACTIONS.has(required), `${required} must be an observing action`);
  }
});

test('plan schema is a valid JSON-schema-ish object with the action enum', () => {
  const s = planSchema();
  assert.equal(s.type, 'object');
  assert.ok(Array.isArray(s.required));
  assert.ok(s.required.includes('speech'));
  assert.ok(s.required.includes('steps'));
  const step = s.properties.steps.items;
  assert.deepEqual(step.properties.action.enum, ACTION_NAMES);
  assert.equal(step.additionalProperties, false);
});

test('step schema exposes a single step', () => {
  const s = stepSchema();
  assert.equal(s.type, 'object');
  assert.ok(s.properties.step);
  assert.deepEqual(s.properties.step.properties.action.enum, ACTION_NAMES);
});

test('param reference mentions every action exactly once', () => {
  const ref = paramReference();
  for (const name of ACTION_NAMES) {
    const hits = ref.split('\n').filter((l) => l.startsWith(`${name}:`)).length;
    assert.equal(hits, 1, `${name} should appear once in the param reference`);
  }
});

test('system prompt contains the catalogue, the rules and the playbook', () => {
  const p = systemPrompt({ locale: 'fa-IR' });
  assert.ok(p.includes('read_screen'));
  assert.ok(p.includes('pause_for_user'));
  assert.ok(p.includes('Persian'));
  assert.ok(p.includes('Snapp'));
  assert.ok(p.includes('Never invent success'));
  // No action may be described that does not exist.
  assert.ok(!p.includes('take_screenshot'), 'stale action name leaked into the prompt');
});

test('system prompt switches language for an English locale', () => {
  const p = systemPrompt({ locale: 'en-US' });
  assert.ok(p.includes('English'));
  assert.ok(!p.includes('Persian (فارسی)'));
});

test('step prompt is smaller than the full prompt', () => {
  const full = systemPrompt({ locale: 'fa-IR' });
  const step = stepPrompt({ locale: 'fa-IR' });
  assert.ok(step.length < full.length);
  assert.ok(step.includes('single next step'));
});

test('device state is embedded when provided', () => {
  const p = systemPrompt({ deviceState: { foregroundApp: 'com.instagram.android' } });
  assert.ok(p.includes('com.instagram.android'));
});
