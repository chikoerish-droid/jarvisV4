import { test, beforeEach, after } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { handlePlan } from '../lib/handler.js';
import { _resetMemoryLimiter } from '../lib/ratelimit.js';

/**
 * A full two-turn session through the real HTTP handler.
 *
 * The model is replaced by a local HTTP server that impersonates Gemini, so
 * the request body Gemini would receive is asserted for real: this is the test
 * that proves `responseSchema` is clean (no additionalProperties) and that the
 * continuation call carries the observation.
 */

const TOKEN = 'session-token';

function makeRes() {
  return {
    statusCode: 0,
    headers: {},
    body: '',
    setHeader(k, v) { this.headers[k.toLowerCase()] = v; },
    end(c) { if (c) this.body += c; },
    json() { return JSON.parse(this.body || '{}'); },
  };
}

let fakeGemini;
let received = [];

beforeEach(async () => {
  process.env.JARVIS_DEVICE_TOKEN = TOKEN;
  process.env.AI_PROVIDER = 'gemini';
  process.env.GEMINI_API_KEY = 'test-key';
  process.env.RATE_LIMIT_PER_MIN = '100';
  _resetMemoryLimiter();
  received = [];

  if (fakeGemini) await new Promise((r) => fakeGemini.close(r));
  fakeGemini = http.createServer((req, res) => {
    let body = '';
    req.on('data', (c) => { body += c; });
    req.on('end', () => {
      const parsed = JSON.parse(body);
      received.push(parsed);

      // Assert the schema is Gemini-clean on every single call.
      const text = JSON.stringify(parsed.generationConfig.responseSchema);
      assert.ok(!text.includes('additionalProperties'), 'additionalProperties leaked to Gemini');

      const isFirst = received.length === 1;
      const plan = isFirst
        ? {
            speech: 'صفحه را می‌خوانم',
            steps: [{ action: 'read_screen', params: {} }],
          }
        : {
            speech: 'دکمه پیام‌ها را می‌زنم',
            steps: [{ action: 'tap_text', params: { text: 'Messages' } }],
            done: true,
          };

      res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify({
        candidates: [{ content: { parts: [{ text: JSON.stringify(plan) }] }, finishReason: 'STOP' }],
        usageMetadata: { totalTokenCount: 100 },
      }));
    });
  });
  await new Promise((r) => fakeGemini.listen(0, r));
  const port = fakeGemini.address().port;

  // Point the provider at the fake.
  process.env.GEMINI_ENDPOINT_OVERRIDE = `http://127.0.0.1:${port}`;
});

after(async () => {
  if (fakeGemini) await new Promise((r) => fakeGemini.close(r));
});

test('a two turn session works end to end through the real handler', async () => {
  const res1 = makeRes();
  await handlePlan({
    method: 'POST',
    headers: { authorization: `Bearer ${TOKEN}` },
    body: { utterance: 'اینستاگرام را باز کن و پیام‌هایم را بخوان', locale: 'fa-IR' },
  }, res1);

  assert.equal(res1.statusCode, 200, `first call failed: ${res1.body}`);
  const plan1 = res1.json();
  assert.equal(plan1.speech, 'صفحه را می‌خوانم');
  assert.equal(plan1.steps[0].action, 'read_screen');
  assert.ok(plan1.requestId);
  assert.ok(!res1.body.includes('test-key'), 'the API key must never be echoed');

  // Continuation.
  const res2 = makeRes();
  await handlePlan({
    method: 'POST',
    headers: { authorization: `Bearer ${TOKEN}` },
    body: {
      mode: 'step',
      utterance: 'اینستاگرام را باز کن و پیام‌هایم را بخوان',
      locale: 'fa-IR',
      iteration: 1,
      observation: { action: 'read_screen', ok: true, data: '[0] clickable "Messages"' },
    },
  }, res2);

  assert.equal(res2.statusCode, 200, `second call failed: ${res2.body}`);
  const plan2 = res2.json();
  assert.equal(plan2.steps[0].action, 'tap_text');
  assert.equal(plan2.done, true);

  // The continuation prompt actually contained the observation.
  const secondUserText = received[1].contents[0].parts[0].text;
  assert.ok(secondUserText.includes('Messages'), 'the observation was not sent to the model');
  assert.ok(secondUserText.includes('read_screen'));
});
