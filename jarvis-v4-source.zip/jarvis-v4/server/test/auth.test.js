import { test, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { authenticate, isAuthConfigured, configuredTokens } from '../lib/auth.js';
import { checkRateLimit, _resetMemoryLimiter } from '../lib/ratelimit.js';

const TOKEN = 'test-token-0123456789abcdef';

beforeEach(() => {
  process.env.JARVIS_DEVICE_TOKEN = TOKEN;
  delete process.env.UPSTASH_REDIS_REST_URL;
  delete process.env.UPSTASH_REDIS_REST_TOKEN;
  process.env.RATE_LIMIT_PER_MIN = '3';
  _resetMemoryLimiter();
});

test('auth is fail-closed when no token is configured', () => {
  delete process.env.JARVIS_DEVICE_TOKEN;
  assert.equal(isAuthConfigured(), false);
  const r = authenticate({ headers: { authorization: `Bearer ${TOKEN}` } });
  assert.equal(r.ok, false);
  assert.equal(r.status, 500);
  assert.equal(r.error, 'server_misconfigured');
});

test('a missing header is rejected', () => {
  const r = authenticate({ headers: {} });
  assert.equal(r.ok, false);
  assert.equal(r.status, 401);
  assert.equal(r.error, 'missing_token');
});

test('a wrong token is rejected', () => {
  const r = authenticate({ headers: { authorization: 'Bearer wrong-token' } });
  assert.equal(r.ok, false);
  assert.equal(r.error, 'bad_token');
});

test('a token of a different length is rejected without throwing', () => {
  const r = authenticate({ headers: { authorization: 'Bearer short' } });
  assert.equal(r.ok, false);
  assert.equal(r.error, 'bad_token');
});

test('the right token is accepted and yields a stable id', () => {
  const a = authenticate({ headers: { authorization: `Bearer ${TOKEN}` } });
  const b = authenticate({ headers: { authorization: `Bearer ${TOKEN}` } });
  assert.equal(a.ok, true);
  assert.equal(a.tokenId, b.tokenId);
  assert.equal(a.tokenId.length, 12);
  assert.ok(!a.tokenId.includes(TOKEN));
});

test('multiple tokens are supported so one device can be revoked', () => {
  process.env.JARVIS_DEVICE_TOKEN = `${TOKEN},second-device-token`;
  assert.equal(configuredTokens().length, 2);
  assert.equal(authenticate({ headers: { authorization: 'Bearer second-device-token' } }).ok, true);
  assert.equal(authenticate({ headers: { authorization: `Bearer ${TOKEN}` } }).ok, true);
});

test('the scheme is case-insensitive', () => {
  assert.equal(authenticate({ headers: { authorization: `bearer ${TOKEN}` } }).ok, true);
});

test('rate limit allows up to the configured number then blocks', async () => {
  const key = 'device-a';
  const r1 = await checkRateLimit(key);
  await checkRateLimit(key);
  const r3 = await checkRateLimit(key);
  const r4 = await checkRateLimit(key);
  assert.equal(r1.allowed, true);
  assert.equal(r3.allowed, true);
  assert.equal(r4.allowed, false);
  assert.equal(r4.remaining, 0);
  assert.equal(r4.scope, 'instance');
});

test('rate limit is per key', async () => {
  await checkRateLimit('a');
  await checkRateLimit('a');
  await checkRateLimit('a');
  const other = await checkRateLimit('b');
  assert.equal(other.allowed, true);
});
