import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { ACTION_NAMES, ALWAYS_CONFIRM, ACTIONS } from '../lib/actions.js';

/**
 * Cross-language parity.
 *
 * Reads the Kotlin ActionSpec enum and asserts the device knows exactly the
 * actions the server can emit — no more, no fewer. This is the test that makes
 * "the two halves drifted apart" (the root cause of the v3 gap review)
 * impossible to merge again.
 */

const here = path.dirname(fileURLToPath(import.meta.url));
const specPath = path.resolve(here, '../../android/core/src/main/kotlin/ai/jarvis/core/ActionSpec.kt');

function kotlinActions() {
  const src = fs.readFileSync(specPath, 'utf8');
  const names = [];
  const re = /^\s*([A-Z][A-Z0-9_]*)\(\s*"([a-z0-9_]+)"([^)]*)\)/gm;
  let m;
  while ((m = re.exec(src)) !== null) {
    names.push({ wire: m[2], confirm: /needsConfirmation\s*=\s*true/.test(m[3]) });
  }
  return names;
}

test('the Kotlin ActionSpec file exists and parses', () => {
  assert.ok(fs.existsSync(specPath), `ActionSpec.kt not found at ${specPath}`);
  const names = kotlinActions();
  assert.ok(names.length >= 45, `expected >=45 Kotlin actions, parsed ${names.length}`);
});

test('every server action exists on the device', () => {
  const kotlin = new Set(kotlinActions().map((a) => a.wire));
  const missing = ACTION_NAMES.filter((n) => !kotlin.has(n));
  assert.deepEqual(missing, [], `device is missing: ${missing.join(', ')}`);
});

test('the device declares no action the server cannot emit', () => {
  const server = new Set(ACTION_NAMES);
  const extra = kotlinActions().map((a) => a.wire).filter((n) => !server.has(n));
  assert.deepEqual(extra, [], `device has extras: ${extra.join(', ')}`);
});

test('confirm flags agree between server and device', () => {
  const kotlin = new Map(kotlinActions().map((a) => [a.wire, a.confirm]));
  for (const name of ACTION_NAMES) {
    const serverWants = ALWAYS_CONFIRM.has(name) || ACTIONS[name].risk === 'high';
    const deviceWants = kotlin.get(name) === true;
    if (serverWants) {
      assert.ok(deviceWants, `${name}: server requires confirmation but the device does not`);
    }
  }
});
