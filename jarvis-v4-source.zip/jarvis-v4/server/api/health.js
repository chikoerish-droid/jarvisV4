import { handleHealth } from '../lib/handler.js';

/**
 * GET /api/health
 *
 * Authenticated with the same device token as /api/plan, so "Test connection"
 * in the app reports the truth. Returns which provider is active and whether
 * its key is present — never the key itself.
 */
export default async function handler(req, res) {
  return handleHealth(req, res);
}
