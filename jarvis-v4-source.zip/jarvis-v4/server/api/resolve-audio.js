import { authenticate, isAuthConfigured } from '../lib/auth.js';
import { checkRateLimit } from '../lib/ratelimit.js';
import { newRequestId, log } from '../lib/log.js';

/**
 * POST /api/resolve-audio
 *
 * The phone cannot extract the audio track from a YouTube/SoundCloud page by
 * itself. This endpoint forwards the request to a resolver service the
 * operator runs (AUDIO_RESOLVER_URL) and returns a direct audio URL the phone
 * can hand to DownloadManager.
 *
 * If no resolver is configured this answers 501 with a clear message. It does
 * NOT pretend to work and it does NOT download a web page as if it were audio
 * — that was the v3 behaviour that made "download this song as mp3" silently
 * produce an HTML file.
 *
 * Resolver contract:
 *   POST {url}  ->  { audio_url, title?, ext?, bitrate? }
 */

function json(res, status, body) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.end(JSON.stringify(body));
}

async function readJson(req) {
  if (req.body && typeof req.body === 'object') return req.body;
  if (typeof req.body === 'string') return JSON.parse(req.body || '{}');
  const chunks = [];
  for await (const c of req) chunks.push(c);
  const text = Buffer.concat(chunks).toString('utf8');
  return text ? JSON.parse(text) : {};
}

export default async function handler(req, res) {
  const requestId = newRequestId();

  if (req.method !== 'POST') {
    json(res, 405, { error: 'method_not_allowed' });
    return;
  }
  if (!isAuthConfigured()) {
    json(res, 500, { error: 'server_misconfigured' });
    return;
  }
  const auth = authenticate(req);
  if (!auth.ok) {
    json(res, auth.status, { error: auth.error });
    return;
  }
  const rl = await checkRateLimit(`audio:${auth.tokenId}`);
  if (!rl.allowed) {
    json(res, 429, { error: 'rate_limited' });
    return;
  }

  const resolver = process.env.AUDIO_RESOLVER_URL;
  if (!resolver) {
    json(res, 501, {
      error: 'audio_resolver_not_configured',
      message: 'قابلیت استخراج صدا روی این سرور فعال نیست. AUDIO_RESOLVER_URL را تنظیم کنید.',
    });
    return;
  }

  let body;
  try {
    body = await readJson(req);
  } catch {
    json(res, 400, { error: 'bad_request' });
    return;
  }

  const query = typeof body.query === 'string' ? body.query.trim() : '';
  if (!query) {
    json(res, 400, { error: 'missing_query' });
    return;
  }

  try {
    const upstream = await fetch(resolver, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(process.env.AUDIO_RESOLVER_TOKEN
          ? { Authorization: `Bearer ${process.env.AUDIO_RESOLVER_TOKEN}` }
          : {}),
      },
      body: JSON.stringify({ query, bitrate: body.bitrate || '192' }),
      signal: AbortSignal.timeout(25000),
    });

    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok || !data.audio_url) {
      log('warn', 'audio_resolve_failed', { requestId, status: upstream.status });
      json(res, 502, { error: 'resolve_failed', message: 'استخراج صدا ناموفق بود.' });
      return;
    }

    log('info', 'audio_resolved', { requestId });
    json(res, 200, {
      audio_url: data.audio_url,
      title: data.title || null,
      ext: data.ext || 'm4a',
      bitrate: data.bitrate || body.bitrate || '192',
    });
  } catch (err) {
    log('error', 'audio_resolve_error', { requestId, detail: err.message });
    json(res, 502, { error: 'resolve_failed', message: 'استخراج صدا ناموفق بود.' });
  }
}
