import { handlePlan } from '../lib/handler.js';

/**
 * POST /api/plan
 *
 * The single endpoint the phone talks to. It receives an utterance (or the
 * result of the previous step) and returns the next validated plan.
 *
 * The model key lives only in this process's environment. Nothing about the
 * key is ever sent to the phone.
 */
export default async function handler(req, res) {
  return handlePlan(req, res);
}
