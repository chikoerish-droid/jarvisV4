# Server architecture

The server is the **brain**. It holds the model key, turns a free-form sentence
into a validated action plan, and never touches the phone's state directly.

```
┌──────────────────────────┐        ┌─────────────────────────────┐
│  Android (phone)         │        │  Relay (this folder)        │
│                          │        │                             │
│  mic ─┐                  │        │  ┌───────────────────────┐  │
│       ├─ STT (platform)  │        │  │ JARVIS_DEVICE_TOKEN   │  │
│  text ┘                  │        │  │   (fail-closed auth)  │  │
│        │                 │  HTTPS │  └───────────┬───────────┘  │
│        └─────────────────┼───────►│              ▼              │
│                          │  Bearer│  ┌───────────────────────┐  │
│  Accessibility tree ◄────┼────────│  │  validate + prompt    │  │
│  (read_screen)           │  plan  │  └───────────┬───────────┘  │
│        │                 │        │              ▼              │
│        └─ gestures,      │        │  ┌───────────────────────┐  │
│           typing         │◄───────┼──┤  Gemini / OpenAI /    │  │
│                          │ JSON   │  │  OpenRouter            │  │
│  (no model key here)     │        │  │  (key only lives here) │  │
└──────────────────────────┘        │  └───────────────────────┘  │
                                    └─────────────────────────────┘
```

## The loop

```
user speaks
    │
    ▼
POST /api/plan { utterance, locale, deviceState, history }
    │
    ├─ auth (constant-time, fail-closed)
    ├─ rate limit (per token)
    ├─ provider call → JSON
    ├─ validate → drop unknown actions/params, force confirm on risky
    ▼
{ speech, steps: [ ... ] }
    │
    ▼
phone executes, collecting observations
    │
    ▼
POST /api/plan { mode: "step", observation, iteration }
    │
    └─► repeat until done / needs_user / max_iterations
```

Two modes exist for a reason: the first call carries the whole prompt and the
action catalogue; every later call is smaller (`stepPrompt`) and only needs the
observation, which keeps each round trip fast and cheap.

## Why one action table

`lib/actions.js` is the only place an action is declared. From it we generate:

- the JSON Schema (`lib/schema.js`)
- the catalogue inside the system prompt (`lib/prompt.js`)
- the parameter reference
- server validation (`lib/validate.js`)
- the confirmation set

The device has a mirror (`ActionSpec.kt`) and **`test/parity.test.js` reads it**:
if the two lists differ by even one name, the test suite fails. This is how the
v3 drift is prevented permanently.

## Adding an action

1. Add it to `lib/actions.js` (`desc`, `params`, `risk`).
2. Add the matching enum entry to `android/core/.../ActionSpec.kt`.
3. Add a branch in `android/app/.../exec/Executor.kt`.
4. `cd server && npm test` — the parity test and the executor-coverage test
   will tell you if you missed a step.
5. The prompt and schema update themselves.

## Endpoints

| Method | Path | Auth | Purpose |
|---|---|---|---|
| `POST` | `/api/plan` | Bearer | The plan (mode `plan`) or the next step (mode `step`) |
| `GET` | `/api/health` | Bearer | Provider, model, whether the key is present |
| `POST` | `/api/resolve-audio` | Bearer | Proxy to a resolver you run (501 when unset) |

### `POST /api/plan` — request

```jsonc
{
  "utterance": "اینستاگرام را باز کن و پیام‌هایم را بخوان",  // mode=plan
  "mode": "plan",                    // or "step"
  "locale": "fa-IR",
  "iteration": 0,
  "history": [{ "role": "user", "content": "..." }],
  "deviceState": { "foregroundApp": "com.android.launcher3" },
  "observation": null,               // mode=step: { action, ok, error, data }
  "screenImage": null,               // base64 JPEG, no data: prefix
  "screenImageMime": "image/jpeg"
}
```

### `POST /api/plan` — response

```jsonc
{
  "requestId": "k3f9x2ab",
  "mode": "plan",
  "speech": "باشه، بازش می‌کنم",
  "steps": [
    { "action": "open_app", "params": { "app": "اینستاگرام" },
      "confirm_before": false }
  ],
  "needsUser": false,
  "done": false,
  "provider": "gemini",
  "model": "gemini-2.5-flash",
  "usage": { "totalTokenCount": 1840 },
  "dropped": []                      // what validation removed, for debugging
}
```

### Errors

Every error has an `error` code, a Persian `message` for the user, and a
`requestId` that matches the server log line.

| Status | `error` | Meaning |
|---|---|---|
| 400 | `missing_utterance` | empty request |
| 401 | `missing_token` / `bad_token` | device token wrong or absent |
| 413 | `utterance_too_long` | over `MAX_UTTERANCE_CHARS` |
| 429 | `rate_limited` | over `RATE_LIMIT_PER_MIN`; has `Retry-After` |
| 500 | `server_misconfigured` | token or model key not set — **fail-closed** |
| 502 | `provider_error` / `empty_response` | the model failed |
| 504 | `timeout` | over `MODEL_TIMEOUT_MS` |

## Cost

Rough numbers, to be checked against current provider pricing before you rely
on them — I am not inventing exact prices.

- One plan call: system prompt is ~3.5k tokens (the action catalogue is the bulk),
  plus a screen tree of 1–2k tokens, plus 300 tokens of output.
- A 4-iteration task is therefore roughly 4 × 5k ≈ 20k tokens.
- At a small-model price (sub-cent per 100k input tokens) that is fractions of a
  cent per task. With a frontier model it is a few cents.
- **The cheap win if cost matters:** cache the system prompt with the provider's
  prompt-caching feature — it is identical on every request, and it is the
  single largest input.

## Operational notes

- **Cold start** adds ~300–800 ms on Vercel. `maxDuration` is 60 s in
  `vercel.json` because the model call itself can take 30 s.
- **Rate limiting** is per-instance in memory unless you set the Upstash
  variables. `X-RateLimit-Scope` tells you which mode you are in.
- **Logging** is JSON lines with `requestId`. Utterances are *not* logged unless
  you set `JARVIS_LOG_UTTERANCES=1`; turn it on only while debugging.
- **Secrets** never appear in a response, and `key_configured` is a boolean, not
  the key.
