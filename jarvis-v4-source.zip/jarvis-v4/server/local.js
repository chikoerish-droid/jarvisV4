import http from 'node:http';
import { handlePlan, handleHealth } from './lib/handler.js';
import resolveAudio from './api/resolve-audio.js';

/**
 * Local development server — no Vercel CLI needed.
 *
 *   cp .env.example .env      # then fill it in
 *   npm install
 *   npm run dev               # http://localhost:3000
 *
 * It loads .env itself (Node 20 has --env-file, but this keeps `npm run dev`
 * working on any 20.x).
 */

import fs from 'node:fs';
import path from 'node:path';

const envPath = path.resolve(process.cwd(), '.env');
if (fs.existsSync(envPath)) {
  for (const line of fs.readFileSync(envPath, 'utf8').split('\n')) {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/.exec(line);
    if (m && !process.env[m[1]]) {
      process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
    }
  }
}

const PORT = Number(process.env.PORT || 3000);

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  try {
    if (url.pathname === '/api/plan') return await handlePlan(req, res);
    if (url.pathname === '/api/health') return await handleHealth(req, res);
    if (url.pathname === '/api/resolve-audio') return await resolveAudio(req, res);
    res.statusCode = 404;
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify({ error: 'not_found', routes: ['/api/plan', '/api/health', '/api/resolve-audio'] }));
  } catch (err) {
    console.error(err);
    res.statusCode = 500;
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify({ error: 'internal', message: err.message }));
  }
});

server.listen(PORT, () => {
  console.log(`Jarvis bridge listening on http://localhost:${PORT}`);
  console.log(`  provider: ${process.env.AI_PROVIDER || 'gemini'}`);
  console.log(`  token set: ${Boolean(process.env.JARVIS_DEVICE_TOKEN)}`);
});
